# حركة 967 — Production Readiness

## Stage 6 status

**READY WITH CONDITIONS**

The repository has received a security and production-hardening pass without rebuilding the architecture. Important authentication, upload, input-integrity, rate-limit, error-handling, and membership workflow issues were fixed.

### Automated verification status for this audit environment

- Type Check: **NOT RUN SUCCESSFULLY** — dependencies/types are not installed and outbound package download is unavailable in the audit environment.
- Tests: **NOT RUN** — pnpm could not be installed because the npm registry was unreachable from the audit environment.
- Build: **NOT RUN** — same dependency/network limitation.
- Lint: **NOT CONFIGURED / NOT RUN** — the repository does not define a lint script.

Do not treat any of the above as a PASS.

## Fixed in Stage 6

- Same-origin validation for the login redirect target.
- File-signature validation and canonical file extensions for uploads.
- CV attachment integrity validation in membership submissions.
- Duplicate protection for active/approved membership applications.
- Submission notification to the configured membership/owner inbox.
- Applicant status email after review.
- Safer client-IP selection for rate limiting.
- Smaller JSON/form request limits.
- Generic API error handling without internal error disclosure.
- Existing logout test corrected to the implemented cookie policy.

## Required manual steps before production

1. Install dependencies with `pnpm install --frozen-lockfile` in an environment with registry access.
2. Run `pnpm check` and fix any environment-specific/type errors reported by the real dependency set.
3. Run `pnpm test`.
4. Run `pnpm build`.
5. Configure `DATABASE_URL`.
6. Configure a strong `JWT_SECRET` (at least 32 characters; preferably a long random value).
7. Configure S3/R2-compatible storage if uploads are required.
8. Configure SMTP and `JOIN_REQUESTS_EMAIL` if membership/contact email delivery is required.
9. If frontend and backend use different domains, configure `ALLOWED_ORIGIN`, `PUBLIC_SERVER_URL`, and `VITE_API_URL`.
10. Create the first super administrator using the controlled bootstrap process, then set `ALLOW_BOOTSTRAP_SUPER_ADMIN=false`.
11. Confirm the GitHub Actions quality workflow is green on the production commit.

## External configuration conditions

- Rate limiting is in-memory by default. A shared Redis-compatible implementation is required if multiple backend instances are deployed.
- Storage and email delivery depend on valid production credentials and provider configuration.
- A real database is required for end-to-end verification.

See `SECURITY_REVIEW_STAGE6.md` for the detailed audit findings and limitations.

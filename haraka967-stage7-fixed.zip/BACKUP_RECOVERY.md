# Backup & Recovery

Before any large change:
1. copy the project folder or export a ZIP backup
2. keep the backup name explicit
3. make only one major change at a time
4. update `PROGRESS.md` after each stable milestone

## Recommended backup names
- `967-platform-backup-before-auth-fix.zip`
- `967-platform-backup-before-admin-fix.zip`
- `967-platform-backup-stable.zip`

## Recovery order
If something breaks:
1. restore the latest backup
2. re-check environment values
3. sign in with the owner account
4. verify `/admin`
5. run build/tests again

## Why this matters
This repository contains auth, admin, content, and database logic in one place. A small backup habit prevents losing a working state while you are cleaning it up.

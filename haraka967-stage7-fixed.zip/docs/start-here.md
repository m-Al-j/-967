# Start Here

For the lowest-friction path, read these in order:
1. `PROGRESS.md`
2. `ADMIN_SETUP.md`
3. `BACKUP_RECOVERY.md`
4. `README.md`

Then verify the owner/admin sign-in path before touching anything else.

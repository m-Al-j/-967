# Architecture Notes

## Stability principles

1. Keep UI, server, shared validation, and database schema separated.
2. Put all sensitive authorization checks on the server.
3. Use database settings for operational values such as:
   - owner email
   - join requests email
   - admin email list
4. Keep uploads locked down by file type, size, and ownership.
5. Add indexes for list/search/filter pages before data volume grows.
6. Use pagination for every large collection.
7. Prefer small migrations over schema rewrites.

## Places to extend safely

- `client/src/pages/` for page-level UI
- `client/src/components/` for shared UI components
- `server/routers.ts` for API behavior
- `server/db.ts` for data access helpers
- `shared/` for schemas and validation rules
- `drizzle/` for schema and migrations

## Operational values

These should remain editable from the database/admin UI rather than hard-coded:

- owner name
- owner email
- owner phone
- join requests email
- admin email list

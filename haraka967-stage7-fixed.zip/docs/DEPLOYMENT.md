# نشر Haraka 967 — Cloudflare Pages (Frontend) + Render/Railway (Backend) + Supabase (DB)

## لماذا هذه البنية بالذات؟

المشروع Backend حقيقي طويل الأمد (Express + tRPC + اتصال Postgres عبر TCP +
SMTP + رفع ملفات) — هذا النمط لا يعمل على Cloudflare Workers إلا بعد إعادة
هيكلة كبيرة (استبدال Postgres TCP بـ Hyperdrive، واستبدال SMTP بخدمة HTTP،
وإعادة كتابة Express بـ router متوافق مع Workers). البنية التالية تحافظ على
الكود الحالي كاملًا بدون حذف أي ميزة:

- **Frontend** (React/Vite الناتج الثابت) → **Cloudflare Pages**
- **Backend** (Express/tRPC/Drizzle كعملية Node مستمرة) → **Render** أو **Railway**
- **Database** → **Supabase Postgres** (تم التأكيد أن لديك مشروع جاهز)
- **تخزين الملفات (S3-compatible)** → يمكن استخدام **Supabase Storage** (لها
  واجهة متوافقة مع S3) أو أي مزود آخر (R2, AWS S3, MinIO)

---

## الخطوة 1 — قاعدة البيانات (Supabase)

1. من لوحة Supabase: **Project Settings → Database → Connection string → URI**
   - يفضّل استخدام **Connection Pooling** (Transaction mode, المنفذ 6543) لأن
     الاتصال المباشر (5432) قد يُحدّ في الخطط المجانية.
   - تأكد أن الرابط يحتوي `?sslmode=require` (الكود يفعّل TLS تلقائيًا لأي
     مضيف غير localhost، لكن وجودها صراحة أضمن).
2. طبّق المخطط الحالي على القاعدة (من جهازك، بعد `pnpm install`):
   ```bash
   export DATABASE_URL="<connection string من supabase>"
   pnpm run db:push
   ```
3. هذا القيمة هي `DATABASE_URL` التي ستضعها في متغيرات بيئة الـ Backend.

**تخزين الملفات عبر Supabase Storage (بديل S3 خارجي):**
- Supabase Dashboard → **Storage → Settings → S3 Connection**، فعّل S3 access
  وأنشئ Access Key/Secret.
- عندها:
  ```
  S3_BUCKET=<اسم الـ bucket الذي أنشأته>
  S3_REGION=<المنطقة المعروضة، غالبًا us-east-1>
  S3_ENDPOINT=https://<project-ref>.supabase.co/storage/v1/s3
  S3_FORCE_PATH_STYLE=true
  S3_ACCESS_KEY_ID=<من Supabase>
  S3_SECRET_ACCESS_KEY=<من Supabase>
  ```

---

## الخطوة 2 — الباك-إند (Render أو Railway)

### عبر Render (يوجد `render.yaml` جاهز في جذر المشروع)
1. ادفع الكود إلى مستودع Git (GitHub/GitLab).
2. Render Dashboard → **New → Blueprint** → اختر المستودع → Render سيقرأ
   `render.yaml` تلقائيًا وينشئ خدمة `haraka967-api`.
3. في تبويب **Environment** أضف القيم الحقيقية لكل متغير مُعلَّم
   `sync: false` في `render.yaml` (القائمة الكاملة في القسم أدناه).
4. Deploy. راقب الـ Logs، تأكد من ظهور `Server listening on port 3000` وأن
   `/healthz` يرجع `200`.
5. انسخ الرابط العام الذي يعطيك إياه Render (مثل
   `https://haraka967-api.onrender.com`) — هذا هو `PUBLIC_SERVER_URL`
   و`VITE_API_URL` لاحقًا.

### عبر Railway (بديل)
1. New Project → Deploy from GitHub repo.
2. Railway يكتشف `package.json` تلقائيًا (Nixpacks). اضبط يدويًا:
   - Build Command: `pnpm install --frozen-lockfile && pnpm run build:server`
   - Start Command: `pnpm start`
3. أضف نفس متغيرات البيئة من القائمة أدناه في تبويب **Variables**.
4. بعد أول Deploy، فعّل **Generate Domain** للحصول على رابط HTTPS عام.

---

## الخطوة 3 — الفرونت-إند (Cloudflare Pages)

عبر لوحة التحكم (الأسهل):
1. Cloudflare Dashboard → **Workers & Pages → Create → Pages → Connect to Git**
2. اختر المستودع، ثم اضبط:
   - **Build command**: `pnpm install && pnpm run build:client`
   - **Build output directory**: `dist/public`
3. **Settings → Environment variables** (لكل من Production وPreview):
   - `VITE_API_URL` = رابط الباك-إند من الخطوة السابقة، مثل
     `https://haraka967-api.onrender.com`
4. Deploy. Cloudflare يعطيك تلقائيًا رابط `https://<project>.pages.dev` مع
   HTTPS مفعّل، ونشر Preview تلقائي لكل Pull Request.

ملف `client/public/_redirects` موجود مسبقًا (`/* /index.html 200`) لضمان
عمل التنقل من جهة العميل (wouter) بشكل صحيح مع كل الروابط المباشرة.

عبر CLI (بديل، ملف `wrangler.toml` جاهز في الجذر):
```bash
pnpm install
VITE_API_URL=https://haraka967-api.onrender.com pnpm run build:client
npx wrangler pages deploy dist/public --project-name=haraka967
```

---

## الخطوة 4 — الربط النهائي بين الطرفين

بعد معرفة رابطي Cloudflare Pages وRender:

**في الباك-إند (Render/Railway) أضف:**
```
ALLOWED_ORIGIN=https://<project>.pages.dev
PUBLIC_SERVER_URL=https://haraka967-api.onrender.com
```
ثم أعد النشر (redeploy) — هذا يفعّل CORS + يجعل كوكي الجلسة تعمل عبر النطاقين
(SameSite=None; Secure) + يجعل روابط الملفات المرفوعة مطلقة وصحيحة.

**في الفرونت-إند (Cloudflare Pages) تأكد من:**
```
VITE_API_URL=https://haraka967-api.onrender.com
```
ثم أعد البناء (VITE_API_URL متغير build-time، أي تغييره يتطلب إعادة نشر).

> إذا ربطت لاحقًا نطاقًا مخصصًا لكليهما تحت نفس الدومين الأساسي (مثل
> `app.haraka967.org` للفرونت و`api.haraka967.org` للباك-إند)، تقدر تبسّط
> الأمر أكثر لاحقًا، لكن هذا غير مطلوب للتشغيل الحالي.

---

## القائمة الكاملة لمتغيرات البيئة المطلوبة (Backend)

| المتغير | إلزامي؟ | ملاحظة |
|---|---|---|
| `DATABASE_URL` | **نعم** | من Supabase (الخطوة 1) |
| `JWT_SECRET` | **نعم** | 32+ حرفًا عشوائيًا. ولّده بـ `openssl rand -base64 48` |
| `ALLOWED_ORIGIN` | **نعم** (بنية النطاقين) | رابط Cloudflare Pages |
| `PUBLIC_SERVER_URL` | **نعم** (بنية النطاقين) | رابط Render/Railway |
| `OWNER_EMAIL` | موصى به | بريدك ليصبح Owner/Admin تلقائيًا |
| `BOOTSTRAP_SUPER_ADMIN_EMAIL` / `_PASSWORD` | لأول تشغيل فقط | راجع `ADMIN_SETUP.md` |
| `ALLOW_BOOTSTRAP_SUPER_ADMIN` | لأول تشغيل فقط | اجعلها `true` مؤقتًا ثم أعدها `false` بعد إنشاء أول أدمن |
| `S3_BUCKET` / `S3_REGION` / `S3_ACCESS_KEY_ID` / `S3_SECRET_ACCESS_KEY` / `S3_ENDPOINT` | **نعم لرفع الملفات** | Supabase Storage أو أي S3 (الخطوة 1) |
| `SMTP_HOST` / `SMTP_PORT` / `SMTP_USER` / `SMTP_PASSWORD` / `SMTP_FROM` | موصى به | بدونها تُعطَّل إشعارات البريد فقط (لا يوقف التطبيق) |
| `JOIN_REQUESTS_EMAIL` | اختياري | وجهة إشعارات طلبات الانضمام |
| `GOOGLE_MAPS_API_KEY` | اختياري | فقط إذا استخدمت صفحات الخرائط |
| `RATE_LIMIT_REDIS_URL` | اختياري | بدونها يعمل rate-limiting في الذاكرة (كافٍ لخادم واحد) |

## متغير بيئة الفرونت-إند (Cloudflare Pages)

| المتغير | إلزامي؟ | ملاحظة |
|---|---|---|
| `VITE_API_URL` | **نعم** | رابط الباك-إند الكامل بدون `/` في النهاية |

---

## الخطوة 5 — التحقق بعد النشر (Checklist)

- [ ] `https://<backend>/healthz` يرجع `{"ok":true,...}`
- [ ] فتح رابط Cloudflare Pages: تظهر الصفحة الرئيسية بلا أخطاء Console
- [ ] تسجيل الدخول (`/login`) ينجح، والكوكي تُحفظ (تحقق من DevTools →
      Application → Cookies أن الكوكي `Secure` و`SameSite=None`)
- [ ] بعد تسجيل الدخول، `/admin` يفتح إذا كان بريدك مطابقًا لـ `OWNER_EMAIL`
      أو `BOOTSTRAP_SUPER_ADMIN_EMAIL`
- [ ] رفع صورة/ملف من لوحة الأدمن يعمل، والرابط الناتج يفتح الصورة فعليًا
      (يتحقق من صحة `PUBLIC_SERVER_URL` + إعداد S3)
- [ ] استدعاءات tRPC (أي صفحة بيانات: News, Projects, Knowledge) تُحمّل بلا
      أخطاء CORS في Console
- [ ] صفحة `/join` (تقديم طلب انضمام + رفع CV) تعمل بدون تسجيل دخول

---

## قبل ذلك: تنفيذ محليًا (install / build / test)

نُفّذ كل التعديلات البرمجية والإعدادات هنا، لكن لم يتم تشغيل
`pnpm install`/`pnpm build`/`pnpm test` فعليًا لأن بيئة التنفيذ الحالية بلا
اتصال إنترنت. نفّذ هذا محليًا أو في CI قبل أول نشر:

```bash
pnpm install
pnpm run check      # tsc --noEmit
pnpm test           # vitest run
pnpm run build:client
pnpm run build:server
```

أصلح أي خطأ TypeScript/اختبار يظهر قبل المتابعة للنشر — لم يكن هناك أي خطأ
ظاهر من الفحص اليدوي للكود، لكن الفحص الآلي (tsc/vitest) هو المرجع النهائي.

# حركة 967 — Stage 6 Security & Production Hardening Audit

Date: 2026-08-13

## Executive Summary

The repository was inspected as a security/production hardening pass. The existing architecture was preserved.

### Fixed in Stage 6

- Blocked login open-redirect behavior by allowing post-login navigation only to the same origin.
- Stopped rate-limit identifiers from trusting a raw client-supplied `X-Forwarded-For` value; Express' resolved request IP is now used.
- Reduced JSON and URL-encoded body limits from 50 MB to 2 MB. Multipart uploads retain their dedicated limits.
- Added file-signature validation for PDF, legacy DOC, DOCX, JPEG, PNG, and WEBP uploads.
- File keys now use canonical extensions derived from the validated MIME type instead of the user-supplied filename extension.
- Prevented membership applications from attaching arbitrary/external CV URLs or mismatched file metadata. The referenced file must exist in the private CV folder and match the stored metadata.
- Added duplicate protection for active/approved membership applications using a case-insensitive email check.
- Added owner notification when a membership application is submitted.
- Added applicant email notification after an application review; email delivery remains best-effort and never makes the review fail.
- Added a production-safe API error boundary so unexpected API failures do not return internal HTML/stack details.
- Corrected the existing logout test expectation to match the actual same-origin `SameSite=Lax` cookie policy.

## Security Findings

| Severity | Finding | Status |
|---|---|---|
| HIGH | Login `next` parameter could be used as an external redirect target | Fixed |
| HIGH | Upload validation trusted browser MIME declarations without file signatures | Fixed |
| HIGH | Membership application could reference arbitrary CV URL/file metadata | Fixed |
| MEDIUM | Rate limiting trusted raw `X-Forwarded-For` | Fixed |
| MEDIUM | 50 MB JSON/form body limits increased unauthenticated memory/DoS exposure | Fixed |
| MEDIUM | Membership submission lacked active/approved duplicate protection | Fixed |
| LOW | Unexpected API errors could fall through to Express' default error response | Fixed |
| INFO | In-memory rate limiting is not suitable for multiple backend instances | Requires Redis/shared store for horizontal scaling |
| INFO | Production credentials/external services cannot be verified from this repository-only audit | Requires deployment configuration |

## Authentication / RBAC Assessment

The server-side RBAC boundary is present and is used by sensitive procedures. The frontend is not the authorization boundary. Role assignment and user-management policy checks prevent lower-ranked administrators from modifying equal/higher-ranked accounts or granting permissions they do not possess.

The session is held in an HTTP-only cookie and the password hash is not returned by the authenticated-user endpoint or the administrative user listing.

The first-super-admin bootstrap path is guarded by an explicit environment flag and only activates when no admin exists. It should be disabled after initial setup.

## File Storage Assessment

Storage access is proxied through the backend and sensitive CV objects require authentication plus the appropriate ownership/administrative permission. Uploads are size-limited, rate-limited, MIME allowlisted, signature checked, and stored under generated keys.

## Testing Limitation

A complete `pnpm install --frozen-lockfile` could not be executed in this audit environment because `pnpm` was not installed and Corepack could not download pnpm from the npm registry due unavailable outbound DNS/network access.

The repository therefore must **not** be described as having a passing type-check, test suite, or production build based on this audit alone.

The local global TypeScript binary was also unable to run the project check because the repository has no installed dependencies/types (`@types/node`, `vite/client`, etc.).

GitHub Actions remains the authoritative automated quality gate once the repository is pushed to GitHub.

import { and, desc, eq, ilike, inArray, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import {
  applications,
  auditLogs,
  contactMessages,
  files,
  knowledge,
  mapPoints,
  members,
  news,
  notifications,
  pages,
  projectParticipationRequests,
  projects,
  rolePermissions,
  siteSettings,
  userPermissions,
  users,
  type InsertApplication,
  type InsertAuditLog,
  type InsertContactMessage,
  type InsertFile,
  type InsertKnowledge,
  type InsertMapPoint,
  type InsertMember,
  type InsertNews,
  type InsertNotification,
  type InsertPage,
  type InsertProject,
  type InsertProjectParticipationRequest,
  type InsertSiteSetting,
  type InsertUser,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { isPermission, type Permission } from "./_core/permissions";

let _db: ReturnType<typeof drizzle> | null = null;
let _client: ReturnType<typeof postgres> | null = null;

export async function getDb() {
  if (!_db && ENV.databaseUrl) {
    try {
      // Supabase (and most managed Postgres providers) require TLS.
      // Skip only for explicit local/non-TLS connection strings.
      const needsSsl =
        !/localhost|127\.0\.0\.1/.test(ENV.databaseUrl) && !/sslmode=disable/.test(ENV.databaseUrl);
      _client ??= postgres(ENV.databaseUrl, {
        max: ENV.databasePoolMax,
        prepare: false,
        ssl: needsSsl ? "require" : false,
      });
      _db = drizzle(_client);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

type SiteSettingsCacheEntry = {
  fetchedAt: number;
  rows: typeof siteSettings.$inferSelect[];
};

const SITE_SETTINGS_CACHE_TTL_MS = 30_000;
let cachedSiteSettings: SiteSettingsCacheEntry | null = null;

function invalidateSiteSettingsCache() {
  cachedSiteSettings = null;
}

async function loadSiteSettings(): Promise<typeof siteSettings.$inferSelect[]> {
  const now = Date.now();
  if (cachedSiteSettings && now - cachedSiteSettings.fetchedAt < SITE_SETTINGS_CACHE_TTL_MS) {
    return cachedSiteSettings.rows;
  }

  const db = await getDb();
  if (!db) return [];

  const rows = await db.select().from(siteSettings);
  cachedSiteSettings = { rows, fetchedAt: now };
  return rows;
}

function parseEmailList(value: string | null | undefined): string[] {
  if (!value) return [];
  const trimmed = value.trim();
  if (!trimmed) return [];
  if (trimmed.startsWith("[")) {
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) {
        return parsed
          .map((item) => String(item).trim().toLowerCase())
          .filter(Boolean);
      }
    } catch {}
  }
  return trimmed
    .split(/[\n,;]/g)
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean);
}

export async function getSettingValue(key: string): Promise<string | null> {
  const rows = await loadSiteSettings();
  const row = rows.find((item) => item.key === key);
  const value = row?.value;
  return value == null ? null : String(value);
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId, updatedAt: new Date() };
  const updateSet: Record<string, unknown> = {};
  (["name", "email", "loginMethod", "passwordHash"] as const).forEach((f) => {
    if (user[f] !== undefined) { values[f] = user[f] ?? null; updateSet[f] = user[f] ?? null; }
  });
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  const configuredOwnerEmail = (await getSettingValue("owner_email"))?.trim().toLowerCase() || ENV.ownerEmail.trim().toLowerCase();
  const configuredAdminEmails = parseEmailList(await getSettingValue("admin_emails"));
  const userEmail = user.email?.trim().toLowerCase() ?? null;
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId || (configuredOwnerEmail && userEmail === configuredOwnerEmail)) {
    values.role = "super_admin";
    updateSet.role = "super_admin";
  } else if (userEmail && configuredAdminEmails.includes(userEmail)) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  updateSet.updatedAt = new Date();
  await db.insert(users).values(values).onConflictDoUpdate({ target: users.openId, set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const r = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return r[0];
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const r = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return r[0];
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const r = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return r[0];
}

export async function createLocalUser(user: InsertUser) {
  const db = await getDb();
  if (!db) throw new Error('Database unavailable');
  const [inserted] = await db.insert(users).values(user).returning();
  return inserted;
}

export async function updateUserById(id: number, patch: Partial<InsertUser>) {
  const db = await getDb();
  if (!db) throw new Error('Database unavailable');
  await db.update(users).set({ ...patch, updatedAt: new Date() }).where(eq(users.id, id));
}

export async function countAdminUsers(): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(users)
    .where(or(eq(users.role, "super_admin"), eq(users.role, "admin")));
  return Number(count);
}

export async function listUsers(page = 1, limit = 20) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const offset = (page - 1) * limit;
  const [items, [{ count }]] = await Promise.all([
    db.select().from(users).orderBy(desc(users.createdAt)).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(users),
  ]);
  return { items, total: Number(count) };
}

/** Paginated + filterable user listing for the admin panel. */
export async function listUsersFiltered(opts: {
  page?: number;
  limit?: number;
  search?: string;
  role?: string;
  isActive?: boolean;
} = {}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const page = Math.max(1, opts.page ?? 1);
  const limit = Math.min(100, Math.max(1, opts.limit ?? 20));
  const offset = (page - 1) * limit;

  const conditions = [] as ReturnType<typeof eq>[];
  if (opts.search) {
    const term = `%${opts.search}%`;
    conditions.push(or(ilike(users.name, term), ilike(users.email, term))!);
  }
  if (opts.role) conditions.push(eq(users.role, opts.role as typeof users.$inferSelect["role"]));
  if (typeof opts.isActive === "boolean") conditions.push(eq(users.isActive, opts.isActive));
  const where = conditions.length > 0 ? and(...conditions) : undefined;

  // Explicit column list: this listing is returned straight to the admin
  // panel over the wire, so the password hash must never be selected here.
  const [items, [{ count }]] = await Promise.all([
    db
      .select({
        id: users.id,
        openId: users.openId,
        name: users.name,
        email: users.email,
        loginMethod: users.loginMethod,
        role: users.role,
        isActive: users.isActive,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        lastSignedIn: users.lastSignedIn,
      })
      .from(users)
      .where(where)
      .orderBy(desc(users.createdAt))
      .limit(limit)
      .offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(users).where(where),
  ]);
  return { items, total: Number(count), page, limit };
}

export async function touchUserLastSignedIn(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, id));
}

// ─── RBAC ─────────────────────────────────────────────────────────────────────
export async function listRolePermissions(role: string): Promise<Permission[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({ permission: rolePermissions.permission })
    .from(rolePermissions)
    .where(eq(rolePermissions.role, role as typeof users.$inferSelect["role"]));
  return rows.map((row) => row.permission).filter(isPermission);
}

export async function listAllRolePermissions(): Promise<Record<string, Permission[]>> {
  const db = await getDb();
  if (!db) return {};
  const rows = await db.select().from(rolePermissions);
  const map: Record<string, Permission[]> = {};
  for (const row of rows) {
    if (!isPermission(row.permission)) continue;
    (map[row.role] ??= []).push(row.permission);
  }
  return map;
}

/** Replaces the whole permission set of a role atomically. */
export async function setRolePermissions(role: string, permissions: Permission[]) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const typedRole = role as typeof users.$inferSelect["role"];
  await db.transaction(async (tx) => {
    await tx.delete(rolePermissions).where(eq(rolePermissions.role, typedRole));
    if (permissions.length > 0) {
      await tx
        .insert(rolePermissions)
        .values(permissions.map((permission) => ({ role: typedRole, permission })))
        .onConflictDoNothing();
    }
  });
}

export async function listUserPermissionOverrides(
  userId: number
): Promise<{ permission: Permission; effect: "grant" | "deny" }[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({ permission: userPermissions.permission, effect: userPermissions.effect })
    .from(userPermissions)
    .where(eq(userPermissions.userId, userId));
  return rows
    .filter((row) => isPermission(row.permission))
    .map((row) => ({ permission: row.permission as Permission, effect: row.effect }));
}

/** Replaces the whole override set of a user atomically. */
export async function setUserPermissionOverrides(
  userId: number,
  overrides: { permission: Permission; effect: "grant" | "deny" }[],
  grantedBy: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.transaction(async (tx) => {
    await tx.delete(userPermissions).where(eq(userPermissions.userId, userId));
    if (overrides.length > 0) {
      await tx
        .insert(userPermissions)
        .values(overrides.map((override) => ({ ...override, userId, grantedBy })))
        .onConflictDoNothing();
    }
  });
}


// ─── News ─────────────────────────────────────────────────────────────────────
export async function listNews(opts: { page?: number; limit?: number; status?: string; search?: string } = {}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const { page = 1, limit = 12, status, search } = opts;
  const offset = (page - 1) * limit;
  const conditions = [];
  if (status) conditions.push(eq(news.status, status as any));
  if (search) conditions.push(or(like(news.title, `%${search}%`), like(news.excerpt, `%${search}%`)));
  const where = conditions.length ? and(...conditions) : undefined;
  const [items, [{ count }]] = await Promise.all([
    db.select().from(news).where(where).orderBy(desc(news.createdAt)).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(news).where(where),
  ]);
  return { items, total: Number(count) };
}

export async function getNewsBySlug(slug: string, opts: { includeUnpublished?: boolean } = {}) {
  const db = await getDb();
  if (!db) return undefined;
  const conditions = [eq(news.slug, slug)];
  if (!opts.includeUnpublished) conditions.push(eq(news.status, "published"));
  const r = await db.select().from(news).where(and(...conditions)).limit(1);
  return r[0];
}

export async function createNews(data: InsertNews) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(news).values(data);
}

export async function updateNews(id: number, data: Partial<InsertNews>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(news).set({ ...data, updatedAt: new Date() }).where(eq(news.id, id));
}

export async function deleteNews(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(news).where(eq(news.id, id));
}

// ─── Projects ─────────────────────────────────────────────────────────────────
export async function listProjects(opts: { page?: number; limit?: number; status?: string; search?: string } = {}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const { page = 1, limit = 12, status, search } = opts;
  const offset = (page - 1) * limit;
  const conditions = [];
  if (status) conditions.push(eq(projects.status, status as any));
  if (search) conditions.push(or(like(projects.title, `%${search}%`), like(projects.excerpt, `%${search}%`)));
  const where = conditions.length ? and(...conditions) : undefined;
  const [items, [{ count }]] = await Promise.all([
    db.select().from(projects).where(where).orderBy(desc(projects.createdAt)).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(projects).where(where),
  ]);
  return { items, total: Number(count) };
}

export async function getProjectBySlug(slug: string, opts: { includeUnpublished?: boolean } = {}) {
  const db = await getDb();
  if (!db) return undefined;
  const conditions = [eq(projects.slug, slug)];
  if (!opts.includeUnpublished) conditions.push(eq(projects.status, "published"));
  const r = await db.select().from(projects).where(and(...conditions)).limit(1);
  return r[0];
}

export async function getProjectById(id: number, opts: { includeUnpublished?: boolean } = {}) {
  const db = await getDb();
  if (!db) return undefined;
  const conditions = [eq(projects.id, id)];
  if (!opts.includeUnpublished) conditions.push(eq(projects.status, "published"));
  const r = await db.select().from(projects).where(and(...conditions)).limit(1);
  return r[0];
}

export async function createProject(data: InsertProject) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(projects).values(data);
}

export async function updateProject(id: number, data: Partial<InsertProject>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(projects).set({ ...data, updatedAt: new Date() }).where(eq(projects.id, id));
}

export async function deleteProject(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(projects).where(eq(projects.id, id));
}

// ─── Project Participation Requests ──────────────────────────────────────────
export async function listProjectParticipationRequests(opts: { page?: number; limit?: number; status?: string; projectId?: number; userId?: number; search?: string } = {}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const { page = 1, limit = 20, status, projectId, userId, search } = opts;
  const offset = (page - 1) * limit;
  const conditions = [];
  if (status) conditions.push(eq(projectParticipationRequests.status, status as any));
  if (projectId) conditions.push(eq(projectParticipationRequests.projectId, projectId));
  if (userId) conditions.push(eq(projectParticipationRequests.userId, userId));
  if (search) {
    const pattern = `%${search}%`;
    conditions.push(or(
      like(projectParticipationRequests.fullName, pattern),
      like(projectParticipationRequests.email, pattern),
      like(projectParticipationRequests.participationType, pattern),
      like(projectParticipationRequests.motivation, pattern),
    ));
  }
  const where = conditions.length ? and(...conditions) : undefined;
  const baseRows = await db.select().from(projectParticipationRequests).where(where).orderBy(desc(projectParticipationRequests.submittedAt)).limit(limit).offset(offset);
  const totalPromise = db.select({ count: sql<number>`count(*)` }).from(projectParticipationRequests).where(where);
  const projectIds = [...new Set(baseRows.map((row) => row.projectId))];
  const projectsById = new Map<number, typeof projects.$inferSelect | undefined>();
  await Promise.all(projectIds.map(async (id) => projectsById.set(id, await getProjectById(id, { includeUnpublished: true }))));
  const items = baseRows.map((row) => {
    const project = projectsById.get(row.projectId);
    return {
      ...row,
      projectTitle: project?.title ?? null,
      projectSlug: project?.slug ?? null,
      projectStatus: project?.status ?? null,
    };
  });
  const [{ count }] = await totalPromise;
  return { items, total: Number(count) };
}

export async function getProjectParticipationRequestById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(projectParticipationRequests).where(eq(projectParticipationRequests.id, id)).limit(1);
  return rows[0];
}

export async function getProjectParticipationRequestByUserAndProject(userId: number, projectId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(projectParticipationRequests).where(and(eq(projectParticipationRequests.userId, userId), eq(projectParticipationRequests.projectId, projectId))).limit(1);
  return rows[0];
}

export async function upsertProjectParticipationRequest(data: InsertProjectParticipationRequest) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const existing = await getProjectParticipationRequestByUserAndProject(data.userId!, data.projectId!);
  const now = new Date();

  if (existing) {
    await db.update(projectParticipationRequests).set({
      ...data,
      status: "pending",
      reviewedBy: null,
      reviewNote: null,
      reviewedAt: null,
      submittedAt: now,
      updatedAt: now,
    } as any).where(eq(projectParticipationRequests.id, existing.id));
    return existing.id;
  }

  const [inserted] = await db.insert(projectParticipationRequests).values({
    ...data,
    status: "pending",
    submittedAt: now,
    updatedAt: now,
  } as any).returning({ id: projectParticipationRequests.id });
  return inserted?.id ?? null;
}

export async function reviewProjectParticipationRequest(id: number, data: { status: "under_review" | "more_information_required" | "approved" | "rejected"; reviewNote?: string | null; reviewedBy?: number | null; reviewedAt?: Date }) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(projectParticipationRequests).set({
    ...data,
    updatedAt: new Date(),
  } as any).where(eq(projectParticipationRequests.id, id));
}

// ─── Knowledge ────────────────────────────────────────────────────────────────
export async function listKnowledge(opts: { page?: number; limit?: number; status?: string; search?: string } = {}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const { page = 1, limit = 12, status, search } = opts;
  const offset = (page - 1) * limit;
  const conditions = [];
  if (status) conditions.push(eq(knowledge.status, status as any));
  if (search) conditions.push(or(like(knowledge.title, `%${search}%`), like(knowledge.excerpt, `%${search}%`)));
  const where = conditions.length ? and(...conditions) : undefined;
  const [items, [{ count }]] = await Promise.all([
    db.select().from(knowledge).where(where).orderBy(desc(knowledge.createdAt)).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(knowledge).where(where),
  ]);
  return { items, total: Number(count) };
}

export async function getKnowledgeBySlug(slug: string, opts: { includeUnpublished?: boolean } = {}) {
  const db = await getDb();
  if (!db) return undefined;
  const conditions = [eq(knowledge.slug, slug)];
  if (!opts.includeUnpublished) conditions.push(eq(knowledge.status, "published"));
  const r = await db.select().from(knowledge).where(and(...conditions)).limit(1);
  return r[0];
}

export async function createKnowledge(data: InsertKnowledge) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(knowledge).values(data);
}

export async function updateKnowledge(id: number, data: Partial<InsertKnowledge>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(knowledge).set({ ...data, updatedAt: new Date() }).where(eq(knowledge.id, id));
}

export async function deleteKnowledge(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(knowledge).where(eq(knowledge.id, id));
}

// ─── Members ─────────────────────────────────────────────────────────────────
export async function listMembers(opts: { page?: number; limit?: number; status?: string; search?: string } = {}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const { page = 1, limit = 20, status, search } = opts;
  const offset = (page - 1) * limit;
  const conditions = [];
  if (status) conditions.push(eq(members.status, status as any));
  if (search) conditions.push(or(like(members.fullName, `%${search}%`), like(members.email, `%${search}%`)));
  const where = conditions.length ? and(...conditions) : undefined;
  const [items, [{ count }]] = await Promise.all([
    db.select().from(members).where(where).orderBy(desc(members.joinedAt)).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(members).where(where),
  ]);
  return { items, total: Number(count) };
}

export async function updateMember(id: number, data: Partial<InsertMember>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(members).set({ ...data, updatedAt: new Date() }).where(eq(members.id, id));
}

export async function getMemberByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(members).where(eq(members.email, email)).limit(1);
  return rows[0];
}

export async function createMember(data: InsertMember) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(members).values(data);
}

export async function deleteMember(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(members).where(eq(members.id, id));
}

// ─── Applications ─────────────────────────────────────────────────────────────
export async function listApplications(opts: { page?: number; limit?: number; status?: string } = {}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const { page = 1, limit = 20, status } = opts;
  const offset = (page - 1) * limit;
  const conditions = [];
  if (status) conditions.push(eq(applications.status, status as any));
  const where = conditions.length ? and(...conditions) : undefined;
  const [items, [{ count }]] = await Promise.all([
    db.select().from(applications).where(where).orderBy(desc(applications.submittedAt)).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(applications).where(where),
  ]);
  return { items, total: Number(count) };
}

export async function getApplicationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(applications).where(eq(applications.id, id)).limit(1);
  return rows[0];
}

export async function getActiveApplicationByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select({ id: applications.id, status: applications.status, applicantId: applications.applicantId })
    .from(applications)
    .where(
      and(
        sql`lower(${applications.email}) = lower(${email})`,
        inArray(applications.status, ["pending", "under_review", "more_information_required", "approved"]),
      ),
    )
    .orderBy(desc(applications.submittedAt))
    .limit(1);
  return rows[0];
}

export async function generateUniqueApplicantId(generate: () => string) {
  const db = await getDb();
  for (let i = 0; i < 10; i++) {
    const candidate = generate();
    if (!db) return candidate;
    const existing = await db.select({ id: applications.id }).from(applications).where(eq(applications.applicantId, candidate)).limit(1);
    if (!existing.length) return candidate;
  }
  throw new Error("تعذر توليد معرّف فريد للمتقدم");
}

/**
 * Thrown when an insert is rejected by the database-level
 * `applications_active_email_unique_idx` partial unique index (see
 * drizzle/0010_haraka967_active_application_email_unique.sql). This is the
 * race-safe backstop for the application-level `getActiveApplicationByEmail`
 * check in the `applications.submit` mutation: two concurrent submissions
 * for the same email can both pass that check, but only one insert can win
 * here.
 */
export class DuplicateActiveApplicationError extends Error {
  constructor() {
    super("Duplicate active application for this email");
    this.name = "DuplicateActiveApplicationError";
  }
}

/** Postgres SQLSTATE for unique_violation. */
const PG_UNIQUE_VIOLATION = "23505";

/**
 * Pure classifier for a Postgres error thrown by the `postgres` driver on
 * insert. Kept free of any DB connection so it can be unit-tested directly
 * with plain error-shaped objects, without a live database.
 */
export function isDuplicateActiveApplicationError(err: unknown): boolean {
  const code = (err as { code?: string } | null)?.code;
  const constraint =
    (err as { constraint_name?: string } | null)?.constraint_name ??
    (err as { constraint?: string } | null)?.constraint;
  return code === PG_UNIQUE_VIOLATION && constraint === "applications_active_email_unique_idx";
}

export async function createApplication(data: InsertApplication) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  try {
    await db.insert(applications).values(data);
  } catch (err) {
    if (isDuplicateActiveApplicationError(err)) {
      throw new DuplicateActiveApplicationError();
    }
    throw err;
  }
}

export async function updateApplication(id: number, data: Partial<InsertApplication>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(applications).set(data).where(eq(applications.id, id));
}

// ─── Map Points ───────────────────────────────────────────────────────────────
export async function listMapPoints(status?: string) {
  const db = await getDb();
  if (!db) return [];
  const where = status ? eq(mapPoints.status, status as any) : undefined;
  return db.select().from(mapPoints).where(where).orderBy(desc(mapPoints.createdAt));
}

export async function createMapPoint(data: InsertMapPoint) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(mapPoints).values(data);
}

export async function updateMapPoint(id: number, data: Partial<InsertMapPoint>) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(mapPoints).set({ ...data, updatedAt: new Date() }).where(eq(mapPoints.id, id));
}

export async function deleteMapPoint(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(mapPoints).where(eq(mapPoints.id, id));
}

// ─── Contact Messages ───────────────────────────────────────────────────────
export async function createContactMessage(data: InsertContactMessage) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(contactMessages).values(data);
}

// ─── Files ────────────────────────────────────────────────────────────────────
export async function listFiles(opts: { page?: number; limit?: number; folder?: string } = {}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const { page = 1, limit = 20, folder } = opts;
  const offset = (page - 1) * limit;
  const where = folder ? eq(files.folder, folder) : undefined;
  const [items, [{ count }]] = await Promise.all([
    db.select().from(files).where(where).orderBy(desc(files.createdAt)).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(files).where(where),
  ]);
  return { items, total: Number(count) };
}

export async function createFile(data: InsertFile) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(files).values(data);
}

export async function getFileByKey(fileKey: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(files).where(eq(files.fileKey, fileKey)).limit(1);
  return rows[0];
}

export async function deleteFile(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.delete(files).where(eq(files.id, id));
}

// ─── Notifications ────────────────────────────────────────────────────────────
export async function listNotifications(userId?: number, unreadOnly = false) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (userId) conditions.push(eq(notifications.userId, userId));
  if (unreadOnly) conditions.push(eq(notifications.read, false));
  const where = conditions.length ? and(...conditions) : undefined;
  return db.select().from(notifications).where(where).orderBy(desc(notifications.createdAt)).limit(50);
}

export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(notifications).values(data);
}

export async function markNotificationRead(id: number, userId?: number, role?: string) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  const conditions = [eq(notifications.id, id)];
  if (!["super_admin", "admin"].includes(role ?? "")) {
    if (!userId) throw new Error("Not authorized");
    conditions.push(eq(notifications.userId, userId));
  }
  await db.update(notifications).set({ read: true }).where(and(...conditions));
}

export async function markAllNotificationsRead(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(notifications).set({ read: true }).where(eq(notifications.userId, userId));
}

// ─── Audit Logs ───────────────────────────────────────────────────────────────
export async function createAuditLog(data: InsertAuditLog) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values(data);
}

export async function listAuditLogs(opts: { page?: number; limit?: number; userId?: number; entity?: string } = {}) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const { page = 1, limit = 50, userId, entity } = opts;
  const offset = (page - 1) * limit;
  const conditions = [];
  if (userId) conditions.push(eq(auditLogs.userId, userId));
  if (entity) conditions.push(eq(auditLogs.entity, entity));
  const where = conditions.length ? and(...conditions) : undefined;
  const [items, [{ count }]] = await Promise.all([
    db.select().from(auditLogs).where(where).orderBy(desc(auditLogs.createdAt)).limit(limit).offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(auditLogs).where(where),
  ]);
  return { items, total: Number(count) };
}

// ─── Site Settings ────────────────────────────────────────────────────────────
export async function getSettings() {
  return loadSiteSettings();
}

export async function updateSetting(key: string, value: string, updatedBy?: number) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.update(siteSettings).set({ value, updatedBy, updatedAt: new Date() }).where(eq(siteSettings.key, key));
  invalidateSiteSettingsCache();
}

// ─── Pages ────────────────────────────────────────────────────────────────────
export async function listPages() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pages).orderBy(desc(pages.updatedAt));
}

export async function getPageBySlug(slug: string, opts: { includeUnpublished?: boolean } = {}) {
  const db = await getDb();
  if (!db) return undefined;
  const conditions = [eq(pages.slug, slug)];
  if (!opts.includeUnpublished) conditions.push(eq(pages.status, "published"));
  const r = await db.select().from(pages).where(and(...conditions)).limit(1);
  return r[0];
}

export async function upsertPage(data: InsertPage) {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");
  await db.insert(pages).values(data).onConflictDoUpdate({
    target: pages.slug,
    set: {
      title: data.title,
      content: data.content,
      status: data.status,
      metaTitle: data.metaTitle,
      metaDescription: data.metaDescription,
      updatedBy: data.updatedBy,
      updatedAt: new Date(),
    },
  });
}

// ─── Global Search ────────────────────────────────────────────────────────────
export async function globalSearch(query: string) {
  const db = await getDb();
  if (!db) return { news: [], projects: [], knowledge: [] };
  const q = `%${query}%`;
  const [newsResults, projectResults, knowledgeResults] = await Promise.all([
    db.select().from(news).where(and(eq(news.status, "published"), or(like(news.title, q), like(news.excerpt, q)))).limit(5),
    db.select().from(projects).where(and(eq(projects.status, "published"), or(like(projects.title, q), like(projects.excerpt, q)))).limit(5),
    db.select().from(knowledge).where(and(eq(knowledge.status, "published"), or(like(knowledge.title, q), like(knowledge.excerpt, q)))).limit(5),
  ]);
  return { news: newsResults, projects: projectResults, knowledge: knowledgeResults };
}

// ─── Dashboard Stats ──────────────────────────────────────────────────────────
export async function getDashboardStats() {
  const db = await getDb();
  if (!db) return { members: 0, applications: 0, news: 0, projects: 0, knowledge: 0, mapPoints: 0 };
  const [
    [{ membersCount }],
    [{ applicationsCount }],
    [{ newsCount }],
    [{ projectsCount }],
    [{ knowledgeCount }],
    [{ mapCount }],
  ] = await Promise.all([
    db.select({ membersCount: sql<number>`count(*)` }).from(members),
    db.select({ applicationsCount: sql<number>`count(*)` }).from(applications).where(eq(applications.status, "pending")),
    db.select({ newsCount: sql<number>`count(*)` }).from(news).where(eq(news.status, "published")),
    db.select({ projectsCount: sql<number>`count(*)` }).from(projects).where(eq(projects.status, "published")),
    db.select({ knowledgeCount: sql<number>`count(*)` }).from(knowledge).where(eq(knowledge.status, "published")),
    db.select({ mapCount: sql<number>`count(*)` }).from(mapPoints).where(eq(mapPoints.status, "active")),
  ]);
  return {
    members: Number(membersCount),
    applications: Number(applicationsCount),
    news: Number(newsCount),
    projects: Number(projectsCount),
    knowledge: Number(knowledgeCount),
    mapPoints: Number(mapCount),
  };
}

/**
 * Object storage — S3 compatible (AWS S3, Cloudflare R2, MinIO, DigitalOcean…).
 *
 * Configure with S3_BUCKET / S3_REGION / S3_ACCESS_KEY_ID / S3_SECRET_ACCESS_KEY
 * and, for non-AWS providers, S3_ENDPOINT + S3_FORCE_PATH_STYLE=true.
 *
 * Public URLs are always returned as `/storage/{key}`, which the app proxies
 * through a short-lived signed URL so access control stays server side.
 */

import crypto from "node:crypto";
import {
  DeleteObjectCommand,
  GetObjectCommand,
  PutObjectCommand,
  S3Client,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { ENV, isStorageConfigured } from "./_core/env";

let client: S3Client | null = null;

function getClient(): S3Client {
  if (!isStorageConfigured()) {
    throw new Error(
      "Storage is not configured: set S3_BUCKET, S3_ACCESS_KEY_ID and S3_SECRET_ACCESS_KEY"
    );
  }
  client ??= new S3Client({
    region: ENV.s3.region,
    endpoint: ENV.s3.endpoint || undefined,
    forcePathStyle: ENV.s3.forcePathStyle || Boolean(ENV.s3.endpoint),
    credentials: {
      accessKeyId: ENV.s3.accessKeyId,
      secretAccessKey: ENV.s3.secretAccessKey,
    },
  });
  return client;
}

/** Strips leading slashes and any path traversal attempt. */
export function normalizeKey(relKey: string): string {
  return relKey
    .replace(/^\/+/, "")
    .split("/")
    .filter((segment) => segment && segment !== "." && segment !== "..")
    .join("/");
}

function appendHashSuffix(relKey: string): string {
  const hash = crypto.randomUUID().replace(/-/g, "").slice(0, 8);
  const lastDot = relKey.lastIndexOf(".");
  if (lastDot === -1) return `${relKey}_${hash}`;
  return `${relKey.slice(0, lastDot)}_${hash}${relKey.slice(lastDot)}`;
}

export async function storagePut(
  relKey: string,
  data: Buffer | Uint8Array | string,
  contentType = "application/octet-stream"
): Promise<{ key: string; url: string }> {
  const key = appendHashSuffix(normalizeKey(relKey));
  const body = typeof data === "string" ? Buffer.from(data) : Buffer.from(data);

  await getClient().send(
    new PutObjectCommand({
      Bucket: ENV.s3.bucket,
      Key: key,
      Body: body,
      ContentType: contentType,
    })
  );

  return { key, url: buildStorageUrl(key) };
}

/**
 * Builds the public URL the browser should load a stored file from.
 * Absolute (using PUBLIC_SERVER_URL) when the frontend and backend are on
 * different domains; falls back to a relative path for same-origin setups.
 */
function buildStorageUrl(key: string): string {
  return ENV.publicServerUrl ? `${ENV.publicServerUrl}/storage/${key}` : `/storage/${key}`;
}

export async function storageGetSignedUrl(
  relKey: string,
  expiresInSeconds = ENV.s3.signedUrlTtlSeconds
): Promise<string> {
  const key = normalizeKey(relKey);
  return getSignedUrl(
    getClient(),
    new GetObjectCommand({ Bucket: ENV.s3.bucket, Key: key }),
    { expiresIn: expiresInSeconds }
  );
}

export { isStorageConfigured };

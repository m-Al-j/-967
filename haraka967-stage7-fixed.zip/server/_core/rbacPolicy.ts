/**
 * Pure authorization policy for administrator management.
 * No I/O here on purpose: every rule below is unit-tested.
 */

import { roleRank, type Permission, type Role } from "./permissions";

export type ActorContext = {
  id: number;
  role: Role | string;
  permissions: ReadonlySet<Permission>;
  isActive?: boolean;
};

export type TargetContext = {
  id: number;
  role: Role | string;
};

export type PolicyResult = { allowed: true } | { allowed: false; reason: string };

const ok: PolicyResult = { allowed: true };
const deny = (reason: string): PolicyResult => ({ allowed: false, reason });

export function isSuperAdmin(actor: Pick<ActorContext, "role">): boolean {
  return actor.role === "super_admin";
}

export function canManageUsers(actor: ActorContext): boolean {
  return actor.permissions.has("users.manage");
}

/** An actor may only act on users strictly below their own rank (never on themselves). */
export function canActOnUser(actor: ActorContext, target: TargetContext): PolicyResult {
  if (!canManageUsers(actor)) return deny("غير مصرح لك بإدارة المسؤولين");
  if (actor.id === target.id) return deny("لا يمكنك تعديل حسابك من هذه الشاشة");
  if (isSuperAdmin(actor)) return ok;
  if (roleRank(target.role) >= roleRank(actor.role)) {
    return deny("لا يمكنك تعديل مستخدم بصلاحية مساوية أو أعلى من صلاحيتك");
  }
  return ok;
}

/** Assigning a role: never at or above your own rank, and only a super admin can mint super admins. */
export function canAssignRole(actor: ActorContext, nextRole: Role | string): PolicyResult {
  if (!canManageUsers(actor)) return deny("غير مصرح لك بتعيين الأدوار");
  if (nextRole === "super_admin" && !isSuperAdmin(actor)) {
    return deny("منح دور المدير الأعلى مسموح للمدير الأعلى فقط");
  }
  if (isSuperAdmin(actor)) return ok;
  if (roleRank(nextRole) >= roleRank(actor.role)) {
    return deny("لا يمكنك منح دور مساوٍ أو أعلى من دورك");
  }
  return ok;
}

/** You can only grant permissions you hold yourself. Denying is always allowed downward. */
export function canDelegatePermissions(
  actor: ActorContext,
  grants: readonly Permission[]
): PolicyResult {
  if (!canManageUsers(actor)) return deny("غير مصرح لك بتعديل الصلاحيات");
  if (isSuperAdmin(actor)) return ok;
  const missing = grants.filter((permission) => !actor.permissions.has(permission));
  if (missing.length > 0) {
    return deny(`لا يمكنك منح صلاحيات لا تملكها: ${missing.join(", ")}`);
  }
  return ok;
}

/** Editing what a *role* can do is a super-admin-only operation. */
export function canEditRolePermissions(actor: ActorContext, role: Role | string): PolicyResult {
  if (!isSuperAdmin(actor)) return deny("تعديل صلاحيات الأدوار مسموح للمدير الأعلى فقط");
  if (role === "super_admin") return deny("لا يمكن تقييد صلاحيات المدير الأعلى");
  return ok;
}

export function canToggleActive(actor: ActorContext, target: TargetContext): PolicyResult {
  return canActOnUser(actor, target);
}

/**
 * Pluggable rate limiter.
 *
 * The default store is in-memory (fine for a single instance). To run several
 * backend instances, implement `RateLimitStore` against Redis (or any shared
 * store) and call `setRateLimitStore(...)` once at boot — no call site changes.
 */

export type RateLimitResult = {
  limited: boolean;
  remaining: number;
  resetAt: number;
};

export interface RateLimitStore {
  hit(key: string, windowMs: number, limit: number): Promise<RateLimitResult>;
}

export class MemoryRateLimitStore implements RateLimitStore {
  private readonly hits = new Map<string, number[]>();
  private lastSweep = Date.now();

  async hit(key: string, windowMs: number, limit: number): Promise<RateLimitResult> {
    const now = Date.now();
    this.sweep(now, windowMs);

    const recent = (this.hits.get(key) ?? []).filter((at) => now - at < windowMs);
    if (recent.length >= limit) {
      this.hits.set(key, recent);
      return { limited: true, remaining: 0, resetAt: (recent[0] ?? now) + windowMs };
    }

    recent.push(now);
    this.hits.set(key, recent);
    return { limited: false, remaining: limit - recent.length, resetAt: now + windowMs };
  }

  private sweep(now: number, windowMs: number) {
    if (now - this.lastSweep < windowMs) return;
    this.lastSweep = now;
    for (const [key, timestamps] of this.hits) {
      const recent = timestamps.filter((at) => now - at < windowMs);
      if (recent.length === 0) this.hits.delete(key);
      else this.hits.set(key, recent);
    }
  }
}

let store: RateLimitStore = new MemoryRateLimitStore();

export function setRateLimitStore(next: RateLimitStore): void {
  store = next;
}

export function getRateLimitStore(): RateLimitStore {
  return store;
}

export type RateLimitRule = { name: string; windowMs: number; limit: number };

export const RATE_LIMITS = {
  login: { name: "login", windowMs: 15 * 60 * 1000, limit: 8 },
  uploadCv: { name: "upload:cv", windowMs: 15 * 60 * 1000, limit: 8 },
  uploadProjectImage: { name: "upload:project-image", windowMs: 15 * 60 * 1000, limit: 12 },
  uploadGeneric: { name: "upload:generic", windowMs: 15 * 60 * 1000, limit: 15 },
  applicationSubmit: { name: "application:submit", windowMs: 60 * 60 * 1000, limit: 5 },
  projectParticipationSubmit: { name: "project-participation:submit", windowMs: 60 * 60 * 1000, limit: 5 },
  contactSubmit: { name: "contact:submit", windowMs: 60 * 60 * 1000, limit: 5 },
} as const satisfies Record<string, RateLimitRule>;

export async function consumeRateLimit(rule: RateLimitRule, identifier: string): Promise<RateLimitResult> {
  return store.hit(`${rule.name}:${identifier}`, rule.windowMs, rule.limit);
}

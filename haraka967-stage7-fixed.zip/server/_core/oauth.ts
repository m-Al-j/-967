import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import crypto from "node:crypto";
import type { Express, Request, Response } from "express";
import * as db from "../db";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";
import { ENV } from "./env";
import { RATE_LIMITS, consumeRateLimit } from "./rateLimit";
import { checkPasswordPolicy, hashPassword, needsRehash, safeEqual, verifyPassword } from "./password";
import { getRequestIp } from "./requestIp";

function getJsonBody(req: Request): Record<string, unknown> {
  return typeof req.body === "object" && req.body && !Array.isArray(req.body)
    ? (req.body as Record<string, unknown>)
    : {};
}

function normalizeEmail(email: unknown): string {
  return typeof email === "string" ? email.trim().toLowerCase() : "";
}

const LOGIN_SESSION_MS = 1000 * 60 * 60 * 12;

async function isLoginRateLimited(req: Request, email: string): Promise<boolean> {
  const [byIp, byEmail] = await Promise.all([
    consumeRateLimit(RATE_LIMITS.login, `ip:${getRequestIp(req)}`),
    consumeRateLimit(RATE_LIMITS.login, `email:${email}`),
  ]);
  return byIp.limited || byEmail.limited;
}

async function bootstrapFirstSuperAdmin(email: string, password: string) {
  const policy = checkPasswordPolicy(password);
  if (!policy.valid) {
    throw new Error(`BOOTSTRAP_SUPER_ADMIN_PASSWORD رفضت: ${policy.reason}`);
  }
  const existing = await db.getUserByEmail(email);
  const passwordHash = hashPassword(password);
  if (existing) {
    await db.updateUserById(existing.id, {
      role: "super_admin",
      passwordHash,
      lastSignedIn: new Date(),
      loginMethod: "local",
    });
    return await db.getUserById(existing.id);
  }

  const created = await db.createLocalUser({
    openId: email,
    email,
    name: email.split("@")[0] || "super_admin",
    role: "super_admin",
    loginMethod: "local",
    passwordHash,
    lastSignedIn: new Date(),
  });
  return created;
}

export function registerOAuthRoutes(app: Express) {
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const body = getJsonBody(req);
      const email = normalizeEmail(body.email);
      const password = typeof body.password === "string" ? body.password : "";
      const remember = body.remember !== false;

      if (!email || !password) {
        res.status(400).json({ error: "البريد الإلكتروني وكلمة المرور مطلوبان" });
        return;
      }

      if (await isLoginRateLimited(req, email)) {
        res.status(429).json({ error: "تم تجاوز عدد محاولات تسجيل الدخول المسموح به مؤقتًا" });
        return;
      }

      const bootstrapEmail =
        ENV.bootstrapSuperAdminEmail.trim().toLowerCase() || ENV.ownerEmail.trim().toLowerCase();
      const bootstrapPassword = ENV.bootstrapSuperAdminPassword;

      let user = await db.getUserByEmail(email);

      if (!user) {
        const adminCount = await db.countAdminUsers();
        const bootstrapAllowed =
          ENV.allowBootstrapSuperAdmin &&
          adminCount === 0 &&
          Boolean(bootstrapEmail) &&
          Boolean(bootstrapPassword) &&
          email === bootstrapEmail &&
          safeEqual(password, bootstrapPassword);

        if (!bootstrapAllowed) {
          res.status(401).json({ error: "بيانات الدخول غير صحيحة" });
          return;
        }
        user = await bootstrapFirstSuperAdmin(email, password);
      } else {
        if (!user.passwordHash || !verifyPassword(password, user.passwordHash)) {
          res.status(401).json({ error: "بيانات الدخول غير صحيحة" });
          return;
        }
        if (user.isActive === false) {
          res.status(403).json({ error: "تم تعطيل هذا الحساب" });
          return;
        }
        if (needsRehash(user.passwordHash)) {
          await db.updateUserById(user.id, { passwordHash: hashPassword(password) });
        }
      }

      if (!user) {
        res.status(401).json({ error: "تعذر تسجيل الدخول" });
        return;
      }

      const sessionToken = await sdk.createSessionToken(user.openId, {
        name: user.name || user.email || email,
        expiresInMs: remember ? ONE_YEAR_MS : LOGIN_SESSION_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, {
        ...cookieOptions,
        maxAge: remember ? ONE_YEAR_MS : LOGIN_SESSION_MS,
      });

      await db.upsertUser({
        openId: user.openId,
        email: user.email ?? email,
        name: user.name ?? email.split("@")[0] ?? null,
        loginMethod: "local",
        lastSignedIn: new Date(),
        role: user.role,
      });

      res.json({
        success: true,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        },
      });
    } catch (error) {
      console.error("[Auth] Login failed", error);
      res.status(500).json({ error: "تعذر تسجيل الدخول" });
    }
  });

  app.post("/api/auth/logout", async (req: Request, res: Response) => {
    const cookieOptions = getSessionCookieOptions(req);
    res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    res.json({ success: true });
  });
}

/**
 * Password hashing — PBKDF2-HMAC-SHA512, OWASP-aligned parameters,
 * constant-time verification, and transparent rehashing on login when the
 * stored parameters are weaker than the current policy.
 */

import crypto from "node:crypto";

export const PBKDF2_ITERATIONS = 210_000;
const KEY_LENGTH = 64;
const DIGEST = "sha512";
const SALT_BYTES = 16;

export type PasswordPolicyResult = { valid: true } | { valid: false; reason: string };

/** Minimum policy: 10+ chars with letters and digits. */
export function checkPasswordPolicy(password: string): PasswordPolicyResult {
  if (password.length < 10) {
    return { valid: false, reason: "كلمة المرور يجب ألا تقل عن 10 أحرف" };
  }
  if (password.length > 256) {
    return { valid: false, reason: "كلمة المرور طويلة جداً" };
  }
  if (!/[A-Za-z\u0600-\u06FF]/.test(password) || !/\d/.test(password)) {
    return { valid: false, reason: "كلمة المرور يجب أن تحتوي على حروف وأرقام" };
  }
  return { valid: true };
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(SALT_BYTES).toString("hex");
  const hash = crypto
    .pbkdf2Sync(password, salt, PBKDF2_ITERATIONS, KEY_LENGTH, DIGEST)
    .toString("hex");
  return `pbkdf2-${DIGEST}$${PBKDF2_ITERATIONS}$${salt}$${hash}`;
}

/** Supports both the current sha512 format and the legacy sha256 one. */
export function verifyPassword(password: string, stored: string): boolean {
  const [scheme, iterationsRaw, salt, expected] = stored.split("$");
  if (!scheme || !iterationsRaw || !salt || !expected) return false;

  const digest = scheme === "pbkdf2-sha512" ? "sha512" : scheme === "pbkdf2" ? "sha256" : null;
  if (!digest) return false;

  const iterations = Number(iterationsRaw);
  if (!Number.isFinite(iterations) || iterations < 1000) return false;

  const keyLength = expected.length / 2;
  if (!Number.isInteger(keyLength) || keyLength < 16) return false;

  const hash = crypto.pbkdf2Sync(password, salt, iterations, keyLength, digest);
  const expectedBuffer = Buffer.from(expected, "hex");
  if (hash.length !== expectedBuffer.length) return false;
  return crypto.timingSafeEqual(hash, expectedBuffer);
}

/** True when a stored hash uses outdated parameters and should be upgraded. */
export function needsRehash(stored: string): boolean {
  const [scheme, iterationsRaw] = stored.split("$");
  return scheme !== `pbkdf2-${DIGEST}` || Number(iterationsRaw) < PBKDF2_ITERATIONS;
}

/** Constant-time comparison for non-hashed secrets (e.g. bootstrap password). */
export function safeEqual(a: string, b: string): boolean {
  const bufferA = Buffer.from(a);
  const bufferB = Buffer.from(b);
  if (bufferA.length !== bufferB.length) return false;
  return crypto.timingSafeEqual(bufferA, bufferB);
}

/**
 * Central RBAC definitions.
 *
 * Permissions are resolved at request time from:
 *   1. role defaults (code) OR role overrides stored in `role_permissions`
 *   2. per-user overrides stored in `user_permissions` (grant / deny)
 *
 * Everything except `super_admin` is fully editable from the admin panel,
 * with no code change and no redeploy.
 */

export const ALL_PERMISSIONS = [
  "content.read_unpublished",
  "content.manage",
  "news.manage",
  "projects.manage",
  "knowledge.manage",
  "pages.manage",
  "applications.read",
  "applications.review",
  "members.manage",
  "members.delete",
  "map.manage",
  "files.manage",
  "notifications.send",
  "audit.read",
  "settings.read_all",
  "settings.manage",
  "users.manage",
  "dashboard.read",
] as const;

export type Permission = (typeof ALL_PERMISSIONS)[number];

export const PERMISSION_LABELS: Record<Permission, string> = {
  "content.read_unpublished": "قراءة المحتوى غير المنشور",
  "content.manage": "إدارة المحتوى العام",
  "news.manage": "إدارة الأخبار",
  "projects.manage": "إدارة المشاريع",
  "knowledge.manage": "إدارة قاعدة المعرفة",
  "pages.manage": "إدارة الصفحات",
  "applications.read": "عرض طلبات الانضمام",
  "applications.review": "مراجعة الطلبات (قبول/رفض)",
  "members.manage": "إدارة الأعضاء",
  "members.delete": "حذف الأعضاء",
  "map.manage": "إدارة الخريطة",
  "files.manage": "إدارة الملفات",
  "notifications.send": "إرسال الإشعارات",
  "audit.read": "قراءة سجل التدقيق",
  "settings.read_all": "قراءة كل الإعدادات",
  "settings.manage": "تعديل الإعدادات",
  "users.manage": "إدارة المسؤولين والصلاحيات",
  "dashboard.read": "الدخول إلى لوحة الإدارة",
};

export const ROLES = [
  "super_admin",
  "admin",
  "content_manager",
  "project_manager",
  "membership_manager",
  "map_manager",
  "knowledge_manager",
  "analyst",
  "member",
] as const;

export type Role = (typeof ROLES)[number];

export const ROLE_LABELS: Record<Role, string> = {
  super_admin: "مدير أعلى",
  admin: "مدير",
  content_manager: "مسؤول المحتوى",
  project_manager: "مسؤول المشاريع",
  membership_manager: "مسؤول العضويات",
  map_manager: "مسؤول الخريطة",
  knowledge_manager: "مسؤول المعرفة",
  analyst: "محلل",
  member: "عضو",
};

/** Higher rank = more authority. Used to block privilege escalation. */
export const ROLE_RANK: Record<Role, number> = {
  super_admin: 100,
  admin: 80,
  content_manager: 50,
  project_manager: 50,
  membership_manager: 50,
  map_manager: 40,
  knowledge_manager: 40,
  analyst: 30,
  member: 10,
};

export function isRole(value: unknown): value is Role {
  return typeof value === "string" && (ROLES as readonly string[]).includes(value);
}

export function isPermission(value: unknown): value is Permission {
  return typeof value === "string" && (ALL_PERMISSIONS as readonly string[]).includes(value);
}

export function roleRank(role?: string | null): number {
  return isRole(role) ? ROLE_RANK[role] : 0;
}

/** Built-in defaults, used whenever a role has no rows in `role_permissions`. */
export const ROLE_DEFAULT_PERMISSIONS: Record<Role, readonly Permission[]> = {
  super_admin: [...ALL_PERMISSIONS],
  admin: [...ALL_PERMISSIONS],
  content_manager: [
    "content.read_unpublished",
    "content.manage",
    "news.manage",
    "projects.manage",
    "knowledge.manage",
    "pages.manage",
    "notifications.send",
    "audit.read",
    "dashboard.read",
  ],
  project_manager: [
    "content.read_unpublished",
    "projects.manage",
    "map.manage",
    "notifications.send",
    "dashboard.read",
  ],
  membership_manager: [
    "applications.read",
    "applications.review",
      "members.manage",
    "notifications.send",
    "dashboard.read",
  ],
  map_manager: ["map.manage", "dashboard.read"],
  knowledge_manager: ["content.read_unpublished", "knowledge.manage", "dashboard.read"],
  analyst: ["applications.read", "audit.read", "dashboard.read"],
  member: [],
};

export type PermissionOverride = { permission: Permission; effect: "grant" | "deny" };

/**
 * Pure resolution: role base set (overrides or defaults) + per-user overrides.
 * `super_admin` always keeps every permission — it can never be locked out.
 */
export function resolvePermissionSet(input: {
  role?: string | null;
  roleOverrides?: readonly Permission[] | null;
  userOverrides?: readonly PermissionOverride[] | null;
}): Set<Permission> {
  const role = isRole(input.role) ? input.role : "member";
  if (role === "super_admin") return new Set(ALL_PERMISSIONS);

  const base =
    input.roleOverrides && input.roleOverrides.length > 0
      ? input.roleOverrides
      : ROLE_DEFAULT_PERMISSIONS[role];

  const set = new Set<Permission>(base);
  for (const override of input.userOverrides ?? []) {
    if (!isPermission(override.permission)) continue;
    if (override.effect === "grant") set.add(override.permission);
    else set.delete(override.permission);
  }
  return set;
}

export function hasAdminAccess(permissions: ReadonlySet<Permission>): boolean {
  return permissions.has("dashboard.read") || permissions.has("content.manage");
}

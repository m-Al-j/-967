import type { CookieOptions, Request } from "express";
import { ENV } from "./env";

function isSecureRequest(req: Request) {
  if (req.protocol === "https") return true;

  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;

  const protoList = Array.isArray(forwardedProto)
    ? forwardedProto
    : forwardedProto.split(",");

  return protoList.some(proto => proto.trim().toLowerCase() === "https");
}

export function getSessionCookieOptions(
  req: Request
): Pick<CookieOptions, "domain" | "httpOnly" | "path" | "sameSite" | "secure"> {
  // When the frontend and backend live on different domains (e.g. Cloudflare
  // Pages + Railway/Render), the auth cookie is sent cross-site, so it must
  // use SameSite=None + Secure. Same-origin setups keep the stricter "lax".
  const isCrossSiteDeployment = ENV.allowedOrigins.length > 0;
  const secure = isSecureRequest(req);

  return {
    httpOnly: true,
    path: "/",
    sameSite: isCrossSiteDeployment && secure ? "none" : "lax",
    secure,
  };
}

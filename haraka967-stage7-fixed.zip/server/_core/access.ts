/**
 * Runtime permission resolution (DB backed, cached).
 *
 * Reads role overrides + per-user overrides from PostgreSQL so a super admin
 * can change what any administrator may do from the admin panel — instantly,
 * without touching code or redeploying.
 */

import * as db from "../db";
import {
  resolvePermissionSet,
  type Permission,
  type PermissionOverride,
} from "./permissions";

const CACHE_TTL_MS = 15_000;

type CacheEntry<T> = { value: T; fetchedAt: number };

const roleCache = new Map<string, CacheEntry<Permission[]>>();
const userCache = new Map<number, CacheEntry<PermissionOverride[]>>();

export function invalidatePermissionCache(scope?: { role?: string; userId?: number }): void {
  if (!scope) {
    roleCache.clear();
    userCache.clear();
    return;
  }
  if (scope.role) roleCache.delete(scope.role);
  if (typeof scope.userId === "number") userCache.delete(scope.userId);
}

async function getRoleOverrides(role: string): Promise<Permission[]> {
  const cached = roleCache.get(role);
  if (cached && Date.now() - cached.fetchedAt < CACHE_TTL_MS) return cached.value;
  const value = await db.listRolePermissions(role);
  roleCache.set(role, { value, fetchedAt: Date.now() });
  return value;
}

async function getUserOverrides(userId: number): Promise<PermissionOverride[]> {
  const cached = userCache.get(userId);
  if (cached && Date.now() - cached.fetchedAt < CACHE_TTL_MS) return cached.value;
  const value = await db.listUserPermissionOverrides(userId);
  userCache.set(userId, { value, fetchedAt: Date.now() });
  return value;
}

export type PermissionSubject = { id: number; role: string | null };

export async function resolvePermissionsFor(
  user: PermissionSubject | null | undefined
): Promise<Set<Permission>> {
  if (!user) return new Set<Permission>();
  if (user.role === "super_admin") return resolvePermissionSet({ role: "super_admin" });

  const [roleOverrides, userOverrides] = await Promise.all([
    getRoleOverrides(user.role ?? "member"),
    getUserOverrides(user.id),
  ]);

  return resolvePermissionSet({
    role: user.role,
    roleOverrides,
    userOverrides,
  });
}

export async function userCanAny(
  user: PermissionSubject | null | undefined,
  permissions: readonly Permission[]
): Promise<boolean> {
  const resolved = await resolvePermissionsFor(user);
  return permissions.some((permission) => resolved.has(permission));
}

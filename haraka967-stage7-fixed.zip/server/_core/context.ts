import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { resolvePermissionsFor } from "./access";
import type { Permission } from "./permissions";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  permissions: ReadonlySet<Permission>;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch {
    // Authentication is optional for public procedures.
    user = null;
  }

  const permissions = user && user.isActive !== false
    ? await resolvePermissionsFor(user)
    : new Set<Permission>();

  return {
    req: opts.req,
    res: opts.res,
    user,
    permissions,
  };
}

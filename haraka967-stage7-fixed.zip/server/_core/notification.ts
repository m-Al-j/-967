/**
 * Outgoing email / owner notifications over standard SMTP (Nodemailer).
 * Configure SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_PASSWORD, SMTP_FROM.
 */

import { TRPCError } from "@trpc/server";
import nodemailer, { type Transporter } from "nodemailer";
import { ENV, isEmailConfigured } from "./env";

export type NotificationPayload = {
  title: string;
  content: string;
  /** Optional explicit recipient; defaults to the owner / join-requests inbox. */
  to?: string;
  html?: string;
};

const TITLE_MAX_LENGTH = 1200;
const CONTENT_MAX_LENGTH = 20000;

const isNonEmptyString = (value: unknown): value is string =>
  typeof value === "string" && value.trim().length > 0;

let transporter: Transporter | null = null;

function getTransporter(): Transporter {
  transporter ??= nodemailer.createTransport({
    host: ENV.smtp.host,
    port: ENV.smtp.port,
    secure: ENV.smtp.secure,
    auth: ENV.smtp.user ? { user: ENV.smtp.user, pass: ENV.smtp.password } : undefined,
  });
  return transporter;
}

function validatePayload(input: NotificationPayload): NotificationPayload {
  if (!isNonEmptyString(input.title)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Notification title is required." });
  }
  if (!isNonEmptyString(input.content)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Notification content is required." });
  }

  const title = input.title.trim();
  const content = input.content.trim();

  if (title.length > TITLE_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification title must be at most ${TITLE_MAX_LENGTH} characters.`,
    });
  }
  if (content.length > CONTENT_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification content must be at most ${CONTENT_MAX_LENGTH} characters.`,
    });
  }

  return { ...input, title, content };
}

export async function sendEmail(options: {
  to: string;
  subject: string;
  text: string;
  html?: string;
}): Promise<boolean> {
  if (!isEmailConfigured()) {
    console.warn("[Email] SMTP is not configured; skipping send to", options.to);
    return false;
  }
  try {
    await getTransporter().sendMail({
      from: ENV.smtp.from,
      to: options.to,
      subject: options.subject,
      text: options.text,
      html: options.html,
    });
    return true;
  } catch (error) {
    console.warn("[Email] Failed to send:", error);
    return false;
  }
}

/**
 * Notifies the site owner. Returns `true` when the message was accepted,
 * `false` when email is unavailable — callers must not treat this as fatal.
 */
export async function notifyOwner(payload: NotificationPayload): Promise<boolean> {
  const { title, content, to, html } = validatePayload(payload);
  const recipient = to || ENV.joinRequestsEmail || ENV.ownerEmail;

  if (!recipient) {
    console.warn("[Notification] No owner recipient configured; skipping notification.");
    return false;
  }

  return sendEmail({ to: recipient, subject: title, text: content, html });
}

import type { Request } from "express";

/**
 * Single source of truth for resolving a request's client IP for use in
 * rate limiting and auditing.
 *
 * We deliberately do NOT parse "x-forwarded-for" ourselves anywhere in the
 * codebase. Express already resolves `req.ip` correctly according to the
 * configured `app.set("trust proxy", N)` policy (see server/_core/index.ts),
 * which only trusts the number of proxy hops we actually have in front of
 * the app. Reading the raw header directly — as opposed to `req.ip` — lets
 * a client set an arbitrary "X-Forwarded-For" value and rotate it on every
 * request to bypass per-IP rate limits (login brute-force, application
 * spam, upload abuse, etc).
 *
 * Every place in the codebase that needs "the client's IP" must call this
 * function instead of reading `req.headers["x-forwarded-for"]` directly.
 */
export function getRequestIp(req: Pick<Request, "ip" | "socket">): string {
  return req.ip || req.socket?.remoteAddress || "unknown";
}

import "dotenv/config";
import multer from "multer";
import { storagePut } from "../storage";
import { createFile } from "../db";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { nanoid } from "nanoid";
import { sdk } from "./sdk";
import { userCanAny } from "./access";
import { assertRequiredEnv, ENV } from "./env";
import { RATE_LIMITS, consumeRateLimit } from "./rateLimit";
import { getRequestIp } from "./requestIp";

const CV_MAX_UPLOAD_SIZE_BYTES = 10 * 1024 * 1024;
const PROJECT_IMAGE_MAX_UPLOAD_SIZE_BYTES = 5 * 1024 * 1024;
const GENERIC_MAX_UPLOAD_SIZE_BYTES = 10 * 1024 * 1024;

const CV_ALLOWED_UPLOAD_MIME_TYPES = new Set([
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
]);

const PROJECT_IMAGE_ALLOWED_UPLOAD_MIME_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
]);

const GENERIC_ALLOWED_UPLOAD_MIME_TYPES = new Set([
  ...CV_ALLOWED_UPLOAD_MIME_TYPES,
  ...PROJECT_IMAGE_ALLOWED_UPLOAD_MIME_TYPES,
]);

function hasValidFileSignature(buffer: Buffer, mimeType: string): boolean {
  if (mimeType === "application/pdf") {
    return buffer.subarray(0, 5).toString("ascii") === "%PDF-";
  }
  if (mimeType === "application/msword") {
    return buffer.subarray(0, 8).equals(Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]));
  }
  if (mimeType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
    return buffer.subarray(0, 4).equals(Buffer.from([0x50, 0x4b, 0x03, 0x04]));
  }
  if (mimeType === "image/jpeg") {
    return buffer.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff]));
  }
  if (mimeType === "image/png") {
    return buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  }
  if (mimeType === "image/webp") {
    return buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WEBP";
  }
  return false;
}

const UPLOAD_EXTENSIONS: Record<string, string> = {
  "application/pdf": "pdf",
  "application/msword": "doc",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
};

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: GENERIC_MAX_UPLOAD_SIZE_BYTES } });

const UPLOAD_RULES = {
  cv: RATE_LIMITS.uploadCv,
  "project-image": RATE_LIMITS.uploadProjectImage,
  generic: RATE_LIMITS.uploadGeneric,
} as const;

/**
 * CSRF guard for endpoints that accept a "simple" content type
 * (multipart/form-data, urlencoded, text/plain). Unlike our JSON tRPC
 * mutations — which browsers can only send cross-site via fetch/XHR and are
 * therefore already blocked by CORS — a plain HTML <form> can POST these
 * content types cross-site without a preflight check, carrying the session
 * cookie along with it. We verify the browser-supplied Origin header
 * ourselves before touching the session.
 */
function isTrustedOrigin(req: express.Request): boolean {
  const origin = req.headers.origin;
  if (!origin) return true; // no Origin header: not a cross-site browser request
  if (ENV.allowedOrigins.length > 0) return ENV.allowedOrigins.includes(origin);
  try {
    return new URL(origin).host === req.headers.host;
  } catch {
    return false;
  }
}

async function isUploadRateLimited(req: express.Request, purpose: keyof typeof UPLOAD_RULES): Promise<boolean> {
  const rule = UPLOAD_RULES[purpose] ?? RATE_LIMITS.uploadGeneric;
  const { limited } = await consumeRateLimit(rule, getRequestIp(req));
  return limited;
}

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  assertRequiredEnv();

  const app = express();
  app.set("trust proxy", 1);
  app.disable("x-powered-by");
  const server = createServer(app);

  // Lightweight health/readiness endpoint for VPS/load balancers.
  // It deliberately avoids exposing secrets or database details.
  app.get("/healthz", (_req, res) => {
    res.status(200).json({ ok: true, service: "haraka967" });
  });

  app.use((_, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
    res.setHeader("Cross-Origin-Resource-Policy", ENV.allowedOrigins.length > 0 ? "cross-origin" : "same-site");
    next();
  });

  // ─── CORS (only needed when the frontend is on a different origin) ────────
  // Set ALLOWED_ORIGIN to the exact frontend origin(s), comma separated,
  // e.g. https://haraka967.pages.dev,https://www.haraka967.org
  if (ENV.allowedOrigins.length > 0) {
    app.use((req, res, next) => {
      const origin = req.headers.origin;
      if (origin && ENV.allowedOrigins.includes(origin)) {
        res.setHeader("Access-Control-Allow-Origin", origin);
        res.setHeader("Access-Control-Allow-Credentials", "true");
        res.setHeader("Vary", "Origin");
      }
      if (req.method === "OPTIONS") {
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
        res.setHeader(
          "Access-Control-Allow-Headers",
          req.headers["access-control-request-headers"] || "Content-Type, Authorization"
        );
        res.setHeader("Access-Control-Max-Age", "86400");
        res.status(204).end();
        return;
      }
      next();
    });
  }

  // File uploads use multer with their own limits. Keep JSON/form bodies
  // deliberately small so an unauthenticated request cannot consume large
  // amounts of memory before reaching application-level validation.
  app.use(express.json({ limit: "2mb" }));
  app.use(express.urlencoded({ limit: "2mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);

  // ─── File Upload Route ─────────────────────────────────────────────────────
  app.post("/api/files/upload", upload.single("file"), async (req, res) => {
    try {
      if (!isTrustedOrigin(req)) {
        res.status(403).json({ error: "طلب مرفوض: مصدر غير موثوق" });
        return;
      }

      const file = req.file;
      if (!file) {
        res.status(400).json({ error: "لم يتم إرسال أي ملف" });
        return;
      }

      const purposeRaw = typeof req.body?.purpose === "string" ? req.body.purpose.trim() : "generic";
      const purpose = (["cv", "project-image", "generic"] as const).includes(purposeRaw as never)
        ? (purposeRaw as "cv" | "project-image" | "generic")
        : "generic";

      let currentUser = null as Awaited<ReturnType<typeof sdk.authenticateRequest>> | null;
      try {
        currentUser = await sdk.authenticateRequest(req as any);
      } catch {
        currentUser = null;
      }

      const requiresAuth = purpose !== "cv";
      if (requiresAuth && !currentUser) {
        res.status(401).json({ error: "يجب تسجيل الدخول لرفع هذا الملف" });
        return;
      }

      if (requiresAuth && currentUser) {
        const canUpload = await userCanAny(
          currentUser,
          purpose === "project-image"
            ? ["projects.manage", "content.manage"]
            : ["files.manage", "content.manage"]
        );
        if (!canUpload) {
          res.status(403).json({ error: purpose === "project-image" ? "غير مصرح لك برفع صورة المشروع" : "غير مصرح لك برفع هذا الملف" });
          return;
        }
      }

      if (await isUploadRateLimited(req, purpose)) {
        res.status(429).json({ error: "تم تجاوز عدد المحاولات المسموح به مؤقتًا" });
        return;
      }

      const allowedMimeTypes =
        purpose === "cv"
          ? CV_ALLOWED_UPLOAD_MIME_TYPES
          : purpose === "project-image"
            ? PROJECT_IMAGE_ALLOWED_UPLOAD_MIME_TYPES
            : GENERIC_ALLOWED_UPLOAD_MIME_TYPES;

      const maxSizeBytes =
        purpose === "cv"
          ? CV_MAX_UPLOAD_SIZE_BYTES
          : purpose === "project-image"
            ? PROJECT_IMAGE_MAX_UPLOAD_SIZE_BYTES
            : GENERIC_MAX_UPLOAD_SIZE_BYTES;

      if (!allowedMimeTypes.has(file.mimetype)) {
        res.status(400).json({ error: "نوع الملف غير مدعوم" });
        return;
      }

      if (file.size > maxSizeBytes) {
        res.status(400).json({ error: "حجم الملف أكبر من الحد المسموح" });
        return;
      }

      // Never trust the browser-provided MIME type alone. Validate the file
      // signature before storing attacker-controlled bytes.
      if (!hasValidFileSignature(file.buffer, file.mimetype)) {
        res.status(400).json({ error: "محتوى الملف لا يطابق نوعه المعلن" });
        return;
      }

      const safeExt = UPLOAD_EXTENSIONS[file.mimetype];
      if (!safeExt) {
        res.status(400).json({ error: "نوع الملف غير مدعوم" });
        return;
      }

      const folder = purpose === "cv" ? "applications/cv" : purpose === "project-image" ? "projects/images" : "uploads";
      const fileKey = `${folder}/${nanoid()}.${safeExt}`;
      const { key, url } = await storagePut(fileKey, file.buffer, file.mimetype);
      await createFile({
        filename: fileKey,
        originalName: file.originalname,
        mimeType: file.mimetype,
        size: file.size,
        url,
        fileKey: key,
        folder,
        uploadedBy: currentUser?.id ?? null,
      });
      res.json({ success: true, url, key, originalName: file.originalname, purpose });
    } catch (err: any) {
      console.error("[Upload]", err);
      res.status(500).json({ error: err.message ?? "خطأ في الرفع" });
    }
  });

  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  const shutdown = (signal: string) => {
    console.log(`[Server] ${signal} received; shutting down gracefully`);
    server.close((error) => {
      if (error) {
        console.error("[Server] Shutdown failed:", error);
        process.exitCode = 1;
      }
      process.exit();
    });
  };

  process.once("SIGTERM", () => shutdown("SIGTERM"));
  process.once("SIGINT", () => shutdown("SIGINT"));

  // Keep unexpected API failures from leaking HTML stack traces or internal
  // error details to clients. tRPC handles its own errors before this point.
  app.use((error: unknown, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (res.headersSent) {
      next(error);
      return;
    }
    console.error(`[HTTP] ${req.method} ${req.path} failed`, error);
    if (req.path.startsWith("/api/")) {
      res.status(500).json({ error: "حدث خطأ داخلي في الخادم" });
      return;
    }
    next(error);
  });
}

startServer().catch((error) => {
  console.error("[Server] Fatal startup error:", error);
  process.exitCode = 1;
});

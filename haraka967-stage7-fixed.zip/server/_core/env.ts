/**
 * All runtime configuration comes from environment variables.
 * Never hard-code secrets, keys or credentials in the codebase.
 * See .env.example for the full list.
 */

const str = (value: string | undefined, fallback = ""): string => (value ?? fallback).trim();
const num = (value: string | undefined, fallback: number): number => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};
const bool = (value: string | undefined, fallback = false): boolean => {
  if (value === undefined) return fallback;
  return ["1", "true", "yes", "on"].includes(value.trim().toLowerCase());
};

export const ENV = {
  appId: str(process.env.VITE_APP_ID, "haraka967"),
  isProduction: process.env.NODE_ENV === "production",

  // Auth
  cookieSecret: str(process.env.JWT_SECRET),
  ownerOpenId: str(process.env.OWNER_OPEN_ID),
  ownerEmail: str(process.env.OWNER_EMAIL),
  joinRequestsEmail: str(process.env.JOIN_REQUESTS_EMAIL),
  bootstrapSuperAdminEmail: str(process.env.BOOTSTRAP_SUPER_ADMIN_EMAIL),
  bootstrapSuperAdminPassword: process.env.BOOTSTRAP_SUPER_ADMIN_PASSWORD ?? "",
  allowBootstrapSuperAdmin: bool(process.env.ALLOW_BOOTSTRAP_SUPER_ADMIN, false),

  // Public URL of THIS backend, used to build absolute /storage/* links.
  // Required when the frontend is deployed on a different domain
  // (e.g. Cloudflare Pages) than this backend (e.g. Railway/Render).
  // Example: https://haraka967-api.onrender.com  (no trailing slash)
  publicServerUrl: str(process.env.PUBLIC_SERVER_URL).replace(/\/+$/, ""),

  // Origin(s) allowed to call this API with credentials (comma separated).
  // Example: https://haraka967.pages.dev,https://www.haraka967.org
  allowedOrigins: str(process.env.ALLOWED_ORIGIN)
    .split(",")
    .map(s => s.trim())
    .filter(Boolean),

  // Database
  databaseUrl: str(process.env.DATABASE_URL),
  databasePoolMax: num(process.env.DATABASE_POOL_MAX, 10),

  // Object storage (S3 compatible: AWS S3, Cloudflare R2, MinIO, Supabase Storage S3…)
  s3: {
    bucket: str(process.env.S3_BUCKET),
    region: str(process.env.S3_REGION, "us-east-1"),
    accessKeyId: str(process.env.S3_ACCESS_KEY_ID),
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY ?? "",
    endpoint: str(process.env.S3_ENDPOINT),
    forcePathStyle: bool(process.env.S3_FORCE_PATH_STYLE, false),
    signedUrlTtlSeconds: num(process.env.S3_SIGNED_URL_TTL_SECONDS, 300),
  },

  // Email (SMTP)
  smtp: {
    host: str(process.env.SMTP_HOST),
    port: num(process.env.SMTP_PORT, 587),
    secure: bool(process.env.SMTP_SECURE, false),
    user: str(process.env.SMTP_USER),
    password: process.env.SMTP_PASSWORD ?? "",
    from: str(process.env.SMTP_FROM),
  },

  // Google Maps (server side geocoding / places)
  googleMapsApiKey: process.env.GOOGLE_MAPS_API_KEY ?? "",

  // Rate limiting
  rateLimitRedisUrl: str(process.env.RATE_LIMIT_REDIS_URL),
} as const;

export const isStorageConfigured = (): boolean =>
  Boolean(ENV.s3.bucket && ENV.s3.accessKeyId && ENV.s3.secretAccessKey);

export const isEmailConfigured = (): boolean => Boolean(ENV.smtp.host && ENV.smtp.from);


/** Fails fast on boot in production when a mandatory secret is missing. */
export function assertRequiredEnv(): void {
  const missing: string[] = [];
  if (!ENV.cookieSecret || ENV.cookieSecret.length < 32) missing.push("JWT_SECRET (32+ chars)");
  if (!ENV.databaseUrl) missing.push("DATABASE_URL");
  if (missing.length === 0) return;

  const message = `Missing required environment variables: ${missing.join(", ")}`;
  if (ENV.isProduction) throw new Error(message);
  console.warn(`[ENV] ${message}`);
}

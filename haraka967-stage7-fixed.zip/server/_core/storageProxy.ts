import type { Express, Request } from "express";
import * as db from "../db";
import { userCanAny } from "./access";
import { isStorageConfigured, storageGetSignedUrl } from "../storage";
import { sdk } from "./sdk";

const SENSITIVE_FOLDERS = new Set(["applications/cv"]);

export function registerStorageProxy(app: Express) {
  app.get("/storage/*", async (req, res) => {
    const rawKey = (req.params as Record<string, string>)[0];
    const key = rawKey?.replace(/^\/+/, "");
    if (!key || key.includes("..")) {
      res.status(400).send("Invalid storage key");
      return;
    }

    const file = await db.getFileByKey(key);
    if (!file) {
      res.status(404).send("File not found");
      return;
    }

    if (SENSITIVE_FOLDERS.has(file.folder ?? "")) {
      let currentUser = null;
      try {
        currentUser = await sdk.authenticateRequest(req as Request);
      } catch {
        currentUser = null;
      }

      const isOwner = Boolean(currentUser && currentUser.id === file.uploadedBy);
      const isAllowed =
        isOwner ||
        (currentUser
          ? await userCanAny(currentUser, [
              "files.manage",
              "applications.review",
              "members.manage",
            ])
          : false);

      if (!isAllowed) {
        res.status(403).send("Forbidden");
        return;
      }
    }

    if (!isStorageConfigured()) {
      res.status(500).send("Storage is not configured");
      return;
    }

    try {
      const url = await storageGetSignedUrl(key);
      res.set("Cache-Control", "no-store");
      res.redirect(307, url);
    } catch (err) {
      console.error("[StorageProxy] failed:", err);
      res.status(502).send("Storage error");
    }
  });
}

import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from "@shared/const";
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";
import { hasAdminAccess as hasAdminAccessFor, type Permission } from "./permissions";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export {
  ALL_PERMISSIONS,
  PERMISSION_LABELS,
  ROLES,
  ROLE_LABELS,
  ROLE_DEFAULT_PERMISSIONS,
  type Permission,
} from "./permissions";

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async ({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }
  if (ctx.user.isActive === false) {
    throw new TRPCError({ code: "FORBIDDEN", message: "تم تعطيل هذا الحساب" });
  }
  return next({ ctx: { ...ctx, user: ctx.user } });
});

export const protectedProcedure = t.procedure.use(requireUser);

/** Server-side permission gate — the single source of truth for authorization. */
export function requirePermission(permission: Permission) {
  return t.middleware(async ({ ctx, next }) => {
    if (!ctx.user) {
      throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
    }
    if (ctx.user.isActive === false) {
      throw new TRPCError({ code: "FORBIDDEN", message: "تم تعطيل هذا الحساب" });
    }
    if (!ctx.permissions.has(permission)) {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }
    return next({ ctx: { ...ctx, user: ctx.user } });
  });
}

export const adminProcedure = protectedProcedure.use(requirePermission("dashboard.read"));

export function hasAdminAccess(permissions: ReadonlySet<Permission>): boolean {
  return hasAdminAccessFor(permissions);
}

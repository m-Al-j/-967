import { describe, expect, it } from "vitest";
import { isDuplicateActiveApplicationError } from "./db";

describe("isDuplicateActiveApplicationError", () => {
  it("recognizes a Postgres unique_violation on the active-email index (constraint_name)", () => {
    const pgError = {
      code: "23505",
      constraint_name: "applications_active_email_unique_idx",
      message: 'duplicate key value violates unique constraint "applications_active_email_unique_idx"',
    };
    expect(isDuplicateActiveApplicationError(pgError)).toBe(true);
  });

  it("recognizes the same violation when the driver exposes `constraint` instead of `constraint_name`", () => {
    const pgError = {
      code: "23505",
      constraint: "applications_active_email_unique_idx",
    };
    expect(isDuplicateActiveApplicationError(pgError)).toBe(true);
  });

  it("ignores unique_violation errors from a different constraint", () => {
    const pgError = {
      code: "23505",
      constraint_name: "applications_applicant_id_unique",
    };
    expect(isDuplicateActiveApplicationError(pgError)).toBe(false);
  });

  it("ignores non-unique-violation Postgres errors", () => {
    const pgError = {
      code: "23502", // not_null_violation
      constraint_name: "applications_active_email_unique_idx",
    };
    expect(isDuplicateActiveApplicationError(pgError)).toBe(false);
  });

  it("ignores plain JS errors, null, and non-object values", () => {
    expect(isDuplicateActiveApplicationError(new Error("boom"))).toBe(false);
    expect(isDuplicateActiveApplicationError(null)).toBe(false);
    expect(isDuplicateActiveApplicationError(undefined)).toBe(false);
    expect(isDuplicateActiveApplicationError("some string")).toBe(false);
    expect(isDuplicateActiveApplicationError(42)).toBe(false);
  });
});

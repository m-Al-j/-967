import { describe, expect, it } from "vitest";
import { resolvePermissionSet, ROLE_RANK } from "./_core/permissions";
import { canActOnUser, canAssignRole } from "./_core/rbacPolicy";
import { hashPassword, verifyPassword, checkPasswordPolicy } from "./_core/password";

describe("permissions", () => {
  it("gives super admin every permission", () => {
    const set = resolvePermissionSet({ role: "super_admin" });
    expect(set.has("users.manage")).toBe(true);
    expect(set.has("settings.manage")).toBe(true);
  });

  it("applies per-user grant and deny overrides", () => {
    const set = resolvePermissionSet({
      role: "analyst",
      userOverrides: [
        { permission: "news.manage", effect: "grant" },
        { permission: "dashboard.read", effect: "deny" },
      ],
    });
    expect(set.has("news.manage")).toBe(true);
    expect(set.has("dashboard.read")).toBe(false);
  });
});

describe("rbac policy", () => {
  const superAdmin = { id: 1, role: "super_admin" as const, permissions: resolvePermissionSet({ role: "super_admin" }) };
  const admin = { id: 2, role: "admin" as const, permissions: resolvePermissionSet({ role: "admin" }) };

  it("blocks acting on a higher-ranked user", () => {
    expect(canActOnUser(admin, { id: 1, role: "super_admin" }).allowed).toBe(false);
    expect(canActOnUser(superAdmin, { id: 2, role: "admin" }).allowed).toBe(true);
  });

  it("blocks privilege escalation via role assignment", () => {
    expect(canAssignRole(admin, "super_admin").allowed).toBe(false);
    expect(canAssignRole(superAdmin, "admin").allowed).toBe(true);
  });

  it("ranks super admin highest", () => {
    expect(ROLE_RANK.super_admin).toBeGreaterThan(ROLE_RANK.admin);
  });
});

describe("passwords", () => {
  it("hashes and verifies", () => {
    const hash = hashPassword("Str0ngPassword!");
    expect(hash).not.toContain("Str0ngPassword");
    expect(verifyPassword("Str0ngPassword!", hash)).toBe(true);
    expect(verifyPassword("wrong-password", hash)).toBe(false);
  });

  it("rejects weak passwords", () => {
    expect(checkPasswordPolicy("123").valid).toBe(false);
    expect(checkPasswordPolicy("Str0ngPassword!").valid).toBe(true);
  });
});

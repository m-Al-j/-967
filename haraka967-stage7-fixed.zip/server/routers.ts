import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, requirePermission, router } from "./_core/trpc";
import {
  ALL_PERMISSIONS,
  PERMISSION_LABELS,
  ROLES,
  ROLE_DEFAULT_PERMISSIONS,
  ROLE_LABELS,
  type Permission,
  type Role,
} from "./_core/permissions";
import {
  canAssignRole,
  canDelegatePermissions,
  canEditRolePermissions,
  canToggleActive,
  canActOnUser,
  type ActorContext,
  type PolicyResult,
} from "./_core/rbacPolicy";
import { invalidatePermissionCache, resolvePermissionsFor } from "./_core/access";
import { checkPasswordPolicy, hashPassword } from "./_core/password";
import { RATE_LIMITS, consumeRateLimit, type RateLimitRule } from "./_core/rateLimit";
import { getRequestIp } from "./_core/requestIp";
import { notifyOwner, sendEmail } from "./_core/notification";
import crypto from "node:crypto";
import * as db from "./db";
import { createAuditLog } from "./db";
import { joinApplicationSchema } from "@shared/join";
import { projectParticipationSubmissionSchema, projectParticipationStatusLabels } from "@shared/projectParticipation";

// ─── Helpers ──────────────────────────────────────────────────────────────────
const roleSchema = z.enum(ROLES);
const permissionSchema = z.enum(ALL_PERMISSIONS);

function canViewUnpublishedContent(ctx: { permissions: ReadonlySet<Permission> }): boolean {
  return ctx.permissions.has("content.read_unpublished") || ctx.permissions.has("content.manage");
}

type AuthedCtx = {
  user: { id: number; role: string | null; isActive?: boolean | null };
  permissions: ReadonlySet<Permission>;
  req: { headers: Record<string, unknown>; socket: { remoteAddress?: string }; ip?: string };
};

function actorOf(ctx: { user: { id: number; role: string | null }; permissions: ReadonlySet<Permission> }): ActorContext {
  return { id: ctx.user.id, role: (ctx.user.role ?? "member") as Role, permissions: ctx.permissions };
}

function assertPolicy(result: PolicyResult): void {
  if (!result.allowed) {
    throw new TRPCError({ code: "FORBIDDEN", message: result.reason });
  }
}

async function requireManageableTarget(
  ctx: { user: { id: number; role: string | null }; permissions: ReadonlySet<Permission> },
  targetId: number
) {
  const target = await db.getUserById(targetId);
  if (!target) throw new TRPCError({ code: "NOT_FOUND", message: "المستخدم غير موجود" });
  assertPolicy(canActOnUser(actorOf(ctx), { id: target.id, role: target.role ?? "member" }));
  return target;
}

async function enforceRateLimit(rule: RateLimitRule, identifier: string): Promise<void> {
  const result = await consumeRateLimit(rule, identifier);
  if (result.limited) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: "عدد المحاولات كبير جداً، يرجى المحاولة لاحقاً",
    });
  }
}

const contentProcedure = protectedProcedure.use(requirePermission("content.manage"));
const newsProcedure = protectedProcedure.use(requirePermission("news.manage"));
const projectsProcedure = protectedProcedure.use(requirePermission("projects.manage"));
const knowledgeProcedure = protectedProcedure.use(requirePermission("knowledge.manage"));
const applicationsReadProcedure = protectedProcedure.use(requirePermission("applications.read"));
const applicationsProcedure = protectedProcedure.use(requirePermission("applications.review"));
const membershipProcedure = protectedProcedure.use(requirePermission("members.manage"));
const membersDeleteProcedure = protectedProcedure.use(requirePermission("members.delete"));
const mapProcedure = protectedProcedure.use(requirePermission("map.manage"));
const filesProcedure = protectedProcedure.use(requirePermission("files.manage"));
const notificationsProcedure = protectedProcedure.use(requirePermission("notifications.send"));
const auditProcedure = protectedProcedure.use(requirePermission("audit.read"));
const settingsReadProcedure = protectedProcedure.use(requirePermission("settings.read_all"));
const settingsProcedure = protectedProcedure.use(requirePermission("settings.manage"));
const pagesProcedure = protectedProcedure.use(requirePermission("pages.manage"));
const dashboardProcedure = protectedProcedure.use(requirePermission("dashboard.read"));
const usersProcedure = protectedProcedure.use(requirePermission("users.manage"));


// ─── Slug Helper ──────────────────────────────────────────────────────────────
function toSlug(title: string): string {
  const base = title
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\u0600-\u06FFa-zA-Z0-9-]/g, "")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .toLowerCase()
    .substring(0, 180);
  const suffix = crypto.randomUUID().replace(/-/g, "").slice(0, 8);
  return `${base || "item"}-${suffix}`;
}

// ─── Applicant ID Helper ──────────────────────────────────────────────────────
function generateApplicantId(): string {
  const year = new Date().getFullYear();
  const random = crypto.randomBytes(4).toString("hex").toUpperCase().slice(0, 6);
  return `H967-${year}-${random}`;
}

// ─── Geo Validators ───────────────────────────────────────────────────────────
const latitudeSchema = z.number().min(-90, "خط العرض يجب أن يكون بين -90 و 90").max(90, "خط العرض يجب أن يكون بين -90 و 90");
const longitudeSchema = z.number().min(-180, "خط الطول يجب أن يكون بين -180 و 180").max(180, "خط الطول يجب أن يكون بين -180 و 180");

export const appRouter = router({
  system: systemRouter,

  // ─── Auth ──────────────────────────────────────────────────────────────────
  auth: router({
    me: publicProcedure.query((opts) => {
      if (!opts.ctx.user) return null;
      // Never send the password hash to the client, even for the user's own account.
      const { passwordHash: _passwordHash, ...safeUser } = opts.ctx.user;
      return safeUser;
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── News ──────────────────────────────────────────────────────────────────
  news: router({
    list: publicProcedure
      .input(z.object({ page: z.number().default(1), limit: z.number().default(12), status: z.string().optional(), search: z.string().optional() }))
      .query(({ input, ctx }) => db.listNews(canViewUnpublishedContent(ctx) ? input : { ...input, status: "published" })),

    get: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input, ctx }) => {
        const item = await db.getNewsBySlug(input.slug, { includeUnpublished: canViewUnpublishedContent(ctx) });
        if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "الخبر غير موجود" });
        return item;
      }),

    create: newsProcedure
      .input(z.object({
        title: z.string().min(3),
        content: z.string().min(10),
        excerpt: z.string().optional(),
        category: z.string().optional(),
        coverImage: z.string().optional(),
        tags: z.array(z.string()).optional(),
        status: z.enum(["draft", "published", "archived"]).default("draft"),
        featured: z.boolean().default(false),
      }))
      .mutation(async ({ input, ctx }) => {
        const slug = toSlug(input.title);
        await db.createNews({ ...input, slug, authorId: ctx.user.id, publishedAt: input.status === "published" ? new Date() : undefined });
        await createAuditLog({ userId: ctx.user.id, action: "create", entity: "news", details: { title: input.title } });
        return { success: true };
      }),

    update: newsProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().min(3).optional(),
        content: z.string().optional(),
        excerpt: z.string().optional(),
        category: z.string().optional(),
        coverImage: z.string().optional(),
        tags: z.array(z.string()).optional(),
        status: z.enum(["draft", "published", "archived"]).optional(),
        featured: z.boolean().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { id, ...data } = input;
        await db.updateNews(id, data);
        await createAuditLog({ userId: ctx.user.id, action: "update", entity: "news", entityId: id });
        return { success: true };
      }),

    delete: newsProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.deleteNews(input.id);
        await createAuditLog({ userId: ctx.user.id, action: "delete", entity: "news", entityId: input.id });
        return { success: true };
      }),
  }),

  // ─── Projects ──────────────────────────────────────────────────────────────
  projects: router({
    list: publicProcedure
      .input(z.object({ page: z.number().default(1), limit: z.number().default(12), status: z.string().optional(), search: z.string().optional() }))
      .query(({ input, ctx }) => db.listProjects(canViewUnpublishedContent(ctx) ? input : { ...input, status: "published" })),

    get: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input, ctx }) => {
        const item = await db.getProjectBySlug(input.slug, { includeUnpublished: canViewUnpublishedContent(ctx) });
        if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "المشروع غير موجود" });
        return item;
      }),

    create: projectsProcedure
      .input(z.object({
        title: z.string().min(3),
        content: z.string().min(10),
        excerpt: z.string().optional(),
        category: z.string().optional(),
        coverImage: z.string().optional(),
        tags: z.array(z.string()).optional(),
        status: z.enum(["draft", "published", "archived", "completed", "ongoing"]).default("draft"),
        featured: z.boolean().default(false),
        location: z.string().optional(),
        imageUrl: z.string().optional(),
        latitude: latitudeSchema.optional().nullable(),
        longitude: longitudeSchema.optional().nullable(),
      }).refine((v) => (v.latitude === undefined || v.latitude === null) === (v.longitude === undefined || v.longitude === null), {
        message: "يجب إدخال خط العرض وخط الطول معًا",
        path: ["longitude"],
      }))
      .mutation(async ({ input, ctx }) => {
        const slug = toSlug(input.title);
        await db.createProject({ ...input, slug, authorId: ctx.user.id });
        await createAuditLog({ userId: ctx.user.id, action: "create", entity: "projects", details: { title: input.title } });
        return { success: true };
      }),

    update: projectsProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        content: z.string().optional(),
        excerpt: z.string().optional(),
        category: z.string().optional(),
        coverImage: z.string().optional(),
        tags: z.array(z.string()).optional(),
        status: z.enum(["draft", "published", "archived", "completed", "ongoing"]).optional(),
        featured: z.boolean().optional(),
        location: z.string().optional(),
        imageUrl: z.string().optional().nullable(),
        latitude: latitudeSchema.optional().nullable(),
        longitude: longitudeSchema.optional().nullable(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { id, ...data } = input;
        await db.updateProject(id, data);
        await createAuditLog({ userId: ctx.user.id, action: "update", entity: "projects", entityId: id });
        return { success: true };
      }),

    delete: projectsProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.deleteProject(input.id);
        await createAuditLog({ userId: ctx.user.id, action: "delete", entity: "projects", entityId: input.id });
        return { success: true };
      }),
  }),

  // ─── Project Participation Requests ───────────────────────────────────────
  participations: router({
    list: projectsProcedure
      .input(z.object({
        page: z.number().int().min(1).default(1),
        limit: z.number().int().min(1).max(100).default(20),
        status: z.string().max(40).optional(),
        projectId: z.number().int().positive().optional(),
        search: z.string().max(200).optional(),
      }))
      .query(({ input }) => db.listProjectParticipationRequests(input)),

    mine: protectedProcedure
      .input(z.object({ projectId: z.number().int().positive() }))
      .query(async ({ input, ctx }) => {
        const request = await db.getProjectParticipationRequestByUserAndProject(ctx.user.id, input.projectId);
        if (!request) return null;
        const project = await db.getProjectById(input.projectId, { includeUnpublished: true });
        return {
          ...request,
          projectTitle: project?.title ?? null,
          projectSlug: project?.slug ?? null,
        };
      }),

    submit: protectedProcedure
      .input(projectParticipationSubmissionSchema)
      .mutation(async ({ input, ctx }) => {
        await enforceRateLimit(RATE_LIMITS.projectParticipationSubmit, String(ctx.user.id));

        const project = await db.getProjectById(input.projectId, { includeUnpublished: true });
        if (!project) {
          throw new TRPCError({ code: "NOT_FOUND", message: "المشروع غير موجود" });
        }
        if (project.status === "archived") {
          throw new TRPCError({ code: "FORBIDDEN", message: "هذا المشروع مؤرشف ولا يستقبل طلبات مشاركة" });
        }

        const existing = await db.getProjectParticipationRequestByUserAndProject(ctx.user.id, input.projectId);
        if (existing && existing.status === "approved") {
          throw new TRPCError({ code: "FORBIDDEN", message: "تمت الموافقة على طلبك بالفعل لهذا المشروع" });
        }

        const requestId = await db.upsertProjectParticipationRequest({
          userId: ctx.user.id,
          projectId: input.projectId,
          fullName: input.fullName,
          email: input.email,
          phone: input.phone,
          governorate: input.governorate,
          city: input.city,
          participationType: input.participationType,
          skills: input.skills,
          motivation: input.motivation,
          status: "pending",
          submittedAt: new Date(),
        } as any);

        await createAuditLog({
          userId: ctx.user.id,
          action: existing ? "resubmit" : "submit",
          entity: "project_participation_requests",
          entityId: requestId ?? undefined,
          details: { projectId: input.projectId, type: input.participationType },
        });

        await notifyOwner({
          title: "طلب مشاركة جديد",
          content: `تم استلام طلب مشاركة جديد في المشروع: ${project.title}
الاسم: ${input.fullName}
البريد: ${input.email}
نوع المشاركة: ${input.participationType}`,
        });

        return { success: true, requestId, projectTitle: project.title };
      }),

    review: projectsProcedure
      .input(z.object({
        id: z.number().int().positive(),
        status: z.enum(["under_review", "more_information_required", "approved", "rejected"]),
        reviewNote: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const request = await db.getProjectParticipationRequestById(input.id);
        if (!request) {
          throw new TRPCError({ code: "NOT_FOUND", message: "الطلب غير موجود" });
        }

        await db.reviewProjectParticipationRequest(input.id, {
          status: input.status,
          reviewNote: input.reviewNote ?? null,
          reviewedBy: ctx.user.id,
          reviewedAt: new Date(),
        });

        const project = await db.getProjectById(request.projectId, { includeUnpublished: true });

        if (request.userId) {
          const statusText = projectParticipationStatusLabels[input.status];
          await db.createNotification({
            userId: request.userId,
            title: `تم تحديث طلب المشاركة: ${statusText}`,
            message: `تم تحديث حالة طلبك في مشروع ${project?.title ?? "المشروع"}.`,
            type: input.status === "approved" ? "success" : input.status === "rejected" ? "warning" : "info",
            link: project?.slug ? `/projects/${project.slug}` : undefined,
          } as any);
        }

        if (project?.title && request.email) {
          const statusText = projectParticipationStatusLabels[input.status];
          await sendEmail({
            to: request.email,
            subject: `تحديث طلب المشاركة - ${project.title}`,
            text: `تم تحديث حالة طلبك في مشروع ${project.title} إلى: ${statusText}
${input.reviewNote ? `ملاحظة المراجع: ${input.reviewNote}` : ""}`,
          });
        }

        await createAuditLog({
          userId: ctx.user.id,
          action: "review",
          entity: "project_participation_requests",
          entityId: input.id,
          details: { status: input.status, projectId: request.projectId },
        });

        return { success: true };
      }),
  }),


  // ─── Knowledge ─────────────────────────────────────────────────────────────
  knowledge: router({
    list: publicProcedure
      .input(z.object({ page: z.number().default(1), limit: z.number().default(12), status: z.string().optional(), search: z.string().optional() }))
      .query(({ input, ctx }) => db.listKnowledge(canViewUnpublishedContent(ctx) ? input : { ...input, status: "published" })),

    get: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input, ctx }) => {
        const item = await db.getKnowledgeBySlug(input.slug, { includeUnpublished: canViewUnpublishedContent(ctx) });
        if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "المقالة غير موجودة" });
        return item;
      }),

    create: knowledgeProcedure
      .input(z.object({
        title: z.string().min(3),
        content: z.string().min(10),
        excerpt: z.string().optional(),
        category: z.string().optional(),
        coverImage: z.string().optional(),
        tags: z.array(z.string()).optional(),
        status: z.enum(["draft", "published", "archived"]).default("draft"),
        featured: z.boolean().default(false),
      }))
      .mutation(async ({ input, ctx }) => {
        const slug = toSlug(input.title);
        await db.createKnowledge({ ...input, slug, authorId: ctx.user.id, publishedAt: input.status === "published" ? new Date() : undefined });
        await createAuditLog({ userId: ctx.user.id, action: "create", entity: "knowledge", details: { title: input.title } });
        return { success: true };
      }),

    update: knowledgeProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        content: z.string().optional(),
        excerpt: z.string().optional(),
        category: z.string().optional(),
        coverImage: z.string().optional(),
        tags: z.array(z.string()).optional(),
        status: z.enum(["draft", "published", "archived"]).optional(),
        featured: z.boolean().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { id, ...data } = input;
        await db.updateKnowledge(id, data);
        await createAuditLog({ userId: ctx.user.id, action: "update", entity: "knowledge", entityId: id });
        return { success: true };
      }),

    delete: knowledgeProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.deleteKnowledge(input.id);
        await createAuditLog({ userId: ctx.user.id, action: "delete", entity: "knowledge", entityId: input.id });
        return { success: true };
      }),
  }),

  // ─── Members ───────────────────────────────────────────────────────────────
  members: router({
    list: membershipProcedure
      .input(z.object({ page: z.number().default(1), limit: z.number().default(20), status: z.string().optional(), search: z.string().optional() }))
      .query(({ input }) => db.listMembers(input)),

    update: membershipProcedure
      .input(z.object({ id: z.number(), status: z.enum(["active", "inactive", "suspended"]).optional(), city: z.string().optional(), governorate: z.string().optional() }))
      .mutation(async ({ input, ctx }) => {
        const { id, ...data } = input;
        await db.updateMember(id, data);
        await createAuditLog({ userId: ctx.user.id, action: "update", entity: "members", entityId: id });
        return { success: true };
      }),

    delete: membersDeleteProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.deleteMember(input.id);
        await createAuditLog({ userId: ctx.user.id, action: "delete", entity: "members", entityId: input.id });
        return { success: true };
      }),
  }),

  // ─── Applications ──────────────────────────────────────────────────────────
  applications: router({
    list: applicationsReadProcedure
      .input(z.object({
        page: z.number().int().min(1).default(1),
        limit: z.number().int().min(1).max(100).default(20),
        status: z.string().max(40).optional(),
      }))
      .query(({ input }) => db.listApplications(input)),

    submit: publicProcedure
      .input(joinApplicationSchema)
      .mutation(async ({ input, ctx }) => {
        await enforceRateLimit(RATE_LIMITS.applicationSubmit, getRequestIp(ctx.req));

        const existingApplication = await db.getActiveApplicationByEmail(input.email.toLowerCase());
        if (existingApplication) {
          throw new TRPCError({
            code: "CONFLICT",
            message: "يوجد بالفعل طلب انضمام نشط بهذا البريد الإلكتروني.",
          });
        }

        if (input.cvFile) {
          const storedFile = await db.getFileByKey(input.cvFile.key);
          if (
            !storedFile ||
            storedFile.folder !== "applications/cv" ||
            storedFile.url !== input.cvFile.url ||
            storedFile.originalName !== input.cvFile.originalName ||
            storedFile.mimeType !== input.cvFile.mimeType ||
            storedFile.size !== input.cvFile.size
          ) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "ملف السيرة الذاتية غير صالح أو غير مرتبط بالرفع الأصلي." });
          }
        }

        const applicantId = await db.generateUniqueApplicantId(generateApplicantId);
        try {
          await db.createApplication({
            applicantId,
            fullName: input.fullName,
            email: input.email,
            phone: input.phone,
            gender: input.gender,
            birthPlace: input.birthPlace,
            age: input.age,
            currentAddress: input.currentAddress,
            cvUrl: input.cvFile?.url,
            cvFileKey: input.cvFile?.key,
            cvOriginalName: input.cvFile?.originalName,
            cvMimeType: input.cvFile?.mimeType,
            cvSize: input.cvFile?.size,
            selectedTeam: input.selectedTeam,
            answers: input.answers,
            agreementAccepted: input.agreement,
            status: "pending",
            submittedAt: new Date(),
          } as any);
        } catch (err) {
          // Race-safe backstop: two concurrent submissions for the same
          // email can both pass the getActiveApplicationByEmail check above;
          // the database's partial unique index rejects the loser here.
          if (err instanceof db.DuplicateActiveApplicationError) {
            throw new TRPCError({
              code: "CONFLICT",
              message: "يوجد بالفعل طلب انضمام نشط بهذا البريد الإلكتروني.",
            });
          }
          throw err;
        }
        if (ctx.user) {
          await createAuditLog({
            userId: ctx.user.id,
            action: "submit",
            entity: "applications",
            details: { team: input.selectedTeam, applicantId },
          });
        }

        await notifyOwner({
          title: "طلب انضمام جديد",
          content: `تم استلام طلب انضمام جديد\nالمتقدم: ${input.fullName}\nالبريد: ${input.email}\nالفريق: ${input.selectedTeam}\nمعرّف الطلب: ${applicantId}`,
        });

        return { success: true, applicantId };
      }),
    review: applicationsProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["approved", "rejected", "under_review", "more_information_required"]),
        reviewNote: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const application = await db.getApplicationById(input.id);
        if (!application) {
          throw new TRPCError({ code: "NOT_FOUND", message: "الطلب غير موجود" });
        }

        await db.updateApplication(input.id, { status: input.status, reviewedBy: ctx.user.id, reviewNote: input.reviewNote, reviewedAt: new Date(), updatedAt: new Date() });

        const statusLabels = {
          approved: "تمت الموافقة",
          rejected: "تم الرفض",
          under_review: "قيد المراجعة",
          more_information_required: "مطلوب مزيد من المعلومات",
        } as const;

        if (input.status === "approved") {
          const existingMember = await db.getMemberByEmail(application.email);
          if (!existingMember) {
            await db.createMember({
              // Approval is performed by an administrator; never associate the
              // member profile with the reviewing administrator's user account.
              // A member account can be linked later through an explicit account flow.
              userId: undefined,
              fullName: application.fullName,
              email: application.email,
              phone: application.phone ?? undefined,
              city: application.city ?? undefined,
              governorate: application.governorate ?? undefined,
              bio: application.motivation ?? undefined,
              skills: application.skills ?? undefined,
              status: "active",
              joinedAt: new Date(),
              updatedAt: new Date(),
            } as any);
          }
        }

        await sendEmail({
          to: application.email,
          subject: `تحديث طلب الانضمام - ${statusLabels[input.status]}`,
          text: `مرحباً ${application.fullName}،\n\nتم تحديث حالة طلب الانضمام الخاص بك إلى: ${statusLabels[input.status]}.\n${input.reviewNote ? `ملاحظة المراجع: ${input.reviewNote}\n` : ""}\nمعرّف الطلب: ${application.applicantId ?? "غير متوفر"}`,
        });

        await createAuditLog({ userId: ctx.user.id, action: "review", entity: "applications", entityId: input.id, details: { status: input.status } });
        return { success: true };
      }),
  }),

  // ─── Map ───────────────────────────────────────────────────────────────────
  map: router({
    list: publicProcedure
      .input(z.object({ status: z.enum(["active", "inactive"]).optional() }))
      .query(async ({ input, ctx }) => {
        // Public visitors may only see active map points. Inactive points are
        // administrative data and require the map.manage permission.
        if (ctx.user && ctx.permissions.has("map.manage")) {
          return db.listMapPoints(input.status);
        }
        return db.listMapPoints("active");
      }),

    create: mapProcedure
      .input(z.object({
        title: z.string().min(2),
        description: z.string().optional(),
        lat: latitudeSchema,
        lng: longitudeSchema,
        category: z.string().optional(),
        governorate: z.string().optional(),
        icon: z.string().optional(),
        color: z.string().optional(),
        status: z.enum(["active", "inactive"]).default("active"),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.createMapPoint({ ...input, createdBy: ctx.user.id });
        await createAuditLog({ userId: ctx.user.id, action: "create", entity: "map_points" });
        return { success: true };
      }),

    update: mapProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        lat: latitudeSchema.optional(),
        lng: longitudeSchema.optional(),
        category: z.string().optional(),
        governorate: z.string().optional(),
        status: z.enum(["active", "inactive"]).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { id, ...data } = input;
        await db.updateMapPoint(id, data);
        await createAuditLog({ userId: ctx.user.id, action: "update", entity: "map_points", entityId: id });
        return { success: true };
      }),

    delete: mapProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.deleteMapPoint(input.id);
        await createAuditLog({ userId: ctx.user.id, action: "delete", entity: "map_points", entityId: input.id });
        return { success: true };
      }),
  }),

  // ─── Files ─────────────────────────────────────────────────────────────────
  files: router({
    list: filesProcedure
      .input(z.object({ page: z.number().default(1), limit: z.number().default(20), folder: z.string().optional() }))
      .query(({ input }) => db.listFiles(input)),

    delete: filesProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.deleteFile(input.id);
        await createAuditLog({ userId: ctx.user.id, action: "delete", entity: "files", entityId: input.id });
        return { success: true };
      }),
  }),

  // ─── Notifications ─────────────────────────────────────────────────────────
  notifications: router({
    list: protectedProcedure
      .input(z.object({ unreadOnly: z.boolean().default(false) }))
      .query(({ input, ctx }) => db.listNotifications(ctx.user.id, input.unreadOnly)),

    markRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input, ctx }) => db.markNotificationRead(input.id, ctx.user.id, ctx.user.role)),

    markAllRead: protectedProcedure
      .mutation(({ ctx }) => db.markAllNotificationsRead(ctx.user.id)),

    send: notificationsProcedure
      .input(z.object({
        userId: z.number().optional(),
        title: z.string().min(2),
        message: z.string().min(5),
        type: z.enum(["info", "success", "warning", "error"]).default("info"),
        link: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.createNotification(input);
        await createAuditLog({ userId: ctx.user.id, action: "send_notification", entity: "notifications" });
        return { success: true };
      }),
  }),

  // ─── Audit ─────────────────────────────────────────────────────────────────
  audit: router({
    list: auditProcedure
      .input(z.object({ page: z.number().default(1), limit: z.number().default(50), userId: z.number().optional(), entity: z.string().optional() }))
      .query(({ input }) => db.listAuditLogs(input)),
  }),

  // ─── Settings ──────────────────────────────────────────────────────────────
  settings: router({
    get: publicProcedure.query(async () => {
      const publicKeys = new Set([
        "site_name",
        "site_description",
        "site_email",
        "owner_name",
        "owner_phone",
        "about_text",
        "vision_text",
        "social_twitter",
        "social_facebook",
        "social_instagram",
        "social_youtube",
      ]);
      return (await db.getSettings()).filter((setting) => publicKeys.has(setting.key));
    }),

    adminGet: settingsReadProcedure.query(() => db.getSettings()),

    update: settingsProcedure
      .input(z.object({ key: z.string(), value: z.string() }))
      .mutation(async ({ input, ctx }) => {
        await db.updateSetting(input.key, input.value, ctx.user.id);
        await createAuditLog({ userId: ctx.user.id, action: "update_setting", entity: "settings", details: { key: input.key } });
        return { success: true };
      }),
  }),

  // ─── Pages ─────────────────────────────────────────────────────────────────
  pages: router({
    list: pagesProcedure.query(() => db.listPages()),

    get: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(({ input, ctx }) => db.getPageBySlug(input.slug, { includeUnpublished: canViewUnpublishedContent(ctx) })),

    upsert: pagesProcedure
      .input(z.object({
        slug: z.string(),
        title: z.string().min(2),
        content: z.string().optional(),
        metaTitle: z.string().optional(),
        metaDescription: z.string().optional(),
        status: z.enum(["draft", "published"]).default("published"),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.upsertPage({ ...input, updatedBy: ctx.user.id });
        await createAuditLog({ userId: ctx.user.id, action: "upsert", entity: "pages", details: { slug: input.slug } });
        return { success: true };
      }),
  }),

  // ─── Contact ───────────────────────────────────────────────────────────────
  contact: router({
    submit: publicProcedure
      .input(z.object({
        name: z.string().trim().min(3),
        email: z.string().trim().email(),
        subject: z.string().trim().min(5),
        message: z.string().trim().min(20),
      }))
      .mutation(async ({ input, ctx }) => {
        const ip = getRequestIp(ctx.req);
        await enforceRateLimit(RATE_LIMITS.contactSubmit, ip);
        await db.createContactMessage({
          name: input.name,
          email: input.email,
          subject: input.subject,
          message: input.message,
          sourceIp: ip,
          userAgent: typeof ctx.req.headers["user-agent"] === "string" ? ctx.req.headers["user-agent"] : null,
          status: "new",
        });

        try {
          await notifyOwner({
            title: `رسالة تواصل جديدة: ${input.subject}`,
            content: `${input.name} <${input.email}>\n\n${input.message}`.slice(0, 18000),
          });
        } catch {}

        await createAuditLog({
          userId: ctx.user?.id ?? undefined,
          action: "submit_contact",
          entity: "contact_messages",
          details: { email: input.email, subject: input.subject },
        });

        return { success: true } as const;
      }),
  }),

  // ─── Search ────────────────────────────────────────────────────────────────
  search: router({
    global: publicProcedure
      .input(z.object({ query: z.string().min(2) }))
      .query(({ input }) => db.globalSearch(input.query)),
  }),

  // ─── Dashboard ─────────────────────────────────────────────────────────────
  dashboard: router({
    stats: dashboardProcedure.query(() => db.getDashboardStats()),
  }),

  // ─── Users & RBAC ──────────────────────────────────────────────────────────
  users: router({
    list: usersProcedure
      .input(z.object({
        page: z.number().int().min(1).default(1),
        limit: z.number().int().min(1).max(100).default(20),
        search: z.string().trim().max(120).optional(),
        role: roleSchema.optional(),
        isActive: z.boolean().optional(),
      }))
      .query(({ input }) => db.listUsersFiltered(input)),

    /** Everything the admin UI needs to render the permission matrix. */
    rbacMatrix: usersProcedure.query(async () => {
      const roleOverrides = await db.listAllRolePermissions();
      return {
        permissions: ALL_PERMISSIONS.map((permission) => ({
          key: permission,
          label: PERMISSION_LABELS[permission],
        })),
        roles: ROLES.map((role) => ({
          key: role,
          label: ROLE_LABELS[role],
          permissions:
            role === "super_admin"
              ? [...ALL_PERMISSIONS]
              : roleOverrides[role]?.length
                ? roleOverrides[role]
                : [...ROLE_DEFAULT_PERMISSIONS[role]],
          isCustomized: Boolean(roleOverrides[role]?.length),
        })),
      };
    }),

    /** Effective permissions of the signed-in user (drives UI gating). */
    myPermissions: protectedProcedure.query(({ ctx }) => ({
      role: ctx.user.role,
      permissions: [...ctx.permissions],
    })),

    getPermissions: usersProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .query(async ({ input }) => {
        const target = await db.getUserById(input.id);
        if (!target) throw new TRPCError({ code: "NOT_FOUND", message: "المستخدم غير موجود" });
        const overrides = await db.listUserPermissionOverrides(target.id);
        const effective = await resolvePermissionsFor(target);
        return {
          user: { id: target.id, name: target.name, email: target.email, role: target.role, isActive: target.isActive },
          overrides,
          effective: [...effective],
        };
      }),

    /** Creates a local administrator account (email + password). */
    createAdmin: usersProcedure
      .input(z.object({
        name: z.string().trim().min(2).max(120),
        email: z.string().trim().toLowerCase().email().max(180),
        password: z.string().min(10).max(256),
        role: roleSchema,
      }))
      .mutation(async ({ input, ctx }) => {
        assertPolicy(canAssignRole(actorOf(ctx), input.role));

        const policy = checkPasswordPolicy(input.password);
        if (!policy.valid) throw new TRPCError({ code: "BAD_REQUEST", message: policy.reason });

        const existing = await db.getUserByEmail(input.email);
        if (existing) throw new TRPCError({ code: "CONFLICT", message: "البريد الإلكتروني مستخدم بالفعل" });

        const created = await db.createLocalUser({
          openId: input.email,
          email: input.email,
          name: input.name,
          role: input.role,
          loginMethod: "local",
          passwordHash: hashPassword(input.password),
          isActive: true,
        });

        await createAuditLog({
          userId: ctx.user.id,
          action: "create_user",
          entity: "users",
          entityId: created?.id,
          details: { email: input.email, role: input.role },
        });
        return { success: true, id: created?.id } as const;
      }),

    /** Resets another administrator's password. */
    resetPassword: usersProcedure
      .input(z.object({ id: z.number().int().positive(), password: z.string().min(10).max(256) }))
      .mutation(async ({ input, ctx }) => {
        const target = await requireManageableTarget(ctx, input.id);
        const policy = checkPasswordPolicy(input.password);
        if (!policy.valid) throw new TRPCError({ code: "BAD_REQUEST", message: policy.reason });

        await db.updateUserById(target.id, { passwordHash: hashPassword(input.password) });
        await createAuditLog({
          userId: ctx.user.id,
          action: "reset_password",
          entity: "users",
          entityId: target.id,
        });
        return { success: true } as const;
      }),

    updateRole: usersProcedure
      .input(z.object({ id: z.number().int().positive(), role: roleSchema }))
      .mutation(async ({ input, ctx }) => {
        const target = await requireManageableTarget(ctx, input.id);
        assertPolicy(canAssignRole(actorOf(ctx), input.role));

        await db.updateUserById(target.id, { role: input.role });
        invalidatePermissionCache({ userId: target.id });
        await createAuditLog({
          userId: ctx.user.id,
          action: "update_role",
          entity: "users",
          entityId: target.id,
          details: { from: target.role, to: input.role },
        });
        return { success: true } as const;
      }),

    setActive: usersProcedure
      .input(z.object({ id: z.number().int().positive(), isActive: z.boolean() }))
      .mutation(async ({ input, ctx }) => {
        const target = await requireManageableTarget(ctx, input.id);
        assertPolicy(canToggleActive(actorOf(ctx), target));

        await db.updateUserById(target.id, { isActive: input.isActive });
        invalidatePermissionCache({ userId: target.id });
        await createAuditLog({
          userId: ctx.user.id,
          action: input.isActive ? "enable_user" : "disable_user",
          entity: "users",
          entityId: target.id,
        });
        return { success: true } as const;
      }),

    /** Per-user grants / denies on top of the role. */
    setPermissions: usersProcedure
      .input(z.object({
        id: z.number().int().positive(),
        overrides: z.array(z.object({
          permission: permissionSchema,
          effect: z.enum(["grant", "deny"]),
        })).max(ALL_PERMISSIONS.length * 2),
      }))
      .mutation(async ({ input, ctx }) => {
        const target = await requireManageableTarget(ctx, input.id);
        const grants = input.overrides.filter((o) => o.effect === "grant").map((o) => o.permission);
        assertPolicy(canDelegatePermissions(actorOf(ctx), grants));

        const deduped = new Map(input.overrides.map((o) => [o.permission, o]));
        await db.setUserPermissionOverrides(target.id, [...deduped.values()], ctx.user.id);
        invalidatePermissionCache({ userId: target.id });
        await createAuditLog({
          userId: ctx.user.id,
          action: "update_user_permissions",
          entity: "users",
          entityId: target.id,
          details: { overrides: [...deduped.values()] },
        });
        return { success: true } as const;
      }),

    /** Redefines what an entire role can do — super admin only. */
    setRolePermissions: usersProcedure
      .input(z.object({
        role: roleSchema,
        permissions: z.array(permissionSchema).max(ALL_PERMISSIONS.length),
      }))
      .mutation(async ({ input, ctx }) => {
        assertPolicy(canEditRolePermissions(actorOf(ctx), input.role));

        await db.setRolePermissions(input.role, [...new Set(input.permissions)]);
        invalidatePermissionCache();
        await createAuditLog({
          userId: ctx.user.id,
          action: "update_role_permissions",
          entity: "roles",
          details: { role: input.role, permissions: input.permissions },
        });
        return { success: true } as const;
      }),

    /** Restores a role to the built-in defaults. */
    resetRolePermissions: usersProcedure
      .input(z.object({ role: roleSchema }))
      .mutation(async ({ input, ctx }) => {
        assertPolicy(canEditRolePermissions(actorOf(ctx), input.role));

        await db.setRolePermissions(input.role, []);
        invalidatePermissionCache();
        await createAuditLog({
          userId: ctx.user.id,
          action: "reset_role_permissions",
          entity: "roles",
          details: { role: input.role },
        });
        return { success: true } as const;
      }),
  }),

});

export type AppRouter = typeof appRouter;

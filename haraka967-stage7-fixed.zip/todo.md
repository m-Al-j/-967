## أولوية العمل الآن
- [ ] إنشاء/الاحتفاظ بنسخة احتياطية قبل أي تعديل كبير
- [ ] تأكيد طريقة دخول أول أدمن
- [ ] التحقق من auth + role checks + `/admin`
- [x] إصلاح مشاكل الأمان المعروفة في Stage 5
- [x] إضافة بوابة CI للتحقق من check/test/build
- [ ] تشغيل build/test فعليًا داخل بيئة تملك مدير الحزم والاعتمادات
- [ ] ثم فقط العمل على التحسينات الثانوية

> هذه القائمة هي ترتيب تنفيذ، وليست إثباتًا نهائيًا أن كل شيء مُراجع يدويًا.

# حركة 967 - خطة المشروع

## قاعدة البيانات
- [x] مخطط جدول users (موجود - تحديث)
- [x] جدول members
- [x] جدول applications
- [x] جدول projects
- [x] جدول news
- [x] جدول knowledge
- [x] جدول map_points
- [x] جدول files
- [x] جدول notifications
- [x] جدول audit_logs
- [x] جدول site_settings
- [x] جدول pages
- [x] تطبيق migrations

## نظام التصميم
- [x] CSS variables: Gold/Black/White
- [x] RTL كامل في index.html
- [x] خطوط Cairo من Google Fonts
- [x] Light/Dark theme switchable
- [x] مكونات مشتركة: ContentCard, Pagination, EmptyState, LoadingState

## Layout العام
- [x] PublicLayout: Header + Footer + Nav
- [x] AdminLayout: Sidebar + Header
- [x] AuthGuard للمسارات الإدارية
- [x] ThemeToggle

## الصفحات العامة
- [x] / الرئيسية
- [x] /about من نحن
- [x] /vision رؤيتنا
- [x] /news قائمة الأخبار
- [x] /news/:slug تفاصيل خبر
- [x] /projects قائمة المشاريع
- [x] /projects/:slug تفاصيل مشروع
- [x] /map الخريطة التفاعلية
- [x] /knowledge قاعدة المعرفة
- [x] /knowledge/:slug تفاصيل مقالة
- [x] /join نموذج الانضمام متعدد الخطوات
- [x] /search البحث الشامل
- [x] /contact التواصل
- [x] /privacy سياسة الخصوصية
- [x] /terms شروط الاستخدام

## لوحة الإدارة
- [x] /admin لوحة التحكم الرئيسية
- [x] /admin/members إدارة الأعضاء
- [x] /admin/applications طلبات الانضمام
- [x] /admin/projects إدارة المشاريع
- [x] /admin/news إدارة الأخبار
- [x] /admin/pages إدارة الصفحات
- [x] /admin/knowledge إدارة المعرفة
- [x] /admin/map إدارة الخريطة
- [x] /admin/roles إدارة الأدوار
- [x] /admin/settings الإعدادات
- [x] /admin/email البريد الإلكتروني
- [x] /admin/notifications الإشعارات
- [x] /admin/files إدارة الملفات
- [x] /admin/audit سجل التدقيق
- [x] /admin/activity سجل النشاط
- [x] /admin/search البحث الإداري

## Backend (tRPC Routers)
- [x] router: news (list, get, create, update, delete)
- [x] router: projects (list, get, create, update, delete)
- [x] router: knowledge (list, get, create, update, delete)
- [x] router: members (list, update, delete)
- [x] router: applications (list, submit, review)
- [x] router: map (list, create, update, delete)
- [x] router: files (list, delete)
- [x] router: notifications (list, markRead, markAllRead, send)
- [x] router: audit (list)
- [x] router: search (global search)
- [x] router: settings (get, update)
- [x] router: pages (list, get, upsert)
- [x] router: dashboard (stats)
- [x] router: users (list, updateRole)

## الجودة والاختبار
- [ ] TypeScript check — يحتاج تشغيلًا فعليًا في بيئة الاعتمادات
- [x] Loading skeletons في جميع الصفحات
- [x] Empty states
- [x] Error boundaries
- [x] Toast notifications
- [x] SEO meta tags
- [x] Accessibility (ARIA)
- [x] Vitest tests (auth.logout)

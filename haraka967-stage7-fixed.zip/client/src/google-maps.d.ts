declare namespace google {
  namespace maps {
    type LatLngLiteral = { lat: number; lng: number };

    enum SymbolPath {
      CIRCLE = 0,
    }

    interface MarkerIcon {
      path?: SymbolPath | string;
      scale?: number;
      fillColor?: string;
      fillOpacity?: number;
      strokeColor?: string;
      strokeWeight?: number;
    }

    interface MarkerOptions {
      position: LatLngLiteral;
      map?: Map | null;
      title?: string;
      icon?: MarkerIcon;
    }

    interface InfoWindowOptions {
      content?: string | Node;
    }

    interface MapOptions {
      zoom?: number;
      center?: LatLngLiteral;
      mapTypeControl?: boolean;
      fullscreenControl?: boolean;
      zoomControl?: boolean;
      streetViewControl?: boolean;
      mapId?: string;
    }

    class Map {
      constructor(element: HTMLElement, options?: MapOptions);
      setCenter(latLng: LatLngLiteral): void;
      setZoom(zoom: number): void;
    }

    class Marker {
      constructor(options: MarkerOptions);
      addListener(eventName: string, handler: () => void): void;
    }

    class InfoWindow {
      constructor(options?: InfoWindowOptions);
      open(map?: Map | null, anchor?: Marker | null): void;
    }

    class Geocoder {
      geocode(request: unknown): Promise<unknown>;
    }

    class DirectionsService {
      route(request: unknown): Promise<unknown>;
    }

    class DirectionsRenderer {
      constructor(options?: { map?: Map | null });
      setDirections(directions: unknown): void;
    }

    class TrafficLayer { setMap(map: Map | null): void; }
    class TransitLayer { setMap(map: Map | null): void; }
    class BicyclingLayer { setMap(map: Map | null): void; }

    namespace marker {
      class AdvancedMarkerElement {
        constructor(options: { map?: Map | null; position?: LatLngLiteral; title?: string });
      }
    }

    namespace places {
      class Place {
        constructor(options: { id: string });
        location?: LatLngLiteral | null;
        fetchFields(options: { fields: string[] }): Promise<void>;
      }
    }

    namespace geometry {
      namespace spherical {
        function computeDistanceBetween(a: LatLngLiteral, b: LatLngLiteral): number;
      }
    }
  }
}

declare const google: { maps: typeof google.maps };

declare interface Window {
  google?: typeof google;
}

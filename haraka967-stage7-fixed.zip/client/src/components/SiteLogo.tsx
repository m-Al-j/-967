import { cn } from "@/lib/utils";

type SiteLogoSize = "sm" | "md" | "lg" | "xl";

type SiteLogoProps = {
  className?: string;
  imageClassName?: string;
  titleClassName?: string;
  subtitleClassName?: string;
  showText?: boolean;
  title?: string;
  subtitle?: string;
  size?: SiteLogoSize;
};

const sizeClasses: Record<SiteLogoSize, string> = {
  sm: "h-9 w-9",
  md: "h-11 w-11",
  lg: "h-16 w-16",
  xl: "h-24 w-24",
};

export function SiteLogo({
  className,
  imageClassName,
  titleClassName,
  subtitleClassName,
  showText = true,
  title = "حركة 967",
  subtitle = "المنصة المجتمعية اليمنية",
  size = "md",
}: SiteLogoProps) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <div
        className={cn(
          "relative shrink-0 overflow-hidden rounded-full bg-background/95 ring-1 ring-border/70 shadow-sm backdrop-blur-sm",
          "dark:bg-zinc-950/90",
          sizeClasses[size],
          imageClassName,
        )}
      >
        <div className="pointer-events-none absolute inset-0 rounded-full bg-gradient-to-br from-white/40 via-transparent to-primary/10 opacity-70" />
        <img
          src="/brand/logo.png"
          alt={`${title} شعار`}
          className="relative z-10 h-full w-full object-contain p-[10%]"
          loading="eager"
          decoding="async"
        />
        <div className="pointer-events-none absolute inset-0 rounded-full ring-1 ring-inset ring-white/15 dark:ring-white/5" />
      </div>
      {showText ? (
        <div className="min-w-0">
          <div className={cn("font-black text-base leading-none tracking-tight", titleClassName)}>
            {title}
          </div>
          <div
            className={cn(
              "mt-0.5 text-xs leading-none text-muted-foreground",
              subtitleClassName,
            )}
          >
            {subtitle}
          </div>
        </div>
      ) : null}
    </div>
  );
}

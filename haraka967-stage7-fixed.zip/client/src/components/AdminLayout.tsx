import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, Users, ClipboardList, FolderOpen, Newspaper, FileText,
  BookOpen, MapPin, Shield, Settings, Mail, Bell, HardDrive, Activity,
  Search, ChevronLeft, Menu, X, LogOut, Moon, Sun, ExternalLink
} from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { startLogin } from "@/const";
import { PageLoadingSpinner } from "@/components/LoadingState";
import { SiteLogo } from "@/components/SiteLogo";

const navItems: { href: string; label: string; icon: any; exact?: boolean; permission?: string }[] = [
  { href: "/admin", label: "لوحة التحكم", icon: LayoutDashboard, exact: true, permission: "dashboard.read" },
  { href: "/admin/members", label: "الأعضاء", icon: Users, permission: "members.manage" },
  { href: "/admin/applications", label: "طلبات الانضمام", icon: ClipboardList, permission: "applications.read" },
  { href: "/admin/projects", label: "المشاريع", icon: FolderOpen, permission: "projects.manage" },
  { href: "/admin/project-participations", label: "مشاركات المشاريع", icon: ClipboardList, permission: "projects.manage" },
  { href: "/admin/news", label: "الأخبار", icon: Newspaper, permission: "news.manage" },
  { href: "/admin/pages", label: "الصفحات", icon: FileText, permission: "pages.manage" },
  { href: "/admin/knowledge", label: "قاعدة المعرفة", icon: BookOpen, permission: "knowledge.manage" },
  { href: "/admin/map", label: "الخريطة", icon: MapPin, permission: "map.manage" },
  { href: "/admin/roles", label: "الأدوار", icon: Shield, permission: "users.manage" },
  { href: "/admin/notifications", label: "الإشعارات", icon: Bell, permission: "notifications.send" },
  { href: "/admin/files", label: "الملفات", icon: HardDrive, permission: "files.manage" },
  { href: "/admin/email", label: "البريد الإلكتروني", icon: Mail, permission: "notifications.send" },
  { href: "/admin/audit", label: "سجل التدقيق", icon: Activity, permission: "audit.read" },
  { href: "/admin/activity", label: "سجل النشاط", icon: Activity, permission: "audit.read" },
  { href: "/admin/search", label: "البحث الإداري", icon: Search, permission: "dashboard.read" },
  { href: "/admin/settings", label: "الإعدادات", icon: Settings, permission: "settings.manage" },
];

function SidebarNav({ onClose, permissions }: { onClose?: () => void; permissions: Set<string> }) {
  const [location] = useLocation();
  const visibleItems = navItems.filter((item) => !item.permission || permissions.has(item.permission));
  return (
    <nav className="flex flex-col gap-0.5 p-3">
      {visibleItems.map(({ href, label, icon: Icon, exact }) => {
        const isActive = exact ? location === href : location.startsWith(href);
        return (
          <Link
            key={href}
            href={href}
            onClick={onClose}
            className={cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all",
              isActive
                ? "bg-primary text-primary-foreground"
                : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
            )}
          >
            <Icon className="w-4 h-4 shrink-0" />
            <span>{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

export function AdminLayout({ children, title }: { children: React.ReactNode; title?: string }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();
  const { user, isAuthenticated, loading, logout } = useAuth();
  const { data: access, isLoading: accessLoading } = trpc.users.myPermissions.useQuery(undefined, {
    retry: false,
  });
  const permissions = new Set<string>(access?.permissions ?? []);
  const logoutMutation = trpc.auth.logout.useMutation({ onSuccess: () => { logout(); window.location.href = "/"; } });

  if (loading) return <PageLoadingSpinner />;
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center max-w-sm p-8">
            <SiteLogo size="xl" showText={false} className="justify-center mb-4" />
            <h1 className="text-xl font-black mb-2">تسجيل الدخول مطلوب</h1>
          <p className="text-muted-foreground text-sm mb-6">يجب تسجيل الدخول للوصول إلى لوحة الإدارة</p>
          <Button className="gradient-gold text-black font-semibold border-0 w-full" onClick={() => startLogin()}>
            تسجيل الدخول
          </Button>
        </div>
      </div>
    );
  }

  if (accessLoading) return <PageLoadingSpinner />;

  if (!permissions.has("dashboard.read")) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center max-w-sm p-8">
          <h1 className="text-xl font-black mb-2">غير مصرح</h1>
          <p className="text-muted-foreground text-sm mb-6">ليس لديك صلاحية الوصول إلى لوحة الإدارة</p>
          <Link href="/"><Button variant="outline">العودة للرئيسية</Button></Link>
        </div>
      </div>
    );
  }

  return (
    <div className="site-shell min-h-screen flex bg-background">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-64 bg-sidebar border-l border-sidebar-border shrink-0 h-screen sticky top-0">
        <div className="p-4 border-b border-sidebar-border">
          <SiteLogo
            size="sm"
            showText
            titleClassName="font-black text-sm text-sidebar-foreground"
            subtitleClassName="text-xs text-sidebar-foreground/50"
          />
        </div>
        <div className="flex-1 overflow-y-auto">
          <SidebarNav permissions={permissions} />
        </div>
        <div className="p-3 border-t border-sidebar-border space-y-1">
          <Link href="/" className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground transition-colors">
            <ExternalLink className="w-3.5 h-3.5" />الموقع العام
          </Link>
          <button onClick={() => logoutMutation.mutate()} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-destructive hover:bg-destructive/10 transition-colors">
            <LogOut className="w-3.5 h-3.5" />تسجيل الخروج
          </button>
        </div>
      </aside>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <aside className="relative w-72 bg-sidebar h-full flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
              <SiteLogo
                size="sm"
                showText={false}
                className="gap-0"
              />
              <button onClick={() => setSidebarOpen(false)} className="text-sidebar-foreground/60 hover:text-sidebar-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <SidebarNav permissions={permissions} onClose={() => setSidebarOpen(false)} />
            </div>
          </aside>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border h-14 flex items-center px-4 gap-3">
          <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-1.5 rounded-lg hover:bg-accent">
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex-1">
            {title && <h1 className="text-sm font-bold text-foreground">{title}</h1>}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={toggleTheme} className="p-1.5 rounded-lg hover:bg-accent transition-colors" aria-label="تبديل الوضع">
              {theme === "dark" ? <Sun className="w-4 h-4 text-primary" /> : <Moon className="w-4 h-4" />}
            </button>
            <div className="flex items-center gap-2 px-2 py-1 rounded-lg bg-muted text-xs">
              <div className="w-6 h-6 rounded-full gradient-gold flex items-center justify-center text-black font-bold text-xs">
                {user?.name?.[0] ?? "م"}
              </div>
              <span className="hidden sm:block font-medium">{user?.name ?? "مستخدم"}</span>
              <span className="text-muted-foreground hidden sm:block">({user?.role === "super_admin" ? "مدير أعلى" : user?.role === "admin" ? "مدير" : user?.role === "content_manager" ? "محتوى" : user?.role === "project_manager" ? "مشاريع" : user?.role === "membership_manager" ? "عضويات" : user?.role === "map_manager" ? "خريطة" : user?.role === "knowledge_manager" ? "معرفة" : user?.role === "analyst" ? "محلل" : "عضو"})</span>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}

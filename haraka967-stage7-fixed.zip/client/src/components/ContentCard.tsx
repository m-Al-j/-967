import { Link } from "wouter";
import { Calendar, Eye, Tag } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface ContentCardProps {
  title: string;
  excerpt?: string | null;
  coverImage?: string | null;
  category?: string | null;
  tags?: string[] | null;
  date?: Date | string | null;
  viewCount?: number;
  href: string;
  featured?: boolean;
  status?: string;
  className?: string;
}

export function ContentCard({ title, excerpt, coverImage, category, tags, date, viewCount, href, featured, status, className }: ContentCardProps) {
  const formattedDate = date ? new Date(date).toLocaleDateString("ar-YE", { year: "numeric", month: "long", day: "numeric" }) : null;

  return (
    <Link href={href} className={cn("group block rounded-xl border border-border bg-card overflow-hidden card-hover", className)}>
      {/* Cover Image */}
      <div className="relative aspect-video bg-muted overflow-hidden">
        {coverImage ? (
          <img src={coverImage} alt={title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" loading="lazy" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-muted to-accent">
            <div className="w-12 h-12 rounded-lg gradient-gold flex items-center justify-center opacity-40">
              <span className="text-black font-black text-lg">967</span>
            </div>
          </div>
        )}
        {featured && (
          <div className="absolute top-2 right-2">
            <Badge className="gradient-gold text-black border-0 text-xs font-bold">مميز</Badge>
          </div>
        )}
        {status && status !== "published" && (
          <div className="absolute top-2 left-2">
            <Badge variant="secondary" className="text-xs">{status === "draft" ? "مسودة" : status === "archived" ? "مؤرشف" : status}</Badge>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        {category && (
          <div className="flex items-center gap-1 mb-2">
            <Tag className="w-3 h-3 text-primary" />
            <span className="text-xs text-primary font-medium">{category}</span>
          </div>
        )}
        <h3 className="font-bold text-foreground line-clamp-2 mb-2 group-hover:text-primary transition-colors leading-snug">
          {title}
        </h3>
        {excerpt && <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed mb-3">{excerpt}</p>}

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          {formattedDate && (
            <div className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              <span>{formattedDate}</span>
            </div>
          )}
          {viewCount !== undefined && (
            <div className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              <span>{viewCount.toLocaleString("ar")}</span>
            </div>
          )}
        </div>

        {tags && tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-3">
            {tags.slice(0, 3).map((tag) => (
              <span key={tag} className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">{tag}</span>
            ))}
          </div>
        )}
      </div>
    </Link>
  );
}

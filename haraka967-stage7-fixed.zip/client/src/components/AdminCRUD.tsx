import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Plus, Pencil, Trash2, Eye, ChevronRight, ChevronLeft, Upload, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { apiUrl } from "@/lib/api";

// ─── Content Table ────────────────────────────────────────────────────────────
interface Column<T> {
  key: keyof T | string;
  label: string;
  render?: (row: T) => React.ReactNode;
  className?: string;
}

interface ContentTableProps<T extends { id: number }> {
  data: T[];
  columns: Column<T>[];
  isLoading?: boolean;
  onEdit?: (row: T) => void;
  onDelete?: (row: T) => void;
  onView?: (row: T) => void;
  total?: number;
  page?: number;
  limit?: number;
  onPageChange?: (page: number) => void;
  search?: string;
  onSearchChange?: (v: string) => void;
  onAdd?: () => void;
  addLabel?: string;
  emptyMessage?: string;
}

export function ContentTable<T extends { id: number }>({
  data, columns, isLoading, onEdit, onDelete, onView, total = 0, page = 1, limit = 20,
  onPageChange, search, onSearchChange, onAdd, addLabel = "إضافة جديد", emptyMessage = "لا توجد بيانات"
}: ContentTableProps<T>) {
  const totalPages = Math.ceil(total / limit);

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between">
        {onSearchChange !== undefined && (
          <div className="relative max-w-xs">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input value={search} onChange={(e) => onSearchChange(e.target.value)} placeholder="بحث..." className="pr-9" />
          </div>
        )}
        {onAdd && (
          <Button onClick={onAdd} className="gradient-gold text-black font-semibold border-0 shrink-0">
            <Plus className="w-4 h-4 ml-1" />{addLabel}
          </Button>
        )}
      </div>

      {/* Table */}
      <div className="rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 border-b border-border">
              <tr>
                {columns.map((col) => (
                  <th key={String(col.key)} className={cn("px-4 py-3 text-right font-semibold text-muted-foreground", col.className)}>
                    {col.label}
                  </th>
                ))}
                {(onEdit || onDelete || onView) && <th className="px-4 py-3 text-right font-semibold text-muted-foreground w-28">الإجراءات</th>}
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-b border-border">
                    {columns.map((col) => <td key={String(col.key)} className="px-4 py-3"><Skeleton className="h-4 w-full" /></td>)}
                    {(onEdit || onDelete) && <td className="px-4 py-3"><Skeleton className="h-4 w-20" /></td>}
                  </tr>
                ))
              ) : data.length === 0 ? (
                <tr><td colSpan={columns.length + 1} className="text-center py-12 text-muted-foreground">{emptyMessage}</td></tr>
              ) : (
                data.map((row) => (
                  <tr key={row.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                    {columns.map((col) => (
                      <td key={String(col.key)} className={cn("px-4 py-3", col.className)}>
                        {col.render ? col.render(row) : String((row as any)[col.key] ?? "—")}
                      </td>
                    ))}
                    {(onEdit || onDelete || onView) && (
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          {onView && <button onClick={() => onView(row)} className="p-1.5 rounded hover:bg-accent text-muted-foreground hover:text-foreground transition-colors" aria-label="عرض"><Eye className="w-3.5 h-3.5" /></button>}
                          {onEdit && <button onClick={() => onEdit(row)} className="p-1.5 rounded hover:bg-accent text-muted-foreground hover:text-foreground transition-colors" aria-label="تعديل"><Pencil className="w-3.5 h-3.5" /></button>}
                          {onDelete && (
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <button className="p-1.5 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors" aria-label="حذف"><Trash2 className="w-3.5 h-3.5" /></button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>تأكيد الحذف</AlertDialogTitle>
                                  <AlertDialogDescription>هل أنت متأكد من حذف هذا العنصر؟ لا يمكن التراجع عن هذا الإجراء.</AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>إلغاء</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => onDelete(row)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">حذف</AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">إجمالي: {total.toLocaleString("ar")} عنصر</span>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="sm" onClick={() => onPageChange?.(page - 1)} disabled={page <= 1}><ChevronRight className="w-4 h-4" /></Button>
            <span className="px-3">{page.toLocaleString("ar")} / {totalPages.toLocaleString("ar")}</span>
            <Button variant="outline" size="sm" onClick={() => onPageChange?.(page + 1)} disabled={page >= totalPages}><ChevronLeft className="w-4 h-4" /></Button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Content Form Dialog ──────────────────────────────────────────────────────
interface ContentFormDialogProps {
  open: boolean;
  onClose: () => void;
  title: string;
  onSubmit: (data: any) => void;
  isLoading?: boolean;
  defaultValues?: any;
  showLocation?: boolean;
  showImageUpload?: boolean;
  showCoordinates?: boolean;
  statusOptions?: { value: string; label: string }[];
}

const DEFAULT_STATUS_OPTIONS = [
  { value: "draft", label: "مسودة" },
  { value: "published", label: "منشور" },
  { value: "archived", label: "مؤرشف" },
];

export function ContentFormDialog({ open, onClose, title, onSubmit, isLoading, defaultValues, showLocation, showImageUpload, showCoordinates, statusOptions = DEFAULT_STATUS_OPTIONS }: ContentFormDialogProps) {
  const [formData, setFormData] = useState<any>(defaultValues ?? {});
  const [tags, setTags] = useState<string>((defaultValues?.tags ?? []).join(", "));
  const [uploading, setUploading] = useState(false);
  const [geoError, setGeoError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // مزامنة القيم عند فتح النموذج أو تبديل العنصر قيد التعديل
  useEffect(() => {
    if (!open) return;
    setFormData(defaultValues ?? {});
    setTags((defaultValues?.tags ?? []).join(", "));
    setGeoError(null);
  }, [open, defaultValues?.id]);

  const parseCoord = (v: any) => {
    if (v === "" || v === null || v === undefined) return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : NaN;
  };

  const validateGeo = () => {
    if (!showCoordinates) return true;
    const lat = parseCoord(formData.latitude);
    const lng = parseCoord(formData.longitude);
    if (Number.isNaN(lat) || Number.isNaN(lng)) { setGeoError("الإحداثيات يجب أن تكون أرقامًا صحيحة"); return false; }
    if ((lat === null) !== (lng === null)) { setGeoError("يجب إدخال خط العرض وخط الطول معًا"); return false; }
    if (lat !== null && (lat < -90 || lat > 90)) { setGeoError("خط العرض يجب أن يكون بين -90 و 90"); return false; }
    if (lng !== null && (lng < -180 || lng > 180)) { setGeoError("خط الطول يجب أن يكون بين -180 و 180"); return false; }
    setGeoError(null);
    return true;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateGeo()) return;
    const payload: any = { ...formData, tags: tags.split(",").map((t: string) => t.trim()).filter(Boolean) };
    if (showCoordinates) {
      payload.latitude = parseCoord(formData.latitude);
      payload.longitude = parseCoord(formData.longitude);
    }
    onSubmit(payload);
  };

  const set = (key: string, value: any) => setFormData((prev: any) => ({ ...prev, [key]: value }));

  async function handleImageFile(file: File | null) {
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("الرجاء اختيار ملف صورة صالح"); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error("حجم الصورة كبير جدًا. الحد الأقصى 5 ميغابايت"); return; }
    const body = new FormData();
    body.append("purpose", "project-image");
    body.append("file", file);
    setUploading(true);
    try {
      const res = await fetch(apiUrl("/api/files/upload"), { method: "POST", body, credentials: "include" });
      const data = await res.json();
      if (!res.ok || !data?.success) throw new Error(data?.error || "فشل رفع الصورة");
      set("imageUrl", data.url);
      toast.success("تم رفع الصورة بنجاح");
    } catch (err: any) {
      toast.error(err?.message ?? "تعذر رفع الصورة");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{title}</DialogTitle></DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <Label>العنوان *</Label>
            <Input value={formData.title ?? ""} onChange={(e) => set("title", e.target.value)} placeholder="أدخل العنوان" required />
          </div>
          <div className="space-y-1.5">
            <Label>المقتطف</Label>
            <Textarea value={formData.excerpt ?? ""} onChange={(e) => set("excerpt", e.target.value)} placeholder="ملخص قصير..." rows={2} />
          </div>
          <div className="space-y-1.5">
            <Label>المحتوى *</Label>
            <Textarea value={formData.content ?? ""} onChange={(e) => set("content", e.target.value)} placeholder="أدخل المحتوى (يدعم Markdown)..." rows={8} required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>التصنيف</Label>
              <Input value={formData.category ?? ""} onChange={(e) => set("category", e.target.value)} placeholder="تصنيف المحتوى" />
            </div>
            <div className="space-y-1.5">
              <Label>الحالة</Label>
              <Select value={formData.status ?? "draft"} onValueChange={(v) => set("status", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{statusOptions.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>صورة الغلاف (رابط)</Label>
            <Input value={formData.coverImage ?? ""} onChange={(e) => set("coverImage", e.target.value)} placeholder="https://..." className="ltr-only" />
          </div>
          <div className="space-y-1.5">
            <Label>الوسوم (مفصولة بفاصلة)</Label>
            <Input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="وسم1, وسم2, وسم3" />
          </div>
          {showLocation && (
            <div className="space-y-1.5">
              <Label>الموقع</Label>
              <Input value={formData.location ?? ""} onChange={(e) => set("location", e.target.value)} placeholder="المحافظة / المدينة" />
            </div>
          )}
          {showImageUpload && (
            <div className="space-y-1.5">
              <Label>صورة المشروع</Label>
              <div className="flex flex-wrap items-center gap-3">
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => void handleImageFile(e.target.files?.[0] ?? null)} />
                <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
                  {uploading ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Upload className="w-4 h-4 ml-1" />}
                  {uploading ? "جارٍ الرفع..." : "رفع صورة"}
                </Button>
                {formData.imageUrl && (
                  <Button type="button" variant="ghost" onClick={() => set("imageUrl", "")}>
                    <X className="w-4 h-4 ml-1" />إزالة
                  </Button>
                )}
              </div>
              <Input value={formData.imageUrl ?? ""} onChange={(e) => set("imageUrl", e.target.value)} placeholder="أو ألصق رابط الصورة https://..." className="ltr-only" />
              {formData.imageUrl && (
                <img src={formData.imageUrl} alt="معاينة صورة المشروع" className="mt-2 h-40 w-full rounded-lg border border-border object-cover" />
              )}
            </div>
          )}
          {showCoordinates && (
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>خط العرض (Latitude)</Label>
                  <Input type="number" step="any" min={-90} max={90} dir="ltr" value={formData.latitude ?? ""} onChange={(e) => set("latitude", e.target.value)} placeholder="15.3694" className="ltr-only" />
                </div>
                <div className="space-y-1.5">
                  <Label>خط الطول (Longitude)</Label>
                  <Input type="number" step="any" min={-180} max={180} dir="ltr" value={formData.longitude ?? ""} onChange={(e) => set("longitude", e.target.value)} placeholder="44.1910" className="ltr-only" />
                </div>
              </div>
              {geoError && <p className="text-xs text-destructive">{geoError}</p>}
              {!geoError && parseCoord(formData.latitude) !== null && parseCoord(formData.longitude) !== null && !Number.isNaN(parseCoord(formData.latitude)) && !Number.isNaN(parseCoord(formData.longitude)) && (
                <a href={`https://www.google.com/maps?q=${formData.latitude},${formData.longitude}`} target="_blank" rel="noreferrer" className="inline-block text-xs text-primary underline">
                  معاينة الموقع على الخريطة
                </a>
              )}
              <p className="text-xs text-muted-foreground">أدخل الإحداثيات ليظهر المشروع على الخريطة التفاعلية.</p>
            </div>
          )}
          <div className="flex items-center gap-2">
            <Switch checked={formData.featured ?? false} onCheckedChange={(v) => set("featured", v)} id="featured" />
            <Label htmlFor="featured">محتوى مميز</Label>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" className="gradient-gold text-black font-semibold border-0" disabled={isLoading}>
              {isLoading ? "جارٍ الحفظ..." : "حفظ"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

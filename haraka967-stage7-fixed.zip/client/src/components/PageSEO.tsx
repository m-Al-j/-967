import { useEffect } from "react";

interface PageSEOProps {
  title: string;
  description?: string;
  image?: string;
  type?: string;
}

export function PageSEO({ title, description, image, type = "website" }: PageSEOProps) {
  const fullTitle = title === "حركة 967" ? title : `${title} | حركة 967`;
  const desc = description ?? "حركة 967 منصة مجتمعية يمنية غير ربحية تهدف إلى توحيد الجهود الشبابية اليمنية";

  useEffect(() => {
    document.title = fullTitle;
    const setMeta = (name: string, content: string, prop = false) => {
      const attr = prop ? "property" : "name";
      let el = document.querySelector(`meta[${attr}="${name}"]`);
      if (!el) { el = document.createElement("meta"); el.setAttribute(attr, name); document.head.appendChild(el); }
      el.setAttribute("content", content);
    };
    setMeta("description", desc);
    setMeta("og:title", fullTitle, true);
    setMeta("og:description", desc, true);
    setMeta("og:type", type, true);
    if (image) setMeta("og:image", image, true);
  }, [fullTitle, desc, image, type]);

  return null;
}

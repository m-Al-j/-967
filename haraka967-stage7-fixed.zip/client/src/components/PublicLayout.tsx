import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Moon, Sun, Menu, Search } from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { SiteLogo } from "@/components/SiteLogo";

const navLinks = [
  { href: "/", label: "الرئيسية" },
  { href: "/about", label: "من نحن" },
  { href: "/vision", label: "رؤيتنا" },
  { href: "/news", label: "الأخبار" },
  { href: "/projects", label: "المشاريع" },
  { href: "/map", label: "الخريطة" },
  { href: "/knowledge", label: "المعرفة" },
];

function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  return (
    <button
      onClick={toggleTheme}
      aria-label="تبديل الوضع"
      className="p-2 rounded-lg hover:bg-accent transition-colors focus-gold"
    >
      {theme === "dark" ? <Sun className="w-5 h-5 text-gold" /> : <Moon className="w-5 h-5" />}
    </button>
  );
}

function NavLink({ href, label, onClick }: { href: string; label: string; onClick?: () => void }) {
  const [location] = useLocation();
  const isActive = location === href || (href !== "/" && location.startsWith(href));
  return (
    <Link
      href={href}
      onClick={onClick}
      className={cn(
        "text-sm font-medium transition-colors hover:text-primary relative py-1",
        isActive
          ? "text-primary after:absolute after:bottom-0 after:right-0 after:left-0 after:h-0.5 after:bg-primary after:rounded-full"
          : "text-foreground/70"
      )}
    >
      {label}
    </Link>
  );
}

export function PublicLayout({ children }: { children: React.ReactNode }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <div className="site-shell min-h-screen flex flex-col bg-background text-foreground">
      {/* ─── Header ──────────────────────────────────────────── */}
      <header
        className={cn(
          "sticky top-0 z-50 transition-all duration-300",
          scrolled
            ? "bg-background/95 backdrop-blur-xl border-b border-border shadow-sm"
            : "bg-background/80 backdrop-blur-md"
        )}
      >
        <div className="container">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="group">
              <SiteLogo
                size="md"
                showText
                className="group"
                subtitleClassName="hidden sm:block"
              />
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-6">
              {navLinks.map((l) => <NavLink key={l.href} {...l} />)}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <Link href="/search" aria-label="بحث" className="p-2 rounded-lg hover:bg-accent transition-colors focus-gold">
                <Search className="w-5 h-5" />
              </Link>
              <ThemeToggle />
              {isAuthenticated ? (
                <div className="flex items-center gap-2">
                  <Link href="/admin" className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 transition-opacity">
                    لوحة التحكم
                  </Link>
                  <div className="w-8 h-8 rounded-full gradient-gold flex items-center justify-center text-black font-bold text-xs">
                    {user?.name?.[0] ?? "م"}
                  </div>
                </div>
              ) : (
                <Button
                  size="sm"
                  className="hidden sm:flex gradient-gold text-black font-semibold border-0 hover:opacity-90"
                  onClick={() => startLogin()}
                >
                  تسجيل الدخول
                </Button>
              )}

              {/* Mobile Menu */}
              <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
                <SheetTrigger asChild>
                  <button className="lg:hidden p-2 rounded-lg hover:bg-accent transition-colors" aria-label="القائمة">
                    <Menu className="w-5 h-5" />
                  </button>
                </SheetTrigger>
                <SheetContent side="right" className="w-72 p-0">
                  <div className="flex flex-col h-full">
                    <div className="flex items-center justify-between p-4 border-b">
                      <SiteLogo
                        size="sm"
                        showText
                        subtitleClassName="hidden"
                        titleClassName="font-bold"
                        className="gap-2"
                      />
                    </div>
                    <nav className="flex flex-col p-4 gap-1">
                      {navLinks.map((l) => (
                        <Link
                          key={l.href}
                          href={l.href}
                          onClick={() => setMobileOpen(false)}
                          className="flex items-center px-3 py-2.5 rounded-lg hover:bg-accent text-sm font-medium transition-colors"
                        >
                          {l.label}
                        </Link>
                      ))}
                    </nav>
                    <div className="mt-auto p-4 border-t space-y-2">
                      <Link href="/join" onClick={() => setMobileOpen(false)}>
                        <Button className="w-full gradient-gold text-black font-semibold border-0">انضم إلينا</Button>
                      </Link>
                      {!isAuthenticated && (
                        <Button variant="outline" className="w-full" onClick={() => { setMobileOpen(false); startLogin(); }}>
                          تسجيل الدخول
                        </Button>
                      )}
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      {/* ─── Main Content ─────────────────────────────────────── */}
      <main className="flex-1">{children}</main>

      {/* ─── Footer ──────────────────────────────────────────── */}
      <footer className="bg-surface text-surface-foreground mt-16">
        <div className="container py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand */}
            <div className="md:col-span-2">
              <SiteLogo
                size="lg"
                showText
                titleClassName="font-black text-lg text-surface-foreground"
                subtitleClassName="text-xs text-surface-foreground/60"
                className="mb-4"
              />
              <p className="text-surface-foreground/70 text-sm leading-relaxed max-w-sm">
                منصة مجتمعية يمنية غير ربحية تهدف إلى توحيد الجهود الشبابية اليمنية نحو مستقبل أفضل لليمن وأبنائه.
              </p>
            </div>

            {/* Links */}
            <div>
              <h3 className="font-bold text-surface-foreground mb-3 text-sm">روابط سريعة</h3>
              <ul className="space-y-2">
                {[{ href: "/about", label: "من نحن" }, { href: "/vision", label: "رؤيتنا" }, { href: "/news", label: "الأخبار" }, { href: "/projects", label: "المشاريع" }].map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="text-surface-foreground/60 hover:text-primary text-sm transition-colors">{l.label}</Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* More Links */}
            <div>
              <h3 className="font-bold text-surface-foreground mb-3 text-sm">المزيد</h3>
              <ul className="space-y-2">
                {[{ href: "/join", label: "انضم إلينا" }, { href: "/contact", label: "تواصل معنا" }, { href: "/privacy", label: "سياسة الخصوصية" }, { href: "/terms", label: "شروط الاستخدام" }].map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="text-surface-foreground/60 hover:text-primary text-sm transition-colors">{l.label}</Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="border-t border-surface-foreground/10 mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-surface-foreground/50 text-sm">© {new Date().getFullYear()} حركة 967. جميع الحقوق محفوظة.</p>
            <p className="text-surface-foreground/40 text-xs italic">لأن اليمن أكبر من أن يكون مجرد فكرة.</p>
            <div className="flex items-center gap-1 text-surface-foreground/50 text-xs">
              <span>صُنع بـ</span>
              <span className="text-primary">♥</span>
              <span>لليمن</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

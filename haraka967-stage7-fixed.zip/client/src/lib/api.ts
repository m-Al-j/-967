/**
 * Central API base URL.
 *
 * In local dev (or when frontend + backend are served from the same origin)
 * this stays empty and all requests are relative ("/api/...").
 *
 * When the frontend (Cloudflare Pages) and backend (Railway/Render/etc.)
 * are deployed on different domains, set VITE_API_URL to the backend's
 * public URL, e.g. https://haraka967-api.onrender.com
 */
const rawBase = import.meta.env.VITE_API_URL ?? "";

// Strip a trailing slash so `${API_BASE_URL}/api/...` never produces `//api`.
export const API_BASE_URL = rawBase.replace(/\/+$/, "");

export function apiUrl(path: string): string {
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  return `${API_BASE_URL}${normalizedPath}`;
}

import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";
import { Heart, Target, Users, Globe } from "lucide-react";

const values = [
  { icon: Heart, title: "الوحدة الوطنية", desc: "نؤمن بأن قوة اليمن تكمن في وحدة أبنائه وتعاونهم" },
  { icon: Target, title: "العمل الهادف", desc: "نركز على المبادرات ذات الأثر الحقيقي والمستدام" },
  { icon: Users, title: "الشراكة المجتمعية", desc: "نبني جسور التعاون بين مختلف شرائح المجتمع" },
  { icon: Globe, title: "الانفتاح والتنوع", desc: "نحتفي بتنوع اليمن الثقافي والجغرافي والفكري" },
];

export default function About() {
  return (
    <PublicLayout>
      <PageSEO title="من نحن" description="تعرف على حركة 967 ورسالتها وقيمها المجتمعية" />

      {/* Hero */}
      <section className="bg-surface text-surface-foreground py-20">
        <div className="container">
          <div className="max-w-2xl">
            <div className="text-primary text-sm font-medium mb-3">من نحن</div>
            <h1 className="text-4xl font-black mb-4 text-surface-foreground">حركة 967</h1>
            <p className="text-surface-foreground/70 text-lg leading-relaxed">
              منصة مجتمعية يمنية غير ربحية تأسست لتكون الجسر الذي يوحد الشباب اليمني الواعي والفاعل في كل أرجاء الوطن والمهجر.
            </p>
            <p className="mt-4 text-sm italic text-surface-foreground/60">لا نبني حضورًا عابرًا، بل نصنع أثرًا يبقى.</p>
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="py-16">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-2xl font-black mb-4">رسالتنا</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                نسعى إلى تمكين الشباب اليمني من خلال توفير منصة رقمية متكاملة تجمع المبادرات والمشاريع والأفكار، وتربط أصحاب الكفاءات بالفرص المتاحة.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                نعمل على بناء شبكة من الشباب اليمني الفاعل في مختلف المجالات: التعليم، الصحة، التكنولوجيا، الثقافة، والتنمية المجتمعية.
              </p>
            </div>
            <div className="bg-muted/30 rounded-2xl p-8 border border-border">
              <div className="text-5xl font-black text-primary mb-2">967</div>
              <p className="text-muted-foreground text-sm">رمز اليمن الدولي، هويتنا وانتماؤنا</p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-muted/20">
        <div className="container">
          <h2 className="text-2xl font-black text-center mb-10">قيمنا</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="p-6 rounded-xl bg-card border border-border text-center">
                <div className="w-12 h-12 rounded-xl gradient-gold flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-6 h-6 text-black" />
                </div>
                <h3 className="font-bold mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}

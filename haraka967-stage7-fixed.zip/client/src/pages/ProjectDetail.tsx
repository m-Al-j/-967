import { useEffect, useState } from "react";
import { useParams, Link } from "wouter";
import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";
import { PageLoadingSpinner } from "@/components/LoadingState";
import { trpc } from "@/lib/trpc";
import { Calendar, MapPin, Eye, ArrowRight, AlertCircle, Users2, CircleCheckBig, MessageCircleMore } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { toast } from "sonner";
import { Streamdown } from "streamdown";
import {
  projectParticipationSubmissionSchema,
  projectParticipationStatusLabels,
  projectParticipationTypeOptions,
  type ProjectParticipationInput,
  type ProjectParticipationStatus,
} from "@shared/projectParticipation";

const statusLabels: Record<string, string> = {
  published: "منشور",
  ongoing: "جارٍ",
  completed: "مكتمل",
  draft: "مسودة",
  archived: "مؤرشف",
};

function parseSkills(value: string): string[] {
  return value
    .split(/[,\n]/g)
    .map((item) => item.trim())
    .filter(Boolean);
}

function formatParticipationStatus(status?: string | null): string {
  if (!status) return "—";
  return projectParticipationStatusLabels[status as ProjectParticipationStatus] ?? status;
}

export default function ProjectDetail() {
  const { slug } = useParams<{ slug: string }>();
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const { data, isLoading, error } = trpc.projects.get.useQuery({ slug: slug ?? "" }, { enabled: !!slug });
  const participationQuery = trpc.projectParticipations.mine.useQuery(
    { projectId: data?.id ?? 0 },
    { enabled: Boolean(data?.id && isAuthenticated) }
  );

  const [participationOpen, setParticipationOpen] = useState(false);
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    governorate: "",
    city: "",
    participationType: "volunteer" as ProjectParticipationInput["participationType"],
    skills: "",
    motivation: "",
  });

  useEffect(() => {
    setForm((current) => ({
      ...current,
      fullName: user?.name ?? current.fullName,
      email: user?.email ?? current.email,
    }));
  }, [user?.name, user?.email]);

  useEffect(() => {
    const request = participationQuery.data;
    if (request) {
      setForm({
        fullName: request.fullName ?? user?.name ?? "",
        email: request.email ?? user?.email ?? "",
        phone: request.phone ?? "",
        governorate: request.governorate ?? "",
        city: request.city ?? "",
        participationType: request.participationType ?? "volunteer",
        skills: Array.isArray(request.skills) ? request.skills.join(", ") : "",
        motivation: request.motivation ?? "",
      });
      return;
    }

    setForm((current) => ({
      ...current,
      fullName: user?.name ?? current.fullName,
      email: user?.email ?? current.email,
    }));
  }, [participationQuery.data, user?.name, user?.email]);

  const submitMutation = trpc.projectParticipations.submit.useMutation({
    onSuccess: async () => {
      toast.success("تم إرسال طلب المشاركة");
      setParticipationOpen(false);
      await participationQuery.refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const canParticipate = data ? data.status === "published" || data.status === "ongoing" : false;
  const existingRequest = participationQuery.data;
  const canEditExistingRequest = !existingRequest || existingRequest.status !== "approved";
  const showParticipationCta = canParticipate && (isAuthenticated || !authLoading);

  if (isLoading) return <PublicLayout><PageLoadingSpinner /></PublicLayout>;
  if (error || !data) return (
    <PublicLayout>
      <div className="container py-20 text-center">
        <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
        <h1 className="text-xl font-bold mb-2">المشروع غير موجود</h1>
        <Link href="/projects" className="text-primary hover:underline text-sm">العودة إلى المشاريع</Link>
      </div>
    </PublicLayout>
  );

  const requestStatus = existingRequest?.status ?? null;
  const requestStatusLabel = formatParticipationStatus(requestStatus);

  const handleSubmit = () => {
    if (!data?.id) return;
    const payload = {
      projectId: data.id,
      fullName: form.fullName,
      email: form.email,
      phone: form.phone || undefined,
      governorate: form.governorate || undefined,
      city: form.city || undefined,
      participationType: form.participationType,
      skills: parseSkills(form.skills),
      motivation: form.motivation,
    };

    const parsed = projectParticipationSubmissionSchema.safeParse(payload);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "تحقق من البيانات");
      return;
    }

    submitMutation.mutate(parsed.data);
  };

  return (
    <PublicLayout>
      <PageSEO title={data.title} description={data.excerpt ?? undefined} image={data.imageUrl ?? data.coverImage ?? undefined} />
      <article className="py-10">
        <div className="container max-w-3xl">
          <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
            <Link href="/" className="hover:text-foreground">الرئيسية</Link>
            <span>/</span>
            <Link href="/projects" className="hover:text-foreground">المشاريع</Link>
            <span>/</span>
            <span className="text-foreground line-clamp-1">{data.title}</span>
          </nav>

          <div className="flex flex-wrap gap-2 mb-3">
            {data.category && <Badge variant="outline" className="text-primary border-primary/30">{data.category}</Badge>}
            <Badge className={data.status === "completed" ? "badge-approved" : data.status === "ongoing" ? "badge-pending" : "badge-draft"}>
              {statusLabels[data.status] ?? data.status}
            </Badge>
          </div>

          <h1 className="text-3xl sm:text-4xl font-black leading-tight mb-4">{data.title}</h1>

          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-6">
            {data.location && <div className="flex items-center gap-1.5"><MapPin className="w-4 h-4" /><span>{data.location}</span></div>}
            <div className="flex items-center gap-1.5"><Calendar className="w-4 h-4" /><span>{new Date(data.createdAt).toLocaleDateString("ar-YE", { year: "numeric", month: "long" })}</span></div>
            <div className="flex items-center gap-1.5"><Eye className="w-4 h-4" /><span>{data.viewCount.toLocaleString("ar")} مشاهدة</span></div>
          </div>

          {(data.imageUrl ?? data.coverImage) && <div className="rounded-xl overflow-hidden mb-8 aspect-video"><img src={data.imageUrl ?? data.coverImage!} alt={data.title} className="w-full h-full object-cover" /></div>}
          {data.excerpt && <p className="text-lg text-muted-foreground leading-relaxed border-r-4 border-primary pr-4 mb-8 font-medium">{data.excerpt}</p>}

          <div className="prose-arabic text-foreground"><Streamdown>{data.content}</Streamdown></div>

          <div className="mt-8 rounded-2xl border border-border bg-card p-5 md:p-6 shadow-sm space-y-4">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <div className="flex items-center gap-2 text-sm font-medium text-primary">
                  <Users2 className="w-4 h-4" />
                  المشاركة في المشروع
                </div>
                <h2 className="text-xl font-black mt-1">شارك في هذا المشروع</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  {canParticipate
                    ? "سجل دخولك ثم أرسل طلب مشاركة مرتبط بحسابك في الموقع."
                    : "هذا المشروع غير مفتوح حاليًا لطلبات المشاركة."}
                </p>
              </div>

              {showParticipationCta && canEditExistingRequest && (
                <Button
                  className="gradient-gold text-black font-semibold border-0"
                  onClick={() => {
                    if (!isAuthenticated) {
                      startLogin();
                      return;
                    }
                    setParticipationOpen(true);
                  }}
                >
                  {existingRequest ? "تحديث طلب المشاركة" : "شارك في المشروع"}
                </Button>
              )}
            </div>

            {existingRequest && (
              <div className="rounded-xl border border-border/70 bg-background p-4 space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <CircleCheckBig className="w-4 h-4 text-primary" />
                  <span className="font-semibold">طلبك الحالي</span>
                  <Badge variant="secondary">{requestStatusLabel}</Badge>
                </div>
                {existingRequest.reviewNote && (
                  <div className="text-sm text-muted-foreground leading-6 whitespace-pre-wrap">{existingRequest.reviewNote}</div>
                )}
                {existingRequest.status === "more_information_required" && (
                  <p className="text-sm text-amber-600 flex items-center gap-2">
                    <MessageCircleMore className="w-4 h-4" />
                    تم طلب معلومات إضافية. يمكنك تحديث الطلب وإعادة الإرسال.
                  </p>
                )}
              </div>
            )}
          </div>

          {data.tags && data.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-8 pt-6 border-t border-border">
              {data.tags.map((tag) => <Badge key={tag} variant="secondary">{tag}</Badge>)}
            </div>
          )}

          <div className="mt-8 pt-6 border-t border-border">
            <Link href="/projects" className="flex items-center gap-2 text-primary hover:underline text-sm font-medium">
              <ArrowRight className="w-4 h-4" />العودة إلى المشاريع
            </Link>
          </div>
        </div>
      </article>

      <Dialog open={participationOpen} onOpenChange={setParticipationOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>شارك في المشروع</DialogTitle>
            <DialogDescription>
              أرسل طلب المشاركة المرتبط بحسابك في الموقع. يمكن تحديثه إذا كانت الحالة ليست مقبولة بعد.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-2">
            <div className="grid gap-2 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label>الاسم الكامل</Label>
                <Input value={form.fullName} onChange={(e) => setForm((p) => ({ ...p, fullName: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>البريد الإلكتروني</Label>
                <Input value={form.email} onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))} className="ltr-only" />
              </div>
            </div>

            <div className="grid gap-2 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label>رقم الهاتف (اختياري)</Label>
                <Input value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} className="ltr-only" />
              </div>
              <div className="space-y-1.5">
                <Label>نوع المشاركة</Label>
                <Select value={form.participationType} onValueChange={(v) => setForm((p) => ({ ...p, participationType: v as any }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {projectParticipationTypeOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-2 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label>المحافظة</Label>
                <Input value={form.governorate} onChange={(e) => setForm((p) => ({ ...p, governorate: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>المدينة</Label>
                <Input value={form.city} onChange={(e) => setForm((p) => ({ ...p, city: e.target.value }))} />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>المهارات (افصل بينها بفواصل)</Label>
              <Input
                value={form.skills}
                onChange={(e) => setForm((p) => ({ ...p, skills: e.target.value }))}
                placeholder="إدارة، تنسيق، تصميم..."
              />
            </div>

            <div className="space-y-1.5">
              <Label>لماذا تريد المشاركة؟</Label>
              <Textarea
                value={form.motivation}
                onChange={(e) => setForm((p) => ({ ...p, motivation: e.target.value }))}
                rows={4}
                placeholder="اكتب سبب رغبتك في المشاركة..."
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setParticipationOpen(false)}>
              إلغاء
            </Button>
            <Button
              className="gradient-gold text-black font-semibold border-0"
              onClick={handleSubmit}
              disabled={submitMutation.isPending || authLoading}
            >
              {submitMutation.isPending ? "جارٍ الإرسال..." : existingRequest ? "تحديث الطلب" : "إرسال الطلب"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PublicLayout>
  );
}

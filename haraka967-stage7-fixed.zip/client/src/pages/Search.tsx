import { useState, useEffect } from "react";
import { useSearch } from "wouter";
import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";
import { ContentCard } from "@/components/ContentCard";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Search as SearchIcon, Loader2 } from "lucide-react";

export default function SearchPage() {
  const searchStr = useSearch();
  const params = new URLSearchParams(searchStr);
  const [query, setQuery] = useState(params.get("q") ?? "");
  const [debouncedQuery, setDebouncedQuery] = useState(query);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query), 400);
    return () => clearTimeout(t);
  }, [query]);

  const { data, isLoading } = trpc.search.global.useQuery({ query: debouncedQuery }, { enabled: debouncedQuery.length >= 2 });
  const totalResults = (data?.news.length ?? 0) + (data?.projects.length ?? 0) + (data?.knowledge.length ?? 0);

  return (
    <PublicLayout>
      <PageSEO title="البحث" description="ابحث في محتوى حركة 967" />
      <section className="bg-surface text-surface-foreground py-16">
        <div className="container max-w-2xl">
          <h1 className="text-3xl font-black text-surface-foreground mb-6">البحث</h1>
          <div className="relative">
            <SearchIcon className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-surface-foreground/40" />
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ابحث في الأخبار والمشاريع والمعرفة..." className="pr-12 h-12 text-base bg-background/10 border-surface-foreground/20 text-surface-foreground placeholder:text-surface-foreground/40 focus:bg-background/20" autoFocus />
          </div>
        </div>
      </section>

      <section className="py-10">
        <div className="container">
          {isLoading && <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="w-4 h-4 animate-spin" />جارٍ البحث...</div>}
          {debouncedQuery.length >= 2 && !isLoading && data && (
            <div className="mb-4 text-sm text-muted-foreground">
              {totalResults > 0 ? `وُجد ${totalResults.toLocaleString("ar")} نتيجة لـ "${debouncedQuery}"` : `لا توجد نتائج لـ "${debouncedQuery}"`}
            </div>
          )}
          {data && (
            <div className="space-y-10">
              {data.news.length > 0 && (
                <div>
                  <h2 className="text-lg font-bold mb-4">الأخبار</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {data.news.map((item) => <ContentCard key={item.id} title={item.title} excerpt={item.excerpt} category={item.category} date={item.publishedAt ?? item.createdAt} href={`/news/${item.slug}`} />)}
                  </div>
                </div>
              )}
              {data.projects.length > 0 && (
                <div>
                  <h2 className="text-lg font-bold mb-4">المشاريع</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {data.projects.map((item) => <ContentCard key={item.id} title={item.title} excerpt={item.excerpt} category={item.category} date={item.createdAt} href={`/projects/${item.slug}`} />)}
                  </div>
                </div>
              )}
              {data.knowledge.length > 0 && (
                <div>
                  <h2 className="text-lg font-bold mb-4">قاعدة المعرفة</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {data.knowledge.map((item) => <ContentCard key={item.id} title={item.title} excerpt={item.excerpt} category={item.category} date={item.publishedAt ?? item.createdAt} href={`/knowledge/${item.slug}`} />)}
                  </div>
                </div>
              )}
            </div>
          )}
          {!debouncedQuery && (
            <div className="text-center py-16 text-muted-foreground">
              <SearchIcon className="w-12 h-12 mx-auto mb-4 opacity-30" />
              <p>أدخل كلمة للبحث</p>
            </div>
          )}
        </div>
      </section>
    </PublicLayout>
  );
}

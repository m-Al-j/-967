import { useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { ContentTable, ContentFormDialog } from "@/components/AdminCRUD";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const statusLabel = (s: string) => ({ published: "منشور", draft: "مسودة", archived: "مؤرشف", completed: "مكتمل", ongoing: "جارٍ" }[s] ?? s);
const statusClass = (s: string) => ({ published: "badge-published", draft: "badge-draft", archived: "badge-archived", completed: "badge-approved", ongoing: "badge-pending" }[s] ?? "");
const STATUS_OPTIONS = [{ value: "draft", label: "مسودة" }, { value: "published", label: "منشور" }, { value: "ongoing", label: "جارٍ" }, { value: "completed", label: "مكتمل" }, { value: "archived", label: "مؤرشف" }];

export default function AdminProjects() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [editItem, setEditItem] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.projects.list.useQuery({ page, limit: 20, search: debouncedSearch || undefined });
  const createMutation = trpc.projects.create.useMutation({ onSuccess: () => { toast.success("تم إنشاء المشروع"); utils.projects.list.invalidate(); setShowForm(false); }, onError: (e) => toast.error(e.message) });
  const updateMutation = trpc.projects.update.useMutation({ onSuccess: () => { toast.success("تم تحديث المشروع"); utils.projects.list.invalidate(); setEditItem(null); }, onError: (e) => toast.error(e.message) });
  const deleteMutation = trpc.projects.delete.useMutation({ onSuccess: () => { toast.success("تم حذف المشروع"); utils.projects.list.invalidate(); }, onError: (e) => toast.error(e.message) });
  const handleSearch = (v: string) => { setSearch(v); clearTimeout((window as any).__projAdminTimer); (window as any).__projAdminTimer = setTimeout(() => { setDebouncedSearch(v); setPage(1); }, 400); };
  return (
    <AdminLayout title="إدارة المشاريع">
      <div className="space-y-4">
        <h1 className="text-xl font-black">إدارة المشاريع</h1>
        <ContentTable
          data={data?.items ?? []} total={data?.total} page={page} limit={20} isLoading={isLoading}
          search={search} onSearchChange={handleSearch} onPageChange={setPage}
          onAdd={() => setShowForm(true)} addLabel="إضافة مشروع" emptyMessage="لا توجد مشاريع"
          onEdit={(row) => setEditItem(row)} onDelete={(row) => deleteMutation.mutate({ id: row.id })}
          columns={[
            { key: "title", label: "العنوان", render: (r) => <span className="font-medium line-clamp-1">{r.title}</span> },
            { key: "category", label: "التصنيف", render: (r) => r.category ?? "—" },
            { key: "location", label: "الموقع", render: (r) => r.location ?? "—" },
            { key: "coords", label: "الإحداثيات", render: (r) => (r.latitude != null && r.longitude != null) ? <span dir="ltr" className="text-xs">{r.latitude}, {r.longitude}</span> : "—" },
            { key: "status", label: "الحالة", render: (r) => <span className={`text-xs px-2 py-0.5 rounded-full ${statusClass(r.status)}`}>{statusLabel(r.status)}</span> },
            { key: "viewCount", label: "المشاهدات", render: (r) => r.viewCount.toLocaleString("ar") },
            { key: "createdAt", label: "التاريخ", render: (r) => new Date(r.createdAt).toLocaleDateString("ar-YE") },
          ]}
        />
      </div>
      <ContentFormDialog open={showForm || !!editItem} onClose={() => { setShowForm(false); setEditItem(null); }} title={editItem ? "تعديل المشروع" : "إضافة مشروع جديد"} defaultValues={editItem} isLoading={createMutation.isPending || updateMutation.isPending} statusOptions={STATUS_OPTIONS} showLocation showImageUpload showCoordinates onSubmit={(data) => editItem ? updateMutation.mutate({ id: editItem.id, ...data }) : createMutation.mutate(data)} />
    </AdminLayout>
  );
}

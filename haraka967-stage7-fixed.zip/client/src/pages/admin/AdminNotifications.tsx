import { useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bell, Send } from "lucide-react";

export default function AdminNotifications() {
  const [form, setForm] = useState({ title: "", message: "", type: "info" as any, link: "" });
  const utils = trpc.useUtils();
  const { data: notifications } = trpc.notifications.list.useQuery({ unreadOnly: false });
  const sendMutation = trpc.notifications.send.useMutation({ onSuccess: () => { toast.success("تم إرسال الإشعار"); setForm({ title: "", message: "", type: "info", link: "" }); utils.notifications.list.invalidate(); }, onError: (e) => toast.error(e.message) });
  const markReadMutation = trpc.notifications.markAllRead.useMutation({ onSuccess: () => utils.notifications.list.invalidate() });
  const set = (k: string, v: string) => setForm((p) => ({ ...p, [k]: v }));
  return (
    <AdminLayout title="الإشعارات">
      <div className="space-y-6">
        <h1 className="text-xl font-black">إدارة الإشعارات</h1>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-card border border-border rounded-xl p-5 space-y-4">
            <h2 className="font-bold flex items-center gap-2"><Send className="w-4 h-4 text-primary" />إرسال إشعار</h2>
            <div className="space-y-1.5"><Label>العنوان *</Label><Input value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="عنوان الإشعار" /></div>
            <div className="space-y-1.5"><Label>الرسالة *</Label><Textarea value={form.message} onChange={(e) => set("message", e.target.value)} placeholder="نص الإشعار..." rows={3} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>النوع</Label>
                <Select value={form.type} onValueChange={(v) => set("type", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="info">معلومة</SelectItem><SelectItem value="success">نجاح</SelectItem><SelectItem value="warning">تحذير</SelectItem><SelectItem value="error">خطأ</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>الرابط (اختياري)</Label><Input value={form.link} onChange={(e) => set("link", e.target.value)} placeholder="/admin/..." className="ltr-only" /></div>
            </div>
            <Button onClick={() => sendMutation.mutate(form)} className="gradient-gold text-black font-semibold border-0 w-full" disabled={sendMutation.isPending || !form.title || !form.message}>
              {sendMutation.isPending ? "جارٍ الإرسال..." : "إرسال الإشعار"}
            </Button>
          </div>
          <div className="bg-card border border-border rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold flex items-center gap-2"><Bell className="w-4 h-4 text-primary" />الإشعارات الأخيرة</h2>
              <Button variant="ghost" size="sm" onClick={() => markReadMutation.mutate()} className="text-xs">تحديد الكل كمقروء</Button>
            </div>
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {!notifications?.length ? (
                <p className="text-sm text-muted-foreground text-center py-8">لا توجد إشعارات</p>
              ) : notifications.map((n) => (
                <div key={n.id} className={`p-3 rounded-lg border ${n.read ? "bg-muted/30 border-border" : "bg-primary/5 border-primary/20"}`}>
                  <div className="font-medium text-sm">{n.title}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{n.message}</div>
                  <div className="text-xs text-muted-foreground mt-1">{new Date(n.createdAt).toLocaleDateString("ar-YE")}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}

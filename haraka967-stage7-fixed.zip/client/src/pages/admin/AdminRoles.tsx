import { useMemo, useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { ContentTable } from "@/components/AdminCRUD";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const PAGE_SIZE = 20;

type OverrideEffect = "grant" | "deny";

export default function AdminRoles() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [permissionUserId, setPermissionUserId] = useState<number | null>(null);
  const [createOpen, setCreateOpen] = useState(false);

  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.users.list.useQuery({
    page,
    limit: PAGE_SIZE,
    search: search.trim() || undefined,
  });
  const { data: matrix } = trpc.users.rbacMatrix.useQuery();
  const { data: me } = trpc.users.myPermissions.useQuery();

  const isSuperAdmin = me?.role === "super_admin";

  const invalidate = () => {
    utils.users.list.invalidate();
    utils.users.rbacMatrix.invalidate();
  };

  const updateRole = trpc.users.updateRole.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث الدور");
      invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const setActive = trpc.users.setActive.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث حالة الحساب");
      invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const roleOptions = matrix?.roles ?? [];

  return (
    <AdminLayout title="إدارة الأدوار والصلاحيات">
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-black">إدارة الأدوار والصلاحيات</h1>
            <p className="text-sm text-muted-foreground">
              تحكّم كامل بمن يستطيع الوصول إلى كل قسم في لوحة الإدارة.
            </p>
          </div>
          <Button onClick={() => setCreateOpen(true)}>إضافة مسؤول</Button>
        </div>

        <Tabs defaultValue="users">
          <TabsList>
            <TabsTrigger value="users">المستخدمون</TabsTrigger>
            <TabsTrigger value="roles">صلاحيات الأدوار</TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-4">
            <Input
              value={search}
              onChange={(event) => {
                setSearch(event.target.value);
                setPage(1);
              }}
              placeholder="بحث بالاسم أو البريد الإلكتروني"
              className="max-w-sm"
            />

            <ContentTable
              data={data?.items ?? []}
              total={data?.total}
              page={page}
              limit={PAGE_SIZE}
              isLoading={isLoading}
              onPageChange={setPage}
              emptyMessage="لا يوجد مستخدمون"
              columns={[
                {
                  key: "name",
                  label: "الاسم",
                  render: (row) => <span className="font-medium">{row.name ?? "—"}</span>,
                },
                {
                  key: "email",
                  label: "البريد",
                  render: (row) => <span className="ltr-only text-sm">{row.email ?? "—"}</span>,
                },
                {
                  key: "role",
                  label: "الدور",
                  render: (row) => (
                    <Select
                      value={row.role}
                      onValueChange={(value) => updateRole.mutate({ id: row.id, role: value as never })}
                    >
                      <SelectTrigger className="w-36 h-8 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {roleOptions.map((role) => (
                          <SelectItem key={role.key} value={role.key}>
                            {role.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ),
                },
                {
                  key: "isActive",
                  label: "الحالة",
                  render: (row) => (
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={row.isActive !== false}
                        onCheckedChange={(checked) => setActive.mutate({ id: row.id, isActive: checked })}
                        aria-label="تفعيل الحساب"
                      />
                      <Badge variant={row.isActive === false ? "destructive" : "secondary"}>
                        {row.isActive === false ? "معطّل" : "نشط"}
                      </Badge>
                    </div>
                  ),
                },
                {
                  key: "actions",
                  label: "الصلاحيات",
                  render: (row) => (
                    <Button variant="outline" size="sm" onClick={() => setPermissionUserId(row.id)}>
                      تخصيص
                    </Button>
                  ),
                },
                {
                  key: "lastSignedIn",
                  label: "آخر دخول",
                  render: (row) =>
                    row.lastSignedIn ? new Date(row.lastSignedIn).toLocaleDateString("ar-YE") : "—",
                },
              ]}
            />
          </TabsContent>

          <TabsContent value="roles">
            <RolePermissionsEditor canEdit={Boolean(isSuperAdmin)} />
          </TabsContent>
        </Tabs>
      </div>

      <UserPermissionsDialog
        userId={permissionUserId}
        onClose={() => setPermissionUserId(null)}
      />
      <CreateAdminDialog open={createOpen} onOpenChange={setCreateOpen} />
    </AdminLayout>
  );
}

function RolePermissionsEditor({ canEdit }: { canEdit: boolean }) {
  const utils = trpc.useUtils();
  const { data: matrix, isLoading } = trpc.users.rbacMatrix.useQuery();
  const [selectedRole, setSelectedRole] = useState<string>("admin");
  const [draft, setDraft] = useState<string[] | null>(null);

  const current = matrix?.roles.find((role) => role.key === selectedRole);
  const selected = draft ?? current?.permissions ?? [];

  const save = trpc.users.setRolePermissions.useMutation({
    onSuccess: () => {
      toast.success("تم حفظ صلاحيات الدور");
      setDraft(null);
      utils.users.rbacMatrix.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const reset = trpc.users.resetRolePermissions.useMutation({
    onSuccess: () => {
      toast.success("تمت الاستعادة إلى الإعداد الافتراضي");
      setDraft(null);
      utils.users.rbacMatrix.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  if (isLoading || !matrix) return <p className="text-sm text-muted-foreground">جارٍ التحميل…</p>;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <Select
          value={selectedRole}
          onValueChange={(value) => {
            setSelectedRole(value);
            setDraft(null);
          }}
        >
          <SelectTrigger className="w-52">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {matrix.roles.map((role) => (
              <SelectItem key={role.key} value={role.key}>
                {role.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {current?.isCustomized ? <Badge variant="secondary">مخصّص</Badge> : <Badge variant="outline">افتراضي</Badge>}
      </div>

      {!canEdit && (
        <p className="text-sm text-muted-foreground">
          تعديل صلاحيات الأدوار متاح للمدير الأعلى فقط.
        </p>
      )}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {matrix.permissions.map((permission) => {
          const checked = selected.includes(permission.key);
          return (
            <label
              key={permission.key}
              className="flex items-start gap-3 rounded-lg border p-3 text-sm"
            >
              <Checkbox
                checked={checked}
                disabled={!canEdit || selectedRole === "super_admin"}
                onCheckedChange={(value) => {
                  const next = new Set(selected);
                  if (value) next.add(permission.key);
                  else next.delete(permission.key);
                  setDraft([...next]);
                }}
              />
              <span>
                <span className="block font-medium">{permission.label}</span>
                <span className="block text-xs text-muted-foreground ltr-only">{permission.key}</span>
              </span>
            </label>
          );
        })}
      </div>

      <div className="flex gap-2">
        <Button
          disabled={!canEdit || selectedRole === "super_admin" || save.isPending || !draft}
          onClick={() => save.mutate({ role: selectedRole as never, permissions: selected as never })}
        >
          حفظ التغييرات
        </Button>
        <Button
          variant="outline"
          disabled={!canEdit || selectedRole === "super_admin" || reset.isPending}
          onClick={() => reset.mutate({ role: selectedRole as never })}
        >
          استعادة الافتراضي
        </Button>
      </div>
    </div>
  );
}

function UserPermissionsDialog({
  userId,
  onClose,
}: {
  userId: number | null;
  onClose: () => void;
}) {
  const utils = trpc.useUtils();
  const { data: matrix } = trpc.users.rbacMatrix.useQuery();
  const { data } = trpc.users.getPermissions.useQuery(
    { id: userId ?? 0 },
    { enabled: userId !== null }
  );
  const [draft, setDraft] = useState<Record<string, OverrideEffect> | null>(null);

  const overrides = useMemo(() => {
    if (draft) return draft;
    const map: Record<string, OverrideEffect> = {};
    for (const override of data?.overrides ?? []) map[override.permission] = override.effect;
    return map;
  }, [data, draft]);

  const save = trpc.users.setPermissions.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث صلاحيات المستخدم");
      setDraft(null);
      utils.users.list.invalidate();
      onClose();
    },
    onError: (error) => toast.error(error.message),
  });

  return (
    <Dialog
      open={userId !== null}
      onOpenChange={(open) => {
        if (!open) {
          setDraft(null);
          onClose();
        }
      }}
    >
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>صلاحيات إضافية للمستخدم</DialogTitle>
          <DialogDescription>
            استثناءات فوق صلاحيات الدور: منح صلاحية إضافية أو سحب صلاحية يمنحها الدور.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2">
          {(matrix?.permissions ?? []).map((permission) => {
            const value = overrides[permission.key] ?? "inherit";
            return (
              <div
                key={permission.key}
                className="flex items-center justify-between gap-3 rounded-lg border p-3"
              >
                <div className="text-sm">
                  <span className="block font-medium">{permission.label}</span>
                  <span className="block text-xs text-muted-foreground ltr-only">{permission.key}</span>
                </div>
                <Select
                  value={value}
                  onValueChange={(next) => {
                    const updated = { ...overrides };
                    if (next === "inherit") delete updated[permission.key];
                    else updated[permission.key] = next as OverrideEffect;
                    setDraft(updated);
                  }}
                >
                  <SelectTrigger className="w-36 h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="inherit">حسب الدور</SelectItem>
                    <SelectItem value="grant">منح</SelectItem>
                    <SelectItem value="deny">منع</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            );
          })}
        </div>

        <DialogFooter>
          <Button
            disabled={userId === null || save.isPending}
            onClick={() =>
              save.mutate({
                id: userId as number,
                overrides: Object.entries(overrides).map(([permission, effect]) => ({
                  permission: permission as never,
                  effect,
                })),
              })
            }
          >
            حفظ
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function CreateAdminDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const utils = trpc.useUtils();
  const { data: matrix } = trpc.users.rbacMatrix.useQuery();
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "content_manager" });

  const create = trpc.users.createAdmin.useMutation({
    onSuccess: () => {
      toast.success("تم إنشاء الحساب");
      setForm({ name: "", email: "", password: "", role: "content_manager" });
      utils.users.list.invalidate();
      onOpenChange(false);
    },
    onError: (error) => toast.error(error.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>إضافة مسؤول جديد</DialogTitle>
          <DialogDescription>
            كلمة المرور: 10 أحرف على الأقل وتحتوي على حروف وأرقام.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="space-y-1">
            <Label htmlFor="admin-name">الاسم</Label>
            <Input
              id="admin-name"
              value={form.name}
              onChange={(event) => setForm({ ...form, name: event.target.value })}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="admin-email">البريد الإلكتروني</Label>
            <Input
              id="admin-email"
              type="email"
              className="ltr-only"
              value={form.email}
              onChange={(event) => setForm({ ...form, email: event.target.value })}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="admin-password">كلمة المرور</Label>
            <Input
              id="admin-password"
              type="password"
              className="ltr-only"
              value={form.password}
              onChange={(event) => setForm({ ...form, password: event.target.value })}
            />
          </div>
          <div className="space-y-1">
            <Label>الدور</Label>
            <Select value={form.role} onValueChange={(value) => setForm({ ...form, role: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(matrix?.roles ?? []).map((role) => (
                  <SelectItem key={role.key} value={role.key}>
                    {role.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button
            disabled={create.isPending}
            onClick={() => create.mutate({ ...form, role: form.role as never })}
          >
            إنشاء
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { ContentTable } from "@/components/AdminCRUD";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const GOVERNORATES = ["صنعاء","عدن","تعز","الحديدة","إب","ذمار","حضرموت","مأرب","البيضاء","الجوف","شبوة","أبين","لحج","الضالع","ريمة","المحويت","عمران","صعدة","حجة","المهرة","سقطرى"];

export default function AdminMap() {
  const [showForm, setShowForm] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [form, setForm] = useState<any>({});
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.map.list.useQuery({});
  const createMutation = trpc.map.create.useMutation({ onSuccess: () => { toast.success("تمت الإضافة"); utils.map.list.invalidate(); setShowForm(false); setForm({}); }, onError: (e) => toast.error(e.message) });
  const updateMutation = trpc.map.update.useMutation({ onSuccess: () => { toast.success("تم التحديث"); utils.map.list.invalidate(); setEditItem(null); }, onError: (e) => toast.error(e.message) });
  const deleteMutation = trpc.map.delete.useMutation({ onSuccess: () => { toast.success("تم الحذف"); utils.map.list.invalidate(); }, onError: (e) => toast.error(e.message) });
  const set = (k: string, v: any) => setForm((p: any) => ({ ...p, [k]: v }));
  const handleOpen = (item?: any) => { setForm(item ?? {}); item ? setEditItem(item) : setShowForm(true); };
  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); const d = { ...form, lat: parseFloat(form.lat), lng: parseFloat(form.lng) }; editItem ? updateMutation.mutate({ id: editItem.id, ...d }) : createMutation.mutate(d); };
  return (
    <AdminLayout title="إدارة الخريطة">
      <div className="space-y-4">
        <h1 className="text-xl font-black">إدارة نقاط الخريطة</h1>
        <ContentTable
          data={data ?? []} isLoading={isLoading} emptyMessage="لا توجد نقاط على الخريطة"
          onAdd={() => handleOpen()} addLabel="إضافة نقطة"
          onEdit={(row) => handleOpen(row)} onDelete={(row) => deleteMutation.mutate({ id: row.id })}
          columns={[
            { key: "title", label: "العنوان", render: (r) => <span className="font-medium">{r.title}</span> },
            { key: "governorate", label: "المحافظة", render: (r) => r.governorate ?? "—" },
            { key: "category", label: "الفئة", render: (r) => r.category ?? "—" },
            { key: "lat", label: "خط العرض", render: (r) => r.lat.toFixed(4) },
            { key: "lng", label: "خط الطول", render: (r) => r.lng.toFixed(4) },
            { key: "status", label: "الحالة", render: (r) => <span className={`text-xs px-2 py-0.5 rounded-full ${r.status === "active" ? "badge-approved" : "badge-draft"}`}>{r.status === "active" ? "فاعل" : "غير فاعل"}</span> },
          ]}
        />
      </div>
      {(showForm || editItem) && (
        <Dialog open onOpenChange={() => { setShowForm(false); setEditItem(null); }}>
          <DialogContent>
            <DialogHeader><DialogTitle>{editItem ? "تعديل نقطة" : "إضافة نقطة جديدة"}</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5"><Label>العنوان *</Label><Input value={form.title ?? ""} onChange={(e) => set("title", e.target.value)} required /></div>
              <div className="space-y-1.5"><Label>الوصف</Label><Textarea value={form.description ?? ""} onChange={(e) => set("description", e.target.value)} rows={2} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5"><Label>خط العرض *</Label><Input type="number" step="any" value={form.lat ?? ""} onChange={(e) => set("lat", e.target.value)} required className="ltr-only" /></div>
                <div className="space-y-1.5"><Label>خط الطول *</Label><Input type="number" step="any" value={form.lng ?? ""} onChange={(e) => set("lng", e.target.value)} required className="ltr-only" /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5"><Label>المحافظة</Label><select value={form.governorate ?? ""} onChange={(e) => set("governorate", e.target.value)} className="w-full px-3 py-2 rounded-lg border border-input bg-background text-sm"><option value="">اختر</option>{GOVERNORATES.map((g) => <option key={g} value={g}>{g}</option>)}</select></div>
                <div className="space-y-1.5"><Label>الفئة</Label><Input value={form.category ?? ""} onChange={(e) => set("category", e.target.value)} /></div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => { setShowForm(false); setEditItem(null); }}>إلغاء</Button>
                <Button type="submit" className="gradient-gold text-black font-semibold border-0" disabled={createMutation.isPending || updateMutation.isPending}>حفظ</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </AdminLayout>
  );
}

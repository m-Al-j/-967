import { useState, useRef } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ContentTable } from "@/components/AdminCRUD";
import { Upload, File, Image, FileText } from "lucide-react";
import { apiUrl } from "@/lib/api";

function FileIcon({ mimeType }: { mimeType?: string | null }) {
  if (mimeType?.startsWith("image/")) return <Image className="w-4 h-4 text-blue-500" />;
  if (mimeType?.includes("pdf")) return <FileText className="w-4 h-4 text-red-500" />;
  return <File className="w-4 h-4 text-muted-foreground" />;
}

export default function AdminFiles() {
  const [page, setPage] = useState(1);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.files.list.useQuery({ page, limit: 20 });
  const deleteMutation = trpc.files.delete.useMutation({ onSuccess: () => { toast.success("تم حذف الملف"); utils.files.list.invalidate(); }, onError: (e) => toast.error(e.message) });

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("purpose", "generic");
      formData.append("file", file);
      const res = await fetch(apiUrl("/api/files/upload"), { method: "POST", body: formData, credentials: "include" });
      if (!res.ok) throw new Error("فشل الرفع");
      const result = await res.json();
      if (result.error) throw new Error(result.error);
      toast.success("تم رفع الملف بنجاح: " + result.originalName);
      utils.files.list.invalidate();
    } catch (err: any) {
      toast.error(err.message ?? "حدث خطأ أثناء الرفع");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  return (
    <AdminLayout title="إدارة الملفات">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-black">إدارة الملفات</h1>
          <div>
            <input ref={fileRef} type="file" className="hidden" onChange={handleUpload} />
            <Button onClick={() => fileRef.current?.click()} className="gradient-gold text-black font-semibold border-0" disabled={uploading}>
              <Upload className="w-4 h-4 ml-1" />{uploading ? "جارٍ الرفع..." : "رفع ملف"}
            </Button>
          </div>
        </div>
        <ContentTable
          data={data?.items ?? []} total={data?.total} page={page} limit={20} isLoading={isLoading} onPageChange={setPage} emptyMessage="لا توجد ملفات"
          onDelete={(row) => deleteMutation.mutate({ id: row.id })}
          columns={[
            { key: "originalName", label: "اسم الملف", render: (r) => <div className="flex items-center gap-2"><FileIcon mimeType={r.mimeType} /><span className="font-medium text-sm">{r.originalName}</span></div> },
            { key: "mimeType", label: "النوع", render: (r) => <span className="text-xs text-muted-foreground">{r.mimeType ?? "—"}</span> },
            { key: "size", label: "الحجم", render: (r) => r.size ? `${(r.size / 1024).toFixed(1)} KB` : "—" },
            { key: "url", label: "الرابط", render: (r) => <a href={r.url} target="_blank" rel="noopener noreferrer" className="text-primary text-xs hover:underline ltr-only truncate max-w-[200px] block">فتح الرابط</a> },
            { key: "createdAt", label: "التاريخ", render: (r) => new Date(r.createdAt).toLocaleDateString("ar-YE") },
          ]}
        />
      </div>
    </AdminLayout>
  );
}

import { Link } from "wouter";
import { AdminLayout } from "@/components/AdminLayout";

const sections: { href: string; label: string }[] = [
  { href: "/admin/members", label: "الأعضاء" },
  { href: "/admin/applications", label: "طلبات الانضمام" },
  { href: "/admin/projects", label: "المشاريع" },
  { href: "/admin/news", label: "الأخبار" },
  { href: "/admin/pages", label: "الصفحات" },
  { href: "/admin/knowledge", label: "المعرفة" },
  { href: "/admin/map", label: "الخريطة" },
  { href: "/admin/roles", label: "الصلاحيات" },
  { href: "/admin/settings", label: "الإعدادات" },
  { href: "/admin/email", label: "البريد" },
  { href: "/admin/notifications", label: "الإشعارات" },
  { href: "/admin/files", label: "الملفات" },
  { href: "/admin/audit", label: "سجل التدقيق" },
  { href: "/admin/activity", label: "النشاط" },
  { href: "/admin/search", label: "البحث" },
];

export default function AdminDashboard() {
  return (
    <AdminLayout title="لوحة التحكم">
      <div className="space-y-4">
        <h1 className="text-xl font-black">لوحة التحكم</h1>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {sections.map((section) => (
            <Link
              key={section.href}
              href={section.href}
              className="rounded-lg border border-border bg-card p-4 text-sm font-semibold transition-colors hover:bg-accent"
            >
              {section.label}
            </Link>
          ))}
        </div>
      </div>
    </AdminLayout>
  );
}

import { useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { Input } from "@/components/ui/input";
import { ContentCard } from "@/components/ContentCard";
import { Search, Loader2 } from "lucide-react";

export default function AdminSearch() {
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const handleSearch = (v: string) => { setQuery(v); clearTimeout((window as any).__adminSearchTimer); (window as any).__adminSearchTimer = setTimeout(() => setDebouncedQuery(v), 400); };
  const { data, isLoading } = trpc.search.global.useQuery({ query: debouncedQuery }, { enabled: debouncedQuery.length >= 2 });
  const total = (data?.news.length ?? 0) + (data?.projects.length ?? 0) + (data?.knowledge.length ?? 0);
  return (
    <AdminLayout title="البحث الإداري">
      <div className="space-y-6">
        <h1 className="text-xl font-black">البحث الإداري</h1>
        <div className="relative max-w-lg">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={query} onChange={(e) => handleSearch(e.target.value)} placeholder="ابحث في جميع المحتوى..." className="pr-9 h-11" autoFocus />
        </div>
        {isLoading && <div className="flex items-center gap-2 text-muted-foreground text-sm"><Loader2 className="w-4 h-4 animate-spin" />جارٍ البحث...</div>}
        {debouncedQuery.length >= 2 && !isLoading && <p className="text-sm text-muted-foreground">{total} نتيجة</p>}
        {data && (
          <div className="space-y-8">
            {data.news.length > 0 && <div><h2 className="font-bold mb-3">الأخبار ({data.news.length})</h2><div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">{data.news.map((i) => <ContentCard key={i.id} title={i.title} excerpt={i.excerpt} category={i.category} date={i.createdAt} href={`/admin/news`} status={i.status} />)}</div></div>}
            {data.projects.length > 0 && <div><h2 className="font-bold mb-3">المشاريع ({data.projects.length})</h2><div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">{data.projects.map((i) => <ContentCard key={i.id} title={i.title} excerpt={i.excerpt} category={i.category} date={i.createdAt} href={`/admin/projects`} status={i.status} />)}</div></div>}
            {data.knowledge.length > 0 && <div><h2 className="font-bold mb-3">المعرفة ({data.knowledge.length})</h2><div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">{data.knowledge.map((i) => <ContentCard key={i.id} title={i.title} excerpt={i.excerpt} category={i.category} date={i.createdAt} href={`/admin/knowledge`} status={i.status} />)}</div></div>}
          </div>
        )}
      </div>
    </AdminLayout>
  );
}

import { useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { ContentTable, ContentFormDialog } from "@/components/AdminCRUD";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";

const statusLabel = (s: string) => ({ published: "منشور", draft: "مسودة", archived: "مؤرشف" }[s] ?? s);
const statusClass = (s: string) => ({ published: "badge-published", draft: "badge-draft", archived: "badge-archived" }[s] ?? "");

export default function AdminNews() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [editItem, setEditItem] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);
  const utils = trpc.useUtils();

  const { data, isLoading } = trpc.news.list.useQuery({ page, limit: 20, search: debouncedSearch || undefined });
  const createMutation = trpc.news.create.useMutation({ onSuccess: () => { toast.success("تم إنشاء الخبر"); utils.news.list.invalidate(); setShowForm(false); }, onError: (e) => toast.error(e.message) });
  const updateMutation = trpc.news.update.useMutation({ onSuccess: () => { toast.success("تم تحديث الخبر"); utils.news.list.invalidate(); setEditItem(null); }, onError: (e) => toast.error(e.message) });
  const deleteMutation = trpc.news.delete.useMutation({ onSuccess: () => { toast.success("تم حذف الخبر"); utils.news.list.invalidate(); }, onError: (e) => toast.error(e.message) });

  const handleSearch = (v: string) => { setSearch(v); clearTimeout((window as any).__newsAdminTimer); (window as any).__newsAdminTimer = setTimeout(() => { setDebouncedSearch(v); setPage(1); }, 400); };

  return (
    <AdminLayout title="إدارة الأخبار">
      <div className="space-y-4">
        <h1 className="text-xl font-black">إدارة الأخبار</h1>
        <ContentTable
          data={data?.items ?? []}
          total={data?.total}
          page={page}
          limit={20}
          isLoading={isLoading}
          search={search}
          onSearchChange={handleSearch}
          onPageChange={setPage}
          onAdd={() => setShowForm(true)}
          addLabel="إضافة خبر"
          emptyMessage="لا توجد أخبار"
          onEdit={(row) => setEditItem(row)}
          onDelete={(row) => deleteMutation.mutate({ id: row.id })}
          columns={[
            { key: "title", label: "العنوان", render: (r) => <span className="font-medium line-clamp-1">{r.title}</span> },
            { key: "category", label: "التصنيف", render: (r) => r.category ?? "—" },
            { key: "status", label: "الحالة", render: (r) => <span className={`text-xs px-2 py-0.5 rounded-full ${statusClass(r.status)}`}>{statusLabel(r.status)}</span> },
            { key: "featured", label: "مميز", render: (r) => r.featured ? <Badge className="gradient-gold text-black border-0 text-xs">مميز</Badge> : "—" },
            { key: "viewCount", label: "المشاهدات", render: (r) => r.viewCount.toLocaleString("ar") },
            { key: "createdAt", label: "التاريخ", render: (r) => new Date(r.createdAt).toLocaleDateString("ar-YE") },
          ]}
        />
      </div>
      <ContentFormDialog
        open={showForm || !!editItem}
        onClose={() => { setShowForm(false); setEditItem(null); }}
        title={editItem ? "تعديل الخبر" : "إضافة خبر جديد"}
        defaultValues={editItem}
        isLoading={createMutation.isPending || updateMutation.isPending}
        onSubmit={(data) => editItem ? updateMutation.mutate({ id: editItem.id, ...data }) : createMutation.mutate(data)}
      />
    </AdminLayout>
  );
}

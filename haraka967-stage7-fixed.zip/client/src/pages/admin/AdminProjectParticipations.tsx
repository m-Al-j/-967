import { useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { ContentTable } from "@/components/AdminCRUD";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { projectParticipationStatusLabels, projectParticipationTypeLabels, type ProjectParticipationStatus } from "@shared/projectParticipation";

const statusOptions: Array<{ value: ProjectParticipationStatus | "all"; label: string }> = [
  { value: "all", label: "جميع الطلبات" },
  { value: "pending", label: "معلقة" },
  { value: "under_review", label: "قيد المراجعة" },
  { value: "more_information_required", label: "مطلوب معلومات إضافية" },
  { value: "approved", label: "مقبولة" },
  { value: "rejected", label: "مرفوضة" },
];

export default function AdminProjectParticipations() {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState<string | undefined>();
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [reviewItem, setReviewItem] = useState<any>(null);
  const [reviewStatus, setReviewStatus] = useState<ProjectParticipationStatus>("under_review");
  const [reviewNote, setReviewNote] = useState("");
  const utils = trpc.useUtils();

  const { data, isLoading } = trpc.projectParticipations.list.useQuery(
    {
      page,
      limit: 20,
      status: statusFilter,
      search: debouncedSearch || undefined,
    }
  );

  const reviewMutation = trpc.projectParticipations.review.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث حالة المشاركة");
      utils.projectParticipations.list.invalidate();
      setReviewItem(null);
    },
    onError: (e) => toast.error(e.message),
  });

  const handleSearch = (value: string) => {
    setSearch(value);
    clearTimeout((window as any).__projectParticipationSearchTimer);
    (window as any).__projectParticipationSearchTimer = setTimeout(() => {
      setDebouncedSearch(value);
      setPage(1);
    }, 400);
  };

  return (
    <AdminLayout title="مشاركات المشاريع">
      <div className="space-y-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-xl font-black">مشاركات المشاريع</h1>
          <Select
            value={statusFilter ?? "all"}
            onValueChange={(v) => {
              setStatusFilter(v === "all" ? undefined : v);
              setPage(1);
            }}
          >
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {statusOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <ContentTable
          data={data?.items ?? []}
          total={data?.total}
          page={page}
          limit={20}
          isLoading={isLoading}
          search={search}
          onSearchChange={handleSearch}
          onPageChange={setPage}
          emptyMessage="لا توجد مشاركات مشاريع"
          onEdit={(row) => {
            setReviewItem(row);
            setReviewStatus(row.status === "approved" || row.status === "rejected" || row.status === "more_information_required" ? row.status : "under_review");
            setReviewNote("");
          }}
          columns={[
            { key: "projectTitle", label: "المشروع", render: (r: any) => <span className="font-medium">{r.projectTitle ?? `#${r.projectId}`}</span> },
            { key: "fullName", label: "الاسم", render: (r: any) => <span className="font-medium">{r.fullName}</span> },
            { key: "email", label: "البريد", render: (r: any) => <span className="ltr-only text-sm">{r.email}</span> },
            { key: "participationType", label: "نوع المشاركة", render: (r: any) => projectParticipationTypeLabels[r.participationType as keyof typeof projectParticipationTypeLabels] ?? r.participationType },
            { key: "status", label: "الحالة", render: (r: any) => <span className={`text-xs px-2 py-0.5 rounded-full ${r.status === "approved" ? "badge-approved" : r.status === "rejected" ? "badge-rejected" : r.status === "under_review" ? "badge-pending" : r.status === "more_information_required" ? "badge-draft" : "badge-pending"}`}>{projectParticipationStatusLabels[r.status as ProjectParticipationStatus] ?? r.status}</span> },
            { key: "submittedAt", label: "تاريخ التقديم", render: (r: any) => new Date(r.submittedAt).toLocaleDateString("ar-YE") },
          ]}
        />
      </div>

      {reviewItem && (
        <Dialog open onOpenChange={() => setReviewItem(null)}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>مراجعة مشاركة المشروع</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="p-4 rounded-lg bg-muted/50 space-y-2">
                <div className="font-semibold">{reviewItem.projectTitle ?? `#${reviewItem.projectId}`}</div>
                <div className="text-sm text-muted-foreground">{reviewItem.fullName} • {reviewItem.email}</div>
                <div className="text-sm">
                  <span className="font-medium">نوع المشاركة: </span>
                  {projectParticipationTypeLabels[reviewItem.participationType as keyof typeof projectParticipationTypeLabels] ?? reviewItem.participationType}
                </div>
                {reviewItem.phone && <div className="text-sm"><span className="font-medium">الهاتف: </span>{reviewItem.phone}</div>}
                {(reviewItem.governorate || reviewItem.city) && (
                  <div className="text-sm"><span className="font-medium">الموقع: </span>{[reviewItem.governorate, reviewItem.city].filter(Boolean).join(" / ")}</div>
                )}
                {Array.isArray(reviewItem.skills) && reviewItem.skills.length > 0 && (
                  <div className="text-sm">
                    <span className="font-medium">المهارات: </span>
                    {reviewItem.skills.join("، ")}
                  </div>
                )}
                <div className="text-sm whitespace-pre-wrap leading-6">{reviewItem.motivation}</div>
              </div>

              <div className="space-y-1.5">
                <Label>القرار</Label>
                <Select value={reviewStatus} onValueChange={(v: ProjectParticipationStatus) => setReviewStatus(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="under_review">قيد المراجعة</SelectItem>
                    <SelectItem value="more_information_required">مطلوب معلومات إضافية</SelectItem>
                    <SelectItem value="approved">قبول</SelectItem>
                    <SelectItem value="rejected">رفض</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <Label>ملاحظة (اختياري)</Label>
                <Textarea
                  value={reviewNote}
                  onChange={(e) => setReviewNote(e.target.value)}
                  placeholder="أضف ملاحظة..."
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setReviewItem(null)}>
                إلغاء
              </Button>
              <Button
                className="gradient-gold text-black font-semibold border-0"
                onClick={() =>
                  reviewMutation.mutate({
                    id: reviewItem.id,
                    status: reviewStatus,
                    reviewNote: reviewNote || undefined,
                  })
                }
                disabled={reviewMutation.isPending}
              >
                حفظ القرار
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </AdminLayout>
  );
}

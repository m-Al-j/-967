import { useState, useEffect } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";

export default function AdminSettings() {
  const { data: settings, isLoading } = trpc.settings.adminGet.useQuery();
  const utils = trpc.useUtils();
  const [form, setForm] = useState<Record<string, string>>({});
  const updateMutation = trpc.settings.update.useMutation({ onSuccess: () => { toast.success("تم حفظ الإعدادات"); utils.settings.adminGet.invalidate(); }, onError: (e) => toast.error(e.message) });

  useEffect(() => {
    if (settings) {
      const map: Record<string, string> = {};
      settings.forEach((s) => { map[s.key] = s.value ?? ""; });
      setForm(map);
    }
  }, [settings]);

  const handleSave = async () => {
    const keys = Object.keys(form);
    for (const key of keys) {
      await updateMutation.mutateAsync({ key, value: form[key] });
    }
  };

  const settingFields = [
    { key: "site_name", label: "اسم الموقع", type: "text" },
    { key: "site_description", label: "وصف الموقع", type: "textarea" },
    { key: "site_email", label: "البريد العام", type: "email" },
    { key: "join_requests_email", label: "البريد الذي يستقبل طلبات الانضمام", type: "email" },
    { key: "owner_name", label: "اسم المسؤول/المالك", type: "text" },
    { key: "owner_email", label: "البريد الإلكتروني للمسؤول الأساسي", type: "email" },
    { key: "owner_phone", label: "هاتف المسؤول الأساسي", type: "text" },
    { key: "admin_emails", label: "بريد المسؤولين (فواصل أو أسطر)", type: "textarea" },
    { key: "about_text", label: "نص صفحة من نحن", type: "textarea" },
    { key: "vision_text", label: "نص صفحة الرؤية", type: "textarea" },
    { key: "social_twitter", label: "تويتر / X", type: "url" },
    { key: "social_facebook", label: "فيسبوك", type: "url" },
    { key: "social_instagram", label: "إنستغرام", type: "url" },
    { key: "social_youtube", label: "يوتيوب", type: "url" },
  ];

  return (
    <AdminLayout title="الإعدادات">
      <div className="space-y-6 max-w-2xl">
        <h1 className="text-xl font-black">إعدادات الموقع</h1>
        <p className="text-sm text-muted-foreground">يمكنك هنا تغيير البريد الأساسي للموقع، البريد الذي يستقبل طلبات الانضمام، وبيانات المسؤول الأساسي وصلاحيات المسؤولين.</p>
        {isLoading ? (
          <div className="space-y-4">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
        ) : (
          <div className="bg-card border border-border rounded-xl p-6 space-y-5">
            {settingFields.map(({ key, label, type }) => (
              <div key={key} className="space-y-1.5">
                <Label>{label}</Label>
                {type === "textarea" ? (
                  <Textarea value={form[key] ?? ""} onChange={(e) => setForm((p) => ({ ...p, [key]: e.target.value }))} rows={3} />
                ) : (
                  <Input type={type} value={form[key] ?? ""} onChange={(e) => setForm((p) => ({ ...p, [key]: e.target.value }))} className={type === "email" || type === "url" ? "ltr-only" : ""} />
                )}
              </div>
            ))}
            <Button onClick={handleSave} className="gradient-gold text-black font-semibold border-0 w-full" disabled={updateMutation.isPending}>
              {updateMutation.isPending ? "جارٍ الحفظ..." : "حفظ الإعدادات"}
            </Button>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}

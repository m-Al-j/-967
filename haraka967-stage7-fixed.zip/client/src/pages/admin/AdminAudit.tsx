import { useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { ContentTable } from "@/components/AdminCRUD";
import { trpc } from "@/lib/trpc";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const entityLabels: Record<string, string> = { news: "الأخبار", projects: "المشاريع", knowledge: "المعرفة", members: "الأعضاء", applications: "الطلبات", map_points: "الخريطة", files: "الملفات", settings: "الإعدادات", notifications: "الإشعارات", users: "المستخدمون", pages: "الصفحات" };
const actionLabels: Record<string, string> = { create: "إنشاء", update: "تحديث", delete: "حذف", review: "مراجعة", send_notification: "إرسال إشعار", update_setting: "تحديث إعداد", update_role: "تحديث دور", upsert: "حفظ" };

export default function AdminAudit() {
  const [page, setPage] = useState(1);
  const [entityFilter, setEntityFilter] = useState<string | undefined>();
  const { data, isLoading } = trpc.audit.list.useQuery({ page, limit: 50, entity: entityFilter });
  return (
    <AdminLayout title="سجل التدقيق">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-black">سجل التدقيق</h1>
          <Select value={entityFilter ?? "all"} onValueChange={(v) => { setEntityFilter(v === "all" ? undefined : v); setPage(1); }}>
            <SelectTrigger className="w-40"><SelectValue placeholder="جميع الكيانات" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الكيانات</SelectItem>
              {Object.entries(entityLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <ContentTable
          data={data?.items ?? []} total={data?.total} page={page} limit={50} isLoading={isLoading} onPageChange={setPage} emptyMessage="لا توجد سجلات"
          columns={[
            { key: "action", label: "الإجراء", render: (r) => <span className="font-medium text-sm">{actionLabels[r.action] ?? r.action}</span> },
            { key: "entity", label: "الكيان", render: (r) => r.entity ? (entityLabels[r.entity] ?? r.entity) : "—" },
            { key: "entityId", label: "المعرف", render: (r) => r.entityId ?? "—" },
            { key: "userId", label: "المستخدم", render: (r) => r.userId ?? "—" },
            { key: "ipAddress", label: "عنوان IP", render: (r) => <span className="ltr-only text-xs">{r.ipAddress ?? "—"}</span> },
            { key: "createdAt", label: "التاريخ", render: (r) => new Date(r.createdAt).toLocaleString("ar-YE") },
          ]}
        />
      </div>
    </AdminLayout>
  );
}

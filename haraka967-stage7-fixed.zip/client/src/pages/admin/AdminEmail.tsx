import { useEffect, useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Send } from "lucide-react";

export default function AdminEmail() {
  const { data: settings } = trpc.settings.adminGet.useQuery();
  const notifyMutation = trpc.system.notifyOwner.useMutation({
    onSuccess: () => {
      toast.success("تم إرسال البريد الإلكتروني");
      setForm({ to: "", subject: "", body: "" });
    },
    onError: (error) => toast.error(error.message),
  });
  const [form, setForm] = useState({ to: "", subject: "", body: "" });
  const [sending, setSending] = useState(false);
  const set = (k: string, v: string) => setForm((p) => ({ ...p, [k]: v }));
  useEffect(() => {
    const recipient =
      settings?.find((s) => s.key === "join_requests_email")?.value ??
      settings?.find((s) => s.key === "site_email")?.value ??
      "";
    if (recipient && !form.to) {
      setForm((p) => ({ ...p, to: String(recipient) }));
    }
  }, [settings]);
  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    try {
      await notifyMutation.mutateAsync({ title: form.subject, content: `إلى: ${form.to}\n\n${form.body}` });
    } finally {
      setSending(false);
    }
  };
  return (
    <AdminLayout title="البريد الإلكتروني">
      <div className="space-y-6 max-w-2xl">
        <h1 className="text-xl font-black">إرسال البريد الإلكتروني</h1>
        <div className="bg-card border border-border rounded-xl p-6">
          <div className="mb-4 text-sm text-muted-foreground">
            البريد المخصص لاستقبال الطلبات من الإعدادات الحالية:
            <span className="ltr-only font-semibold text-foreground">
              {settings?.find((s) => s.key === "join_requests_email")?.value || settings?.find((s) => s.key === "site_email")?.value || "غير محدد"}
            </span>
          </div>
          <form onSubmit={handleSend} className="space-y-4">
            <div className="space-y-1.5"><Label>إلى *</Label><Input type="email" value={form.to} onChange={(e) => set("to", e.target.value)} placeholder="example@email.com" className="ltr-only" required /></div>
            <div className="space-y-1.5"><Label>الموضوع *</Label><Input value={form.subject} onChange={(e) => set("subject", e.target.value)} placeholder="موضوع الرسالة" required /></div>
            <div className="space-y-1.5"><Label>نص الرسالة *</Label><Textarea value={form.body} onChange={(e) => set("body", e.target.value)} placeholder="اكتب نص الرسالة هنا..." rows={8} required /></div>
            <Button type="submit" className="gradient-gold text-black font-semibold border-0 w-full" disabled={sending || notifyMutation.isPending}>
              <Send className="w-4 h-4 ml-1" />{sending ? "جارٍ الإرسال..." : "إرسال البريد"}
            </Button>
          </form>
        </div>
      </div>
    </AdminLayout>
  );
}

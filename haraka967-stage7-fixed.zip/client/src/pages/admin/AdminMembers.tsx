import { useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { ContentTable } from "@/components/AdminCRUD";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export default function AdminMembers() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [editItem, setEditItem] = useState<any>(null);
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.members.list.useQuery({ page, limit: 20, search: debouncedSearch || undefined });
  const updateMutation = trpc.members.update.useMutation({ onSuccess: () => { toast.success("تم تحديث العضو"); utils.members.list.invalidate(); setEditItem(null); }, onError: (e) => toast.error(e.message) });
  const deleteMutation = trpc.members.delete.useMutation({ onSuccess: () => { toast.success("تم حذف العضو"); utils.members.list.invalidate(); }, onError: (e) => toast.error(e.message) });
  const handleSearch = (v: string) => { setSearch(v); clearTimeout((window as any).__membersTimer); (window as any).__membersTimer = setTimeout(() => { setDebouncedSearch(v); setPage(1); }, 400); };
  return (
    <AdminLayout title="إدارة الأعضاء">
      <div className="space-y-4">
        <h1 className="text-xl font-black">إدارة الأعضاء</h1>
        <ContentTable
          data={data?.items ?? []} total={data?.total} page={page} limit={20} isLoading={isLoading}
          search={search} onSearchChange={handleSearch} onPageChange={setPage} emptyMessage="لا يوجد أعضاء"
          onEdit={(row) => setEditItem(row)} onDelete={(row) => deleteMutation.mutate({ id: row.id })}
          columns={[
            { key: "fullName", label: "الاسم", render: (r) => <span className="font-medium">{r.fullName}</span> },
            { key: "email", label: "البريد الإلكتروني", render: (r) => <span className="ltr-only text-sm">{r.email}</span> },
            { key: "governorate", label: "المحافظة", render: (r) => r.governorate ?? "—" },
            { key: "status", label: "الحالة", render: (r) => <span className={`text-xs px-2 py-0.5 rounded-full ${r.status === "active" ? "badge-approved" : r.status === "suspended" ? "badge-rejected" : "badge-draft"}`}>{r.status === "active" ? "فاعل" : r.status === "suspended" ? "موقوف" : "غير فاعل"}</span> },
            { key: "joinedAt", label: "تاريخ الانضمام", render: (r) => new Date(r.joinedAt).toLocaleDateString("ar-YE") },
          ]}
        />
      </div>
      {editItem && (
        <Dialog open onOpenChange={() => setEditItem(null)}>
          <DialogContent>
            <DialogHeader><DialogTitle>تعديل حالة العضو</DialogTitle></DialogHeader>
            <div className="space-y-4 py-2">
              <div><div className="font-semibold">{editItem.fullName}</div><div className="text-sm text-muted-foreground">{editItem.email}</div></div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">الحالة</label>
                <Select defaultValue={editItem.status} onValueChange={(v) => setEditItem({ ...editItem, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">فاعل</SelectItem>
                    <SelectItem value="inactive">غير فاعل</SelectItem>
                    <SelectItem value="suspended">موقوف</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditItem(null)}>إلغاء</Button>
              <Button className="gradient-gold text-black font-semibold border-0" onClick={() => updateMutation.mutate({ id: editItem.id, status: editItem.status })} disabled={updateMutation.isPending}>حفظ</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </AdminLayout>
  );
}

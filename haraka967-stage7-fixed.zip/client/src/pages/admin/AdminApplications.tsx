
import { useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { ContentTable } from "@/components/AdminCRUD";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getQuestionsForTeam, getTeamLabel } from "@shared/join";

export default function AdminApplications() {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState<string | undefined>();
  const [reviewItem, setReviewItem] = useState<any>(null);
  const [reviewStatus, setReviewStatus] = useState<"approved" | "rejected" | "under_review" | "more_information_required">("under_review");
  const [reviewNote, setReviewNote] = useState("");
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.applications.list.useQuery({ page, limit: 20, status: statusFilter });
  const reviewMutation = trpc.applications.review.useMutation({ onSuccess: () => { toast.success("تم تحديث حالة الطلب"); utils.applications.list.invalidate(); setReviewItem(null); }, onError: (e) => toast.error(e.message) });

  return (
    <AdminLayout title="طلبات الانضمام">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-black">طلبات الانضمام</h1>
          <Select value={statusFilter ?? "all"} onValueChange={(v) => { setStatusFilter(v === "all" ? undefined : v); setPage(1); }}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الطلبات</SelectItem>
              <SelectItem value="pending">معلقة</SelectItem>
              <SelectItem value="under_review">قيد المراجعة</SelectItem>
              <SelectItem value="more_information_required">مطلوب معلومات إضافية</SelectItem>
              <SelectItem value="approved">مقبولة</SelectItem>
              <SelectItem value="rejected">مرفوضة</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <ContentTable
          data={data?.items ?? []}
          total={data?.total}
          page={page}
          limit={20}
          isLoading={isLoading}
          onPageChange={setPage}
          emptyMessage="لا توجد طلبات"
          onEdit={(row) => {
            setReviewItem(row);
            setReviewStatus(row.status === "more_information_required" || row.status === "approved" || row.status === "rejected" ? row.status : "under_review");
            setReviewNote("");
          }}
          columns={[
            { key: "applicantId", label: "معرّف المتقدم", render: (r: any) => r.applicantId ? <span dir="ltr" className="text-xs font-mono">{r.applicantId}</span> : "—" },
            { key: "fullName", label: "الاسم", render: (r) => <span className="font-medium">{r.fullName}</span> },
            { key: "email", label: "البريد", render: (r) => <span className="ltr-only text-sm">{r.email}</span> },
            { key: "selectedTeam", label: "الفريق", render: (r) => r.selectedTeam ? getTeamLabel(r.selectedTeam) : "—" },
            { key: "currentAddress", label: "العنوان الحالي", render: (r) => r.currentAddress ?? "—" },
            { key: "status", label: "الحالة", render: (r) => <span className={`text-xs px-2 py-0.5 rounded-full ${r.status === "approved" ? "badge-approved" : r.status === "rejected" ? "badge-rejected" : r.status === "under_review" ? "badge-pending" : r.status === "more_information_required" ? "badge-draft" : "badge-pending"}`}>{r.status === "approved" ? "مقبول" : r.status === "rejected" ? "مرفوض" : r.status === "under_review" ? "قيد المراجعة" : r.status === "more_information_required" ? "مطلوب معلومات" : "معلق"}</span> },
            { key: "submittedAt", label: "تاريخ التقديم", render: (r) => new Date(r.submittedAt).toLocaleDateString("ar-YE") },
          ]}
        />
      </div>

      {reviewItem && (
        <Dialog open onOpenChange={() => setReviewItem(null)}>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>مراجعة الطلب</DialogTitle></DialogHeader>
            <div className="space-y-4 py-2">
              <div className="p-4 rounded-lg bg-muted/50 space-y-2">
                <div className="font-semibold">{reviewItem.fullName}</div>
                <div className="text-sm text-muted-foreground">{reviewItem.email} • {reviewItem.currentAddress ?? reviewItem.governorate ?? "—"}</div>
                <div className="mt-2 text-sm"><span className="font-medium">الفريق: </span>{reviewItem.selectedTeam ? getTeamLabel(reviewItem.selectedTeam) : "—"}</div>
                {reviewItem.gender && <div className="text-sm mt-1"><span className="font-medium">الجنس: </span>{reviewItem.gender === "male" ? "ذكر" : reviewItem.gender === "female" ? "أنثى" : reviewItem.gender}</div>}
                {reviewItem.phone && <div className="text-sm mt-1"><span className="font-medium">الهاتف: </span>{reviewItem.phone}</div>}
                {reviewItem.birthPlace && <div className="text-sm mt-1"><span className="font-medium">محل الميلاد: </span>{reviewItem.birthPlace}</div>}
                {reviewItem.age && <div className="text-sm mt-1"><span className="font-medium">العمر: </span>{reviewItem.age}</div>}
                {reviewItem.cvUrl && <div className="text-sm mt-1"><span className="font-medium">السيرة الذاتية: </span><a className="text-primary underline" href={reviewItem.cvUrl} target="_blank" rel="noreferrer">عرض الملف</a></div>}
                {reviewItem.answers && reviewItem.selectedTeam && (
                  <div className="mt-4 space-y-3 border-t pt-4">
                    <div className="text-sm font-semibold">إجابات الفريق المختار</div>
                    {getQuestionsForTeam(reviewItem.selectedTeam).map((question) => (
                      <div key={question.id} className="rounded-lg bg-background p-3 text-sm">
                        <div className="text-xs font-semibold text-primary">{question.id}</div>
                        <div className="mt-1 font-medium leading-6">{question.label}</div>
                        <div className="mt-2 whitespace-pre-wrap text-muted-foreground">{reviewItem.answers?.[question.id] ?? "—"}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-1.5">
                <Label>القرار</Label>
                <Select value={reviewStatus} onValueChange={(v: any) => setReviewStatus(v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="under_review">قيد المراجعة</SelectItem>
                    <SelectItem value="more_information_required">مطلوب معلومات إضافية</SelectItem>
                    <SelectItem value="approved">قبول</SelectItem>
                    <SelectItem value="rejected">رفض</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <Label>ملاحظة (اختياري)</Label>
                <Textarea value={reviewNote} onChange={(e) => setReviewNote(e.target.value)} placeholder="أضف ملاحظة..." rows={3} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setReviewItem(null)}>إلغاء</Button>
              <Button className="gradient-gold text-black font-semibold border-0" onClick={() => reviewMutation.mutate({ id: reviewItem.id, status: reviewStatus, reviewNote: reviewNote || undefined })} disabled={reviewMutation.isPending}>حفظ القرار</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </AdminLayout>
  );
}

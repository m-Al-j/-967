import { useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { ContentTable } from "@/components/AdminCRUD";

export default function AdminPages() {
  const [editItem, setEditItem] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<any>({});
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.pages.list.useQuery();
  const upsertMutation = trpc.pages.upsert.useMutation({ onSuccess: () => { toast.success("تم حفظ الصفحة"); utils.pages.list.invalidate(); setShowForm(false); setEditItem(null); }, onError: (e) => toast.error(e.message) });
  const set = (k: string, v: string) => setForm((p: any) => ({ ...p, [k]: v }));
  const handleOpen = (item?: any) => { setForm(item ?? { status: "published" }); item ? setEditItem(item) : setShowForm(true); };
  return (
    <AdminLayout title="إدارة الصفحات">
      <div className="space-y-4">
        <h1 className="text-xl font-black">إدارة الصفحات</h1>
        <ContentTable
          data={data ?? []} isLoading={isLoading} emptyMessage="لا توجد صفحات"
          onAdd={() => handleOpen()} addLabel="إضافة صفحة"
          onEdit={(row) => handleOpen(row)}
          columns={[
            { key: "title", label: "العنوان", render: (r) => <span className="font-medium">{r.title}</span> },
            { key: "slug", label: "المسار", render: (r) => <span className="ltr-only text-sm text-muted-foreground">/{r.slug}</span> },
            { key: "status", label: "الحالة", render: (r) => <span className={`text-xs px-2 py-0.5 rounded-full ${r.status === "published" ? "badge-published" : "badge-draft"}`}>{r.status === "published" ? "منشور" : "مسودة"}</span> },
            { key: "updatedAt", label: "آخر تحديث", render: (r) => new Date(r.updatedAt).toLocaleDateString("ar-YE") },
          ]}
        />
      </div>
      {(showForm || editItem) && (
        <Dialog open onOpenChange={() => { setShowForm(false); setEditItem(null); }}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{editItem ? "تعديل الصفحة" : "إضافة صفحة جديدة"}</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div className="space-y-1.5"><Label>العنوان *</Label><Input value={form.title ?? ""} onChange={(e) => set("title", e.target.value)} required /></div>
              <div className="space-y-1.5"><Label>المسار (slug) *</Label><Input value={form.slug ?? ""} onChange={(e) => set("slug", e.target.value)} placeholder="about, vision, ..." className="ltr-only" required /></div>
              <div className="space-y-1.5"><Label>المحتوى</Label><Textarea value={form.content ?? ""} onChange={(e) => set("content", e.target.value)} rows={8} placeholder="يدعم Markdown..." /></div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5"><Label>عنوان SEO</Label><Input value={form.metaTitle ?? ""} onChange={(e) => set("metaTitle", e.target.value)} /></div>
                <div className="space-y-1.5"><Label>الحالة</Label>
                  <Select value={form.status ?? "published"} onValueChange={(v) => set("status", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="published">منشور</SelectItem><SelectItem value="draft">مسودة</SelectItem></SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5"><Label>وصف SEO</Label><Textarea value={form.metaDescription ?? ""} onChange={(e) => set("metaDescription", e.target.value)} rows={2} /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => { setShowForm(false); setEditItem(null); }}>إلغاء</Button>
              <Button className="gradient-gold text-black font-semibold border-0" onClick={() => upsertMutation.mutate(form)} disabled={upsertMutation.isPending}>حفظ</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </AdminLayout>
  );
}


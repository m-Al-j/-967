import { useState } from "react";
import { AdminLayout } from "@/components/AdminLayout";
import { ContentTable, ContentFormDialog } from "@/components/AdminCRUD";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function AdminKnowledge() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [editItem, setEditItem] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);
  const utils = trpc.useUtils();
  const { data, isLoading } = trpc.knowledge.list.useQuery({ page, limit: 20, search: debouncedSearch || undefined });
  const createMutation = trpc.knowledge.create.useMutation({ onSuccess: () => { toast.success("تم إنشاء المقالة"); utils.knowledge.list.invalidate(); setShowForm(false); }, onError: (e) => toast.error(e.message) });
  const updateMutation = trpc.knowledge.update.useMutation({ onSuccess: () => { toast.success("تم تحديث المقالة"); utils.knowledge.list.invalidate(); setEditItem(null); }, onError: (e) => toast.error(e.message) });
  const deleteMutation = trpc.knowledge.delete.useMutation({ onSuccess: () => { toast.success("تم حذف المقالة"); utils.knowledge.list.invalidate(); }, onError: (e) => toast.error(e.message) });
  const handleSearch = (v: string) => { setSearch(v); clearTimeout((window as any).__knowledgeAdminTimer); (window as any).__knowledgeAdminTimer = setTimeout(() => { setDebouncedSearch(v); setPage(1); }, 400); };
  return (
    <AdminLayout title="إدارة قاعدة المعرفة">
      <div className="space-y-4">
        <h1 className="text-xl font-black">إدارة قاعدة المعرفة</h1>
        <ContentTable
          data={data?.items ?? []} total={data?.total} page={page} limit={20} isLoading={isLoading}
          search={search} onSearchChange={handleSearch} onPageChange={setPage}
          onAdd={() => setShowForm(true)} addLabel="إضافة مقالة" emptyMessage="لا توجد مقالات"
          onEdit={(row) => setEditItem(row)} onDelete={(row) => deleteMutation.mutate({ id: row.id })}
          columns={[
            { key: "title", label: "العنوان", render: (r) => <span className="font-medium line-clamp-1">{r.title}</span> },
            { key: "category", label: "التصنيف", render: (r) => r.category ?? "—" },
            { key: "status", label: "الحالة", render: (r) => <span className={`text-xs px-2 py-0.5 rounded-full ${r.status === "published" ? "badge-published" : r.status === "draft" ? "badge-draft" : "badge-archived"}`}>{r.status === "published" ? "منشور" : r.status === "draft" ? "مسودة" : "مؤرشف"}</span> },
            { key: "viewCount", label: "المشاهدات", render: (r) => r.viewCount.toLocaleString("ar") },
            { key: "createdAt", label: "التاريخ", render: (r) => new Date(r.createdAt).toLocaleDateString("ar-YE") },
          ]}
        />
      </div>
      <ContentFormDialog open={showForm || !!editItem} onClose={() => { setShowForm(false); setEditItem(null); }} title={editItem ? "تعديل المقالة" : "إضافة مقالة جديدة"} defaultValues={editItem} isLoading={createMutation.isPending || updateMutation.isPending} onSubmit={(data) => editItem ? updateMutation.mutate({ id: editItem.id, ...data }) : createMutation.mutate(data)} />
    </AdminLayout>
  );
}


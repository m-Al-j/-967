import { AdminLayout } from "@/components/AdminLayout";
import { trpc } from "@/lib/trpc";
import { ContentTable } from "@/components/AdminCRUD";
import { useState } from "react";

export default function AdminActivity() {
  const [page, setPage] = useState(1);
  const { data, isLoading } = trpc.audit.list.useQuery({ page, limit: 50 });
  return (
    <AdminLayout title="سجل النشاط">
      <div className="space-y-4">
        <h1 className="text-xl font-black">سجل النشاط</h1>
        <p className="text-sm text-muted-foreground">جميع العمليات التي تمت على المنصة مرتبة زمنياً</p>
        <ContentTable
          data={data?.items ?? []} total={data?.total} page={page} limit={50} isLoading={isLoading} onPageChange={setPage} emptyMessage="لا يوجد نشاط"
          columns={[
            { key: "action", label: "الإجراء", render: (r) => <span className="font-medium text-sm">{r.action}</span> },
            { key: "entity", label: "الكيان", render: (r) => r.entity ?? "—" },
            { key: "userId", label: "المستخدم", render: (r) => r.userId ?? "—" },
            { key: "createdAt", label: "الوقت", render: (r) => new Date(r.createdAt).toLocaleString("ar-YE") },
          ]}
        />
      </div>
    </AdminLayout>
  );
}

import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";

export default function Terms() {
  return (
    <PublicLayout>
      <PageSEO title="شروط الاستخدام" description="شروط استخدام منصة حركة 967" />
      <section className="bg-surface text-surface-foreground py-16"><div className="container"><h1 className="text-3xl font-black text-surface-foreground">شروط الاستخدام</h1><p className="text-surface-foreground/60 text-sm mt-2">آخر تحديث: {new Date().toLocaleDateString("ar-YE", { year: "numeric", month: "long" })}</p></div></section>
      <section className="py-10">
        <div className="container max-w-3xl prose-arabic text-foreground space-y-6">
          {[
            { title: "قبول الشروط", content: "باستخدامك لمنصة حركة 967، فإنك توافق على الالتزام بهذه الشروط والأحكام." },
            { title: "استخدام المنصة", content: "يُسمح باستخدام المنصة للأغراض المشروعة فقط. يُحظر نشر أي محتوى مسيء أو مضلل أو ينتهك حقوق الآخرين." },
            { title: "الملكية الفكرية", content: "جميع المحتويات المنشورة على المنصة محمية بحقوق الملكية الفكرية. لا يجوز إعادة نشرها دون إذن مسبق." },
            { title: "المسؤولية", content: "حركة 967 غير مسؤولة عن أي أضرار ناتجة عن استخدام المنصة أو عدم القدرة على الوصول إليها." },
            { title: "التعديلات", content: "نحتفظ بالحق في تعديل هذه الشروط في أي وقت. سيتم إخطارك بأي تغييرات جوهرية." },
          ].map(({ title, content }) => (
            <div key={title}>
              <h2 className="text-xl font-bold mb-2">{title}</h2>
              <p className="text-muted-foreground leading-relaxed">{content}</p>
            </div>
          ))}
        </div>
      </section>
    </PublicLayout>
  );
}


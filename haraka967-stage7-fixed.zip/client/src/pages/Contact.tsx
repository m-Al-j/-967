import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Mail, Phone, MapPin, CheckCircle } from "lucide-react";
import { toast } from "sonner";

const schema = z.object({
  name: z.string().min(3, "الاسم مطلوب"),
  email: z.string().email("البريد الإلكتروني غير صحيح"),
  subject: z.string().min(5, "الموضوع مطلوب"),
  message: z.string().min(20, "الرسالة يجب أن تكون 20 حرفاً على الأقل"),
});

export default function Contact() {
  const [sent, setSent] = useState(false);
  const { data: settings } = trpc.settings.get.useQuery();
  const contactMutation = trpc.contact.submit.useMutation({
    onSuccess: () => {
      setSent(true);
      toast.success("تم إرسال رسالتك بنجاح!");
    },
    onError: (error) => toast.error(error.message),
  });
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(schema) });
  const onSubmit = async (data: any) => {
    await contactMutation.mutateAsync(data);
  };
  return (
    <PublicLayout>
      <PageSEO title="تواصل معنا" description="تواصل مع فريق حركة 967" />
      <section className="bg-surface text-surface-foreground py-16">
        <div className="container"><div className="text-primary text-sm font-medium mb-2">التواصل</div><h1 className="text-3xl font-black text-surface-foreground">تواصل معنا</h1></div>
      </section>
      <section className="py-10">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="space-y-6">
              {[{ icon: Mail, label: "البريد الإلكتروني", value: settings?.find((s) => s.key === "site_email")?.value || settings?.find((s) => s.key === "join_requests_email")?.value || "غير محدد" }, { icon: Phone, label: "الهاتف", value: settings?.find((s) => s.key === "owner_phone")?.value || "غير محدد" }, { icon: MapPin, label: "الموقع", value: settings?.find((s) => s.key === "owner_location")?.value || "اليمن" }].map(({ icon: Icon, label, value }) => (
                <div key={label} className="flex gap-3 p-4 rounded-lg border border-border bg-card">
                  <div className="w-10 h-10 rounded-lg gradient-gold flex items-center justify-center shrink-0"><Icon className="w-5 h-5 text-black" /></div>
                  <div><div className="text-xs text-muted-foreground">{label}</div><div className="font-medium text-sm mt-0.5">{value}</div></div>
                </div>
              ))}
            </div>
            <div className="lg:col-span-2">
              {sent ? (
                <div className="text-center py-12">
                  <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-4" />
                  <h2 className="text-xl font-bold mb-2">تم إرسال رسالتك!</h2>
                  <p className="text-muted-foreground">سنتواصل معك في أقرب وقت ممكن.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 bg-card border border-border rounded-xl p-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5"><Label>الاسم *</Label><Input {...register("name")} placeholder="اسمك الكامل" />{errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}</div>
                    <div className="space-y-1.5"><Label>البريد الإلكتروني *</Label><Input type="email" {...register("email")} placeholder="example@email.com" className="ltr-only" />{errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}</div>
                  </div>
                  <div className="space-y-1.5"><Label>الموضوع *</Label><Input {...register("subject")} placeholder="موضوع رسالتك" />{errors.subject && <p className="text-xs text-destructive">{errors.subject.message}</p>}</div>
                  <div className="space-y-1.5"><Label>الرسالة *</Label><Textarea {...register("message")} placeholder="اكتب رسالتك هنا..." rows={5} />{errors.message && <p className="text-xs text-destructive">{errors.message.message}</p>}</div>
                  <Button type="submit" className="w-full gradient-gold text-black font-semibold border-0" disabled={isSubmitting || contactMutation.isPending}>{isSubmitting || contactMutation.isPending ? "جارٍ الإرسال..." : "إرسال الرسالة"}</Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}

import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";

export default function Privacy() {
  return (
    <PublicLayout>
      <PageSEO title="سياسة الخصوصية" description="سياسة خصوصية حركة 967" />
      <section className="bg-surface text-surface-foreground py-16"><div className="container"><h1 className="text-3xl font-black text-surface-foreground">سياسة الخصوصية</h1><p className="text-surface-foreground/60 text-sm mt-2">آخر تحديث: {new Date().toLocaleDateString("ar-YE", { year: "numeric", month: "long" })}</p></div></section>
      <section className="py-10">
        <div className="container max-w-3xl prose-arabic text-foreground space-y-6">
          {[
            { title: "جمع المعلومات", content: "نجمع المعلومات التي تقدمها طوعاً عند التسجيل أو تقديم طلب الانضمام، وتشمل الاسم والبريد الإلكتروني ورقم الهاتف والموقع الجغرافي." },
            { title: "استخدام المعلومات", content: "نستخدم معلوماتك لمعالجة طلبات الانضمام، والتواصل معك بشأن أنشطة الحركة، وتحسين خدماتنا. لن نبيع أو نشارك معلوماتك مع أطراف ثالثة دون موافقتك." },
            { title: "حماية البيانات", content: "نتخذ إجراءات أمنية مناسبة لحماية معلوماتك من الوصول غير المصرح به أو الإفصاح أو التعديل أو الإتلاف." },
            { title: "حقوقك", content: "يحق لك الوصول إلى معلوماتك الشخصية وتصحيحها أو حذفها في أي وقت. يمكنك التواصل معنا عبر البريد الإلكتروني لممارسة هذه الحقوق." },
          ].map(({ title, content }) => (
            <div key={title}>
              <h2 className="text-xl font-bold mb-2">{title}</h2>
              <p className="text-muted-foreground leading-relaxed">{content}</p>
            </div>
          ))}
        </div>
      </section>
    </PublicLayout>
  );
}

import { useParams, Link } from "wouter";
import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";
import { PageLoadingSpinner } from "@/components/LoadingState";
import { trpc } from "@/lib/trpc";
import { Calendar, Eye, Tag, ArrowRight, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Streamdown } from "streamdown";

export default function NewsDetail() {
  const { slug } = useParams<{ slug: string }>();
  const { data, isLoading, error } = trpc.news.get.useQuery({ slug: slug ?? "" }, { enabled: !!slug });

  if (isLoading) return <PublicLayout><PageLoadingSpinner /></PublicLayout>;
  if (error || !data) return (
    <PublicLayout>
      <div className="container py-20 text-center">
        <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
        <h1 className="text-xl font-bold mb-2">الخبر غير موجود</h1>
        <Link href="/news" className="text-primary hover:underline text-sm">العودة إلى الأخبار</Link>
      </div>
    </PublicLayout>
  );

  const formattedDate = new Date(data.publishedAt ?? data.createdAt).toLocaleDateString("ar-YE", { year: "numeric", month: "long", day: "numeric" });

  return (
    <PublicLayout>
      <PageSEO title={data.title} description={data.excerpt ?? undefined} image={data.coverImage ?? undefined} type="article" />

      <article className="py-10">
        <div className="container max-w-3xl">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
            <Link href="/" className="hover:text-foreground">الرئيسية</Link>
            <span>/</span>
            <Link href="/news" className="hover:text-foreground">الأخبار</Link>
            <span>/</span>
            <span className="text-foreground line-clamp-1">{data.title}</span>
          </nav>

          {/* Category */}
          {data.category && (
            <div className="flex items-center gap-1.5 mb-3">
              <Tag className="w-3.5 h-3.5 text-primary" />
              <span className="text-sm text-primary font-medium">{data.category}</span>
            </div>
          )}

          <h1 className="text-3xl sm:text-4xl font-black leading-tight mb-4">{data.title}</h1>

          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-6">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4" />
              <span>{formattedDate}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Eye className="w-4 h-4" />
              <span>{data.viewCount.toLocaleString("ar")} مشاهدة</span>
            </div>
          </div>

          {data.coverImage && (
            <div className="rounded-xl overflow-hidden mb-8 aspect-video">
              <img src={data.coverImage} alt={data.title} className="w-full h-full object-cover" />
            </div>
          )}

          {data.excerpt && (
            <p className="text-lg text-muted-foreground leading-relaxed border-r-4 border-primary pr-4 mb-8 font-medium">{data.excerpt}</p>
          )}

          <div className="prose-arabic text-foreground">
            <Streamdown>{data.content}</Streamdown>
          </div>

          {data.tags && data.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-8 pt-6 border-t border-border">
              {data.tags.map((tag) => (
                <Badge key={tag} variant="secondary">{tag}</Badge>
              ))}
            </div>
          )}

          <div className="mt-8 pt-6 border-t border-border">
            <Link href="/news" className="flex items-center gap-2 text-primary hover:underline text-sm font-medium">
              <ArrowRight className="w-4 h-4" />
              العودة إلى الأخبار
            </Link>
          </div>
        </div>
      </article>
    </PublicLayout>
  );
}

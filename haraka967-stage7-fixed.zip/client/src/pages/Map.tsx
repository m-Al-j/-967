import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";
import { trpc } from "@/lib/trpc";
import { MapView } from "@/components/Map";
import { PageLoadingSpinner } from "@/components/LoadingState";

function buildInfoWindowContent(options: {
  title: string;
  description?: string | null;
  location?: string | null;
  imageUrl?: string | null;
}) {
  const wrapper = document.createElement("div");
  wrapper.dir = "rtl";
  wrapper.style.fontFamily = "Cairo, sans-serif";
  wrapper.style.padding = "8px";
  wrapper.style.maxWidth = "220px";

  if (options.imageUrl) {
    const img = document.createElement("img");
    img.src = options.imageUrl;
    img.alt = options.title;
    img.style.width = "100%";
    img.style.height = "100px";
    img.style.objectFit = "cover";
    img.style.borderRadius = "6px";
    img.style.marginBottom = "6px";
    wrapper.appendChild(img);
  }

  const titleEl = document.createElement("strong");
  titleEl.style.fontSize = "14px";
  titleEl.textContent = options.title;
  wrapper.appendChild(titleEl);

  if (options.description) {
    const desc = document.createElement("p");
    desc.style.fontSize = "12px";
    desc.style.color = "#666";
    desc.style.marginTop = "4px";
    desc.textContent = options.description;
    wrapper.appendChild(desc);
  }

  if (options.location) {
    const loc = document.createElement("span");
    loc.style.fontSize = "11px";
    loc.style.color = "#999";
    loc.textContent = options.location;
    wrapper.appendChild(loc);
  }

  return wrapper;
}


export default function MapPage() {
  const { data: points, isLoading } = trpc.map.list.useQuery({ status: "active" });
  const { data: projectsData, isLoading: projectsLoading } = trpc.projects.list.useQuery({ page: 1, limit: 100, status: "published" });
  const geoProjects = (projectsData?.items ?? []).filter(
    (p: any) => typeof p.latitude === "number" && typeof p.longitude === "number"
  );

  return (
    <PublicLayout>
      <PageSEO title="الخريطة التفاعلية" description="خريطة تفاعلية لمشاريع ونشاطات حركة 967 في اليمن" />
      <section className="bg-surface text-surface-foreground py-12">
        <div className="container">
          <div className="text-primary text-sm font-medium mb-2">الخريطة</div>
          <h1 className="text-3xl font-black text-surface-foreground mb-2">الخريطة التفاعلية</h1>
          <p className="text-surface-foreground/60 text-sm">تعرف على توزيع نشاطاتنا ومشاريعنا في اليمن</p>
        </div>
      </section>

      <section className="py-6">
        <div className="container">
          {isLoading || projectsLoading ? (
            <PageLoadingSpinner />
          ) : (
            <div className="rounded-xl overflow-hidden border border-border" style={{ height: "600px" }}>
              <MapView
                onMapReady={(map) => {
                  geoProjects.forEach((project: any) => {
                    const marker = new google.maps.Marker({
                      position: { lat: project.latitude, lng: project.longitude },
                      map,
                      title: project.title,
                      icon: {
                        path: google.maps.SymbolPath.CIRCLE,
                        scale: 8,
                        fillColor: "#C9A227",
                        fillOpacity: 1,
                        strokeColor: "#ffffff",
                        strokeWeight: 2,
                      },
                    });
                    const infoWindow = new google.maps.InfoWindow({
                      content: buildInfoWindowContent({
                        title: project.title,
                        description: project.excerpt,
                        location: project.location,
                        imageUrl: project.imageUrl,
                      }),
                    });
                    marker.addListener("click", () => infoWindow.open(map, marker));
                  });

                  // Center on Yemen
                  map.setCenter({ lat: 15.5527, lng: 48.5164 });
                  map.setZoom(6);

                  if (!points?.length) return;
                  points.forEach((point: any) => {
                    const marker = new google.maps.Marker({
                      position: { lat: point.lat, lng: point.lng },
                      map,
                      title: point.title,
                    });
                    const infoWindow = new google.maps.InfoWindow({
                      content: buildInfoWindowContent({
                        title: point.title,
                        description: point.description,
                        location: point.governorate,
                      }),
                    });
                    marker.addListener("click", () => infoWindow.open(map, marker));
                  });
                  // Center on Yemen
                  map.setCenter({ lat: 15.5527, lng: 48.5164 });
                  map.setZoom(6);
                }}
              />
            </div>
          )}

          {points && points.length > 0 && (
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {points.slice(0, 6).map((point: any) => (
                <div key={point.id} className="flex gap-3 p-4 rounded-lg border border-border bg-card">
                  <div className="w-2 h-2 rounded-full bg-primary mt-1.5 shrink-0" />
                  <div>
                    <div className="font-semibold text-sm">{point.title}</div>
                    {point.governorate && <div className="text-xs text-muted-foreground mt-0.5">{point.governorate}</div>}
                    {point.description && <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{point.description}</div>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </PublicLayout>
  );
}

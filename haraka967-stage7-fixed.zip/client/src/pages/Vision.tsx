import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";
import { Lightbulb, Rocket, Shield, Star } from "lucide-react";

const pillars = [
  { icon: Lightbulb, title: "التعليم والمعرفة", desc: "بناء مجتمع معرفي يمني قادر على مواجهة تحديات المستقبل" },
  { icon: Rocket, title: "الابتكار والتطوير", desc: "تشجيع الأفكار الإبداعية والحلول التقنية للمشكلات المحلية" },
  { icon: Shield, title: "السلام والاستقرار", desc: "دعم مبادرات السلام والمصالحة الوطنية" },
  { icon: Star, title: "التميز والريادة", desc: "تمكين الشباب اليمني ليكون رائداً في مجاله" },
];

export default function Vision() {
  return (
    <PublicLayout>
      <PageSEO title="رؤيتنا" description="رؤية حركة 967 نحو يمن متحد ومزدهر" />

      <section className="bg-surface text-surface-foreground py-20">
        <div className="container max-w-2xl">
          <div className="text-primary text-sm font-medium mb-3">رؤيتنا</div>
          <h1 className="text-4xl font-black mb-4 text-surface-foreground">نحو يمن أفضل</h1>
          <p className="text-surface-foreground/70 text-lg leading-relaxed">
            نرى يمناً متحداً ومزدهراً يقوده شباب واعٍ وفاعل، قادر على بناء مستقبله بأيديه.
          </p>
          <p className="mt-4 text-sm italic text-surface-foreground/60">وطنٌ يجمعنا، وأثرٌ نصنعه معًا.</p>
        </div>
      </section>

      <section className="py-16">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-2xl font-black mb-4">رؤيتنا لعام 2030</h2>
            <p className="text-muted-foreground leading-relaxed">
              نطمح إلى أن تكون حركة 967 المرجع الأول للشباب اليمني الراغب في المساهمة الفاعلة في إعادة بناء الوطن، من خلال شبكة واسعة من الكوادر المؤهلة في كل محافظات اليمن.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {pillars.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="flex gap-4 p-6 rounded-xl bg-card border border-border">
                <div className="w-12 h-12 rounded-xl gradient-gold flex items-center justify-center shrink-0">
                  <Icon className="w-6 h-6 text-black" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">{title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}

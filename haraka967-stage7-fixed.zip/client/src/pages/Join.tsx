import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { CheckCircle2, ChevronLeft, ChevronRight, FileText, Loader2, ShieldCheck, Users, BriefcaseBusiness, Code2, Megaphone, BadgeCheck, Paperclip, X } from "lucide-react";
import { toast } from "sonner";
import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { apiUrl } from "@/lib/api";
import {
  joinApplicationSchema,
  joinTeamOptions,
  getQuestionsForTeam,
  getTeamLabel,
  hasMeaningfulAnswer,
  hasMeaningfulName,
  isValidAge,
  isValidLocation,
  isValidPhone,
  normalizePhone,
  normalizeText,
  cvUploadSchema,
  type JoinApplicationInput,
  type JoinTeam,
} from "@shared/join";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";

const MAX_CV_SIZE = 10 * 1024 * 1024;
const ALLOWED_CV_MIME_TYPES = new Set([
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
]);

const stepLabels = [
  "البيانات الشخصية والأساسية",
  "اختيار فريق العمل",
  "التقييم التخصصي",
  "الإقرار النهائي",
] as const;

const personalStepSchema = z.object({
  fullName: z.string().trim().refine(hasMeaningfulName, {
    message: "يرجى كتابة الاسم الثلاثي بشكل صحيح",
  }),
  email: z.string().trim().email("البريد الإلكتروني غير صحيح"),
  phone: z
    .union([z.string(), z.undefined(), z.null()])
    .transform((value) => {
      if (typeof value !== "string") return undefined;
      const normalized = normalizePhone(value);
      return normalized ? normalized : undefined;
    })
    .optional()
    .refine((value) => value === undefined || isValidPhone(value), {
      message: "رقم الهاتف غير صحيح",
    }),
  gender: z.string().refine((value) => value === "male" || value === "female", {
    message: "يرجى اختيار الجنس",
  }),
  birthPlace: z.string().trim().refine(isValidLocation, {
    message: "يرجى كتابة محل الميلاد بشكل صحيح",
  }),
  age: z
    .preprocess((value) => {
      if (value === "" || value === null || value === undefined) return undefined;
      const next = typeof value === "number" ? value : Number(value);
      return Number.isNaN(next) ? undefined : next;
    }, z.number().int().optional())
    .refine((value) => value === undefined || isValidAge(value), {
      message: "العمر غير منطقي",
    }),
  currentAddress: z.string().trim().refine(isValidLocation, {
    message: "يرجى كتابة العنوان الحالي بشكل صحيح",
  }),
  cvFile: cvUploadSchema.optional(),
});

const teamStepSchema = z.object({
  selectedTeam: z.string().refine((value): value is JoinTeam => ["governance", "membership", "projects", "tech", "media"].includes(value as JoinTeam), {
    message: "يرجى اختيار فريق العمل",
  }),
});

const agreementStepSchema = z.object({
  agreement: z.boolean().refine((value) => value === true, {
    message: "يجب الموافقة على الإقرار",
  }),
});

type JoinFormValues = {
  fullName: string;
  email: string;
  phone?: string;
  gender?: "male" | "female";
  birthPlace: string;
  age?: number;
  currentAddress: string;
  cvFile?: JoinApplicationInput["cvFile"];
  selectedTeam?: JoinTeam;
  answers: Record<string, string>;
  agreement: boolean;
};

function mapZodIssues(issues: z.ZodIssue[], setError: any) {
  for (const issue of issues) {
    const path = issue.path.join(".") as any;
    if (!path) continue;
    setError(path, { type: "manual", message: issue.message });
  }
}

function getDefaultAnswers(team: JoinTeam | undefined) {
  const questions = team ? getQuestionsForTeam(team) : [];
  return questions.reduce<Record<string, string>>((acc, question) => {
    acc[question.id] = "";
    return acc;
  }, {});
}

function formatAge(value?: number) {
  if (typeof value !== "number" || Number.isNaN(value)) return "—";
  return `${value}`;
}

function valueOrDash(value?: string | number | null) {
  if (value === undefined || value === null || value === "") return "—";
  return String(value);
}

export default function Join() {
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [applicantId, setApplicantId] = useState<string | null>(null);
  const [uploadingCv, setUploadingCv] = useState(false);
  const [cvError, setCvError] = useState<string | null>(null);
  const utils = trpc.useUtils();

  const {
    register,
    handleSubmit,
    setValue,
    setError,
    clearErrors,
    watch,
    getValues,
    formState: { errors },
  } = useForm<JoinFormValues>({
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      gender: undefined,
      birthPlace: "",
      age: undefined,
      currentAddress: "",
      cvFile: undefined,
      selectedTeam: undefined,
      answers: {},
      agreement: false,
    },
    mode: "onBlur",
  });

  const selectedTeam = watch("selectedTeam");
  const answers = watch("answers");
  const cvFile = watch("cvFile");
  const questions = useMemo(() => (selectedTeam ? getQuestionsForTeam(selectedTeam) : []), [selectedTeam]);

  useEffect(() => {
    if (!selectedTeam) return;
    setValue("answers", getDefaultAnswers(selectedTeam), { shouldDirty: true, shouldTouch: true });
    clearErrors("answers");
  }, [selectedTeam, clearErrors, setValue]);

  const submitMutation = trpc.applications.submit.useMutation({
    onSuccess: async (data) => {
      setApplicantId(data?.applicantId ?? null);
      setSubmitted(true);
      toast.success("تم تقديم الطلب بنجاح. الطلب الآن بحالة Pending");
      await utils.applications.list.invalidate();
    },
    onError: (error) => toast.error(error.message || "حدث خطأ أثناء إرسال الطلب"),
  });

  const totalSteps = stepLabels.length;

  async function validateStep(stepIndex: number): Promise<boolean> {
    const values = getValues();
    clearErrors();

    if (stepIndex === 0) {
      const result = personalStepSchema.safeParse(values);
      if (!result.success) {
        mapZodIssues(result.error.issues, setError);
        return false;
      }
      return true;
    }

    if (stepIndex === 1) {
      const result = teamStepSchema.safeParse(values);
      if (!result.success) {
        mapZodIssues(result.error.issues, setError);
        return false;
      }
      return true;
    }

    if (stepIndex === 2) {
      const team = values.selectedTeam;
      const base = teamStepSchema.safeParse(values);
      if (!base.success) {
        mapZodIssues(base.error.issues, setError);
        return false;
      }
      if (!team) {
        setError("selectedTeam", { type: "manual", message: "يرجى اختيار الفريق أولًا" });
        return false;
      }
      const teamQuestions = getQuestionsForTeam(team);
      let valid = true;
      for (const question of teamQuestions) {
        const answer = normalizeText(values.answers?.[question.id] ?? "");
        if (!answer) {
          setError(`answers.${question.id}` as any, {
            type: "manual",
            message: "هذه الإجابة مطلوبة",
          });
          valid = false;
          continue;
        }
        if (!hasMeaningfulAnswer(answer)) {
          setError(`answers.${question.id}` as any, {
            type: "manual",
            message: "يرجى كتابة إجابة أكثر تفصيلًا توضح طريقة تفكيرك أو تجربتك.",
          });
          valid = false;
        }
      }
      const allowed = new Set(teamQuestions.map((question) => question.id));
      for (const key of Object.keys(values.answers ?? {})) {
        if (!allowed.has(key)) {
          setError(`answers.${key}` as any, {
            type: "manual",
            message: "هذا السؤال لا ينتمي للفريق المختار",
          });
          valid = false;
        }
      }
      return valid;
    }

    const agreementResult = agreementStepSchema.safeParse(values);
    if (!agreementResult.success) {
      mapZodIssues(agreementResult.error.issues, setError);
      return false;
    }
    return true;
  }

  async function handleNext() {
    const valid = await validateStep(step);
    if (!valid) return;
    if (step < totalSteps - 1) setStep((current) => current + 1);
  }

  async function onSubmit(values: JoinFormValues) {
    const finalPayload = joinApplicationSchema.safeParse({
      ...values,
      selectedTeam: values.selectedTeam,
      answers: values.answers,
      cvFile: values.cvFile ?? undefined,
    });

    if (!finalPayload.success) {
      mapZodIssues(finalPayload.error.issues, setError);
      const firstIssue = finalPayload.error.issues[0];
      if (firstIssue?.path[0] === "selectedTeam" || firstIssue?.path[0] === "answers") {
        setStep(2);
      } else if (firstIssue?.path[0] === "agreement") {
        setStep(3);
      } else {
        setStep(0);
      }
      toast.error("هناك حقول تحتاج إلى مراجعة قبل الإرسال");
      return;
    }

    submitMutation.mutate(finalPayload.data);
  }

  async function uploadCv(file: File | null) {
    setCvError(null);
    clearErrors("cvFile" as any);
    if (!file) return;
    if (file.size > MAX_CV_SIZE) {
      const message = "حجم الملف كبير جدًا. الحد الأقصى 10 ميغابايت.";
      setCvError(message);
      setError("cvFile" as any, { type: "manual", message });
      return;
    }
    if (!ALLOWED_CV_MIME_TYPES.has(file.type)) {
      const message = "نوع الملف غير مدعوم. استخدم PDF أو DOC أو DOCX.";
      setCvError(message);
      setError("cvFile" as any, { type: "manual", message });
      return;
    }

    const formData = new FormData();
    formData.append("purpose", "cv");
    formData.append("file", file);
    setUploadingCv(true);
    try {
      const response = await fetch(apiUrl("/api/files/upload"), {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      const payload = (await response.json()) as
        | { success: true; url: string; key: string; originalName: string }
        | { error: string };
      if (!response.ok || !("success" in payload)) {
        throw new Error((payload as { error?: string }).error || "فشل رفع الملف");
      }
      const uploaded = {
        url: payload.url,
        key: payload.key,
        originalName: payload.originalName,
        mimeType: file.type,
        size: file.size,
      };
      setValue("cvFile", uploaded, { shouldDirty: true, shouldTouch: true, shouldValidate: true });
      toast.success("تم رفع السيرة الذاتية بنجاح");
    } catch (error) {
      const message = error instanceof Error ? error.message : "تعذر رفع الملف";
      setCvError(message);
      setError("cvFile" as any, { type: "manual", message });
      toast.error(message);
    } finally {
      setUploadingCv(false);
    }
  }

  function removeCv() {
    setValue("cvFile", undefined, { shouldDirty: true, shouldTouch: true, shouldValidate: true });
    setCvError(null);
    clearErrors("cvFile" as any);
  }

  if (submitted) {
    return (
      <PublicLayout>
        <PageSEO title="تم إرسال الطلب" description="تم تقديم طلب الانضمام إلى حركة 967 بنجاح" />
        <section className="py-24">
          <div className="container max-w-2xl text-center">
            <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300">
              <CheckCircle2 className="h-10 w-10" aria-hidden="true" />
            </div>
            <h1 className="text-3xl font-black">تم تقديم طلبك بنجاح</h1>
            <p className="mt-3 text-muted-foreground">
              تم حفظ الطلب في قاعدة البيانات بحالة <span className="font-semibold">Pending</span>، وسيتم مراجعته من الفريق المختص.
            </p>
            <p className="mt-3 text-sm italic text-muted-foreground">مكانك بين من يؤمنون أن التغيير يبدأ منّا.</p>
            {applicantId && (
              <div className="mt-6 rounded-xl border border-border bg-card p-5">
                <div className="text-sm text-muted-foreground">معرّف المتقدم الخاص بك</div>
                <div className="mt-2 text-2xl font-black tracking-widest text-primary" dir="ltr">{applicantId}</div>
                <p className="mt-2 text-xs text-muted-foreground">احتفظ بهذا المعرّف لمتابعة حالة طلبك.</p>
              </div>
            )}
            <Button className="mt-8 gradient-gold border-0 font-semibold text-black" onClick={() => window.location.assign("/")}>العودة للرئيسية</Button>
          </div>
        </section>
      </PublicLayout>
    );
  }

  const currentSummary = getValues();
  const selectedQuestions = selectedTeam ? getQuestionsForTeam(selectedTeam) : [];

  return (
    <PublicLayout>
      <PageSEO title="استمارة الانضمام والتطوع" description="نموذج الانضمام والتطوع في حركة 967 مع أسئلة تخصصية بحسب الفريق المختار" />
      <section className="border-b border-border bg-surface py-16 text-surface-foreground">
        <div className="container max-w-4xl">
          <div className="mb-3 text-sm font-medium text-primary">الانضمام والتطوع</div>
          <h1 className="max-w-2xl text-4xl font-black leading-tight text-surface-foreground md:text-5xl">استمارة الانضمام والتطوع — حركة 967</h1>
          <p className="mt-4 max-w-3xl text-sm leading-7 text-surface-foreground/70 md:text-base">
            املأ بياناتك الأساسية، اختر الفريق المناسب، ثم أجب فقط عن الأسئلة الخاصة به. النموذج يحفظ الطلب فعليًا ويمنع إرسال الإجابات غير المكتملة أو غير المنطقية.
          </p>
          <p className="mt-4 max-w-3xl text-sm italic text-surface-foreground/60">إن كنت ترى في اليمن ما يستحق أن نبني من أجله، فأنت في المكان الصحيح.</p>
        </div>
      </section>

      <section className="py-10 md:py-14">
        <div className="container max-w-4xl">
          <div className="mb-8 grid gap-3 md:grid-cols-4">
            {stepLabels.map((label, index) => {
              const active = index === step;
              const done = index < step;
              return (
                <div key={label} className={cn("rounded-2xl border p-4 transition-colors", active ? "border-primary bg-primary/5" : done ? "border-emerald-400/40 bg-emerald-50/60 dark:bg-emerald-950/30" : "border-border bg-card") }>
                  <div className="flex items-center gap-3">
                    <div className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-bold", done || active ? "gradient-gold text-black" : "bg-muted text-muted-foreground")}>{done ? <CheckCircle2 className="h-4 w-4" aria-hidden="true" /> : index + 1}</div>
                    <div>
                      <div className="text-xs text-muted-foreground">خطوة {index + 1} من {totalSteps}</div>
                      <div className="font-semibold">{label}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <form
            onSubmit={handleSubmit(onSubmit)}
            className="glass rounded-3xl border border-border/50 p-5 shadow-xl md:p-8"
          >
            {step === 0 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-black">البيانات الشخصية والأساسية</h2>
                  <p className="mt-2 text-sm text-muted-foreground">
                    نحتاج إلى بعض المعلومات الأساسية للتعرف عليك والتواصل معك عند الحاجة. بعض المعلومات اختيارية ويمكنك عدم مشاركتها في المرحلة الأولى.
                  </p>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="fullName">الاسم الثلاثي</Label>
                    <Input id="fullName" {...register("fullName")} placeholder="أدخل اسمك الثلاثي" />
                    {errors.fullName && <p className="text-xs text-destructive">{errors.fullName.message}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">البريد الإلكتروني</Label>
                    <Input id="email" type="email" autoComplete="email" dir="ltr" {...register("email")} placeholder="name@example.com" />
                    {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">رقم الهاتف مع رمز الدولة (اختياري)</Label>
                    <Input id="phone" dir="ltr" {...register("phone")} placeholder="+966xxxxxxxxx أو +967xxxxxxxxx" />
                    <p className="text-xs text-muted-foreground">يمكنك ترك هذا الحقل فارغًا.</p>
                    {errors.phone && <p className="text-xs text-destructive">{errors.phone.message}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label>الجنس</Label>
                    <RadioGroup
                      className="grid grid-cols-2 gap-3"
                      value={watch("gender") ?? ""}
                      onValueChange={(value) => setValue("gender", value as "male" | "female", { shouldDirty: true, shouldTouch: true, shouldValidate: true })}
                    >
                      {[
                        { value: "male", label: "ذكر" },
                        { value: "female", label: "أنثى" },
                      ].map((item) => (
                        <Label
                          key={item.value}
                          className={cn(
                            "flex cursor-pointer items-center gap-3 rounded-2xl border p-4 transition-colors",
                            watch("gender") === item.value ? "border-primary bg-primary/5" : "border-border bg-card",
                          )}
                        >
                          <RadioGroupItem value={item.value} id={item.value} />
                          <span className="font-medium">{item.label}</span>
                        </Label>
                      ))}
                    </RadioGroup>
                    {errors.gender && <p className="text-xs text-destructive">{errors.gender.message}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="birthPlace">محل الميلاد</Label>
                    <Input id="birthPlace" {...register("birthPlace")} placeholder="عدن، اليمن" />
                    <p className="text-xs text-muted-foreground">هذا الحقل يمثل محل الميلاد وليس مكان الإقامة الحالي.</p>
                    {errors.birthPlace && <p className="text-xs text-destructive">{errors.birthPlace.message}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="age">العمر (اختياري)</Label>
                    <Input id="age" type="number" inputMode="numeric" min={14} max={99} {...register("age", { valueAsNumber: true })} placeholder="مثال: 27" />
                    <p className="text-xs text-muted-foreground">يمكنك ترك هذا الحقل فارغًا.</p>
                    {errors.age && <p className="text-xs text-destructive">{errors.age.message}</p>}
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="currentAddress">العنوان الحالي (دولة الإقامة والمدينة)</Label>
                    <Input id="currentAddress" {...register("currentAddress")} placeholder="الدمام، المملكة العربية السعودية" />
                    <p className="text-xs text-muted-foreground">هذا الحقل مستقل تمامًا عن محل الميلاد.</p>
                    {errors.currentAddress && <p className="text-xs text-destructive">{errors.currentAddress.message}</p>}
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <Label>إرفاق السيرة الذاتية (إن وجدت)</Label>
                    <p className="mt-1 text-xs text-muted-foreground">PDF هو النوع المفضل. يمكنك أيضًا رفع DOC أو DOCX إذا كانت البنية الحالية تدعم ذلك.</p>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-dashed border-border bg-surface/60 p-4">
                    <label className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-border px-4 py-2 text-sm font-medium transition-colors hover:bg-background">
                      <Paperclip className="h-4 w-4" aria-hidden="true" />
                      {uploadingCv ? "جارٍ الرفع..." : "اختيار ملف"}
                      <input
                        type="file"
                        className="hidden"
                        accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        onChange={(event) => void uploadCv(event.target.files?.[0] ?? null)}
                      />
                    </label>
                    {cvFile ? (
                      <div className="flex items-center gap-2 rounded-full bg-primary/10 px-3 py-2 text-sm text-primary">
                        <FileText className="h-4 w-4" aria-hidden="true" />
                        <span className="max-w-[220px] truncate">{cvFile.originalName}</span>
                        <button type="button" onClick={removeCv} className="ml-1 rounded-full p-1 hover:bg-primary/10" aria-label="إزالة الملف">
                          <X className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">لم يتم رفع ملف بعد.</span>
                    )}
                  </div>
                  {cvError && <p className="text-xs text-destructive">{cvError}</p>}
                  {errors.cvFile && <p className="text-xs text-destructive">{String(errors.cvFile.message)}</p>}
                </div>
              </div>
            )}

            {step === 1 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-black">اختيار فريق العمل</h2>
                  <p className="mt-2 text-sm text-muted-foreground">
                    بناءً على خبراتك واهتماماتك، اختر الفريق الذي ترغب في الانضمام إليه. سيظهر لك فقط التقييم التخصصي الخاص بهذا الفريق.
                  </p>
                </div>

                <div className="grid gap-3 md:grid-cols-2">
                  {joinTeamOptions.map((team) => {
                    const active = selectedTeam === team.value;
                    return (
                      <button
                        key={team.value}
                        type="button"
                        onClick={() => {
                          setValue("selectedTeam", team.value, { shouldDirty: true, shouldTouch: true, shouldValidate: true });
                          setValue("answers", getDefaultAnswers(team.value), { shouldDirty: true, shouldTouch: true });
                          clearErrors("answers");
                        }}
                        className={cn(
                          "rounded-3xl border p-5 text-right transition-all hover:-translate-y-0.5",
                          active ? "border-primary bg-primary/5 shadow-soft" : "border-border bg-card hover:border-primary/40",
                        )}
                      >
                        <div className="flex items-start gap-3">
                          <div className={cn("flex h-10 w-10 items-center justify-center rounded-2xl", active ? "gradient-gold text-black" : "bg-muted text-muted-foreground")}>
                            {team.value === "governance" && <ShieldCheck className="h-5 w-5" aria-hidden="true" />}
                            {team.value === "membership" && <Users className="h-5 w-5" aria-hidden="true" />}
                            {team.value === "projects" && <BriefcaseBusiness className="h-5 w-5" aria-hidden="true" />}
                            {team.value === "tech" && <Code2 className="h-5 w-5" aria-hidden="true" />}
                            {team.value === "media" && <Megaphone className="h-5 w-5" aria-hidden="true" />}
                          </div>
                          <div className="space-y-1">
                            <div className="font-semibold">{team.label}</div>
                            <div className="text-xs leading-6 text-muted-foreground">
                              {team.value === "governance" && "إدارة، شفافية، حوكمة، ومتابعة مالية."}
                              {team.value === "membership" && "تنظيم الأعضاء والفروع والصلاحيات الداخلية."}
                              {team.value === "projects" && "حلول ميدانية وخدمات مجتمعية وتنفيذ عملي."}
                              {team.value === "tech" && "أنظمة، بيانات، وبناء أدوات آمنة وفعالة."}
                              {team.value === "media" && "محتوى، شراكات، ورسائل إعلامية مؤثرة."}
                            </div>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
                {errors.selectedTeam && <p className="text-xs text-destructive">{errors.selectedTeam.message}</p>}
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-black">التقييم التخصصي — {selectedTeam ? getTeamLabel(selectedTeam) : ""}</h2>
                  <p className="mt-2 text-sm text-muted-foreground">
                    سيظهر لك هنا فقط أسئلة الفريق الذي اخترته. الأسئلة الأخرى لا تظهر ولا تُرسل.
                  </p>
                </div>

                {!selectedTeam ? (
                  <div className="rounded-2xl border border-dashed border-border bg-surface p-5 text-sm text-muted-foreground">
                    يرجى اختيار الفريق أولًا.
                  </div>
                ) : (
                  <div className="space-y-5">
                    {questions.map((question) => (
                      <div key={question.id} className="rounded-3xl border border-border bg-card p-5">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <div className="text-xs font-semibold text-primary">{question.id}</div>
                            <Label className="mt-2 block text-base font-semibold leading-7">{question.label}</Label>
                            {question.hint && <p className="mt-1 text-xs text-muted-foreground">{question.hint}</p>}
                          </div>
                        </div>
                        <Textarea
                          className="mt-4 min-h-[140px]"
                          placeholder="اكتب إجابة تفصيلية وواضحة..."
                          {...register(`answers.${question.id}` as const)}
                        />
                        {(() => {
                          const answerError = errors.answers as Record<string, { message?: string }> | undefined;
                          return answerError?.[question.id]?.message ? (
                            <p className="mt-2 text-xs text-destructive">{answerError[question.id]?.message}</p>
                          ) : null;
                        })()}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-xl font-black">الإقرار النهائي</h2>
                  <p className="mt-2 text-sm text-muted-foreground">
                    راجع بياناتك قبل الإرسال. الطلب سينتقل إلى حالة <span className="font-semibold">Pending</span> بعد الحفظ.
                  </p>
                </div>

                <div className="grid gap-4 rounded-3xl border border-border bg-surface/60 p-5 md:grid-cols-2">
                  <SummaryRow label="الاسم" value={currentSummary.fullName} />
                  <SummaryRow label="البريد الإلكتروني" value={currentSummary.email} />
                  <SummaryRow label="رقم الهاتف" value={currentSummary.phone || "غير مذكور"} />
                  <SummaryRow label="الجنس" value={currentSummary.gender === "male" ? "ذكر" : currentSummary.gender === "female" ? "أنثى" : "—"} />
                  <SummaryRow label="محل الميلاد" value={currentSummary.birthPlace} />
                  <SummaryRow label="العمر" value={formatAge(currentSummary.age)} />
                  <SummaryRow label="العنوان الحالي" value={currentSummary.currentAddress} />
                  <SummaryRow label="الفريق المختار" value={selectedTeam ? getTeamLabel(selectedTeam) : "—"} />
                </div>

                {selectedTeam && (
                  <div className="space-y-3">
                    <div className="font-semibold">إجابات الفريق المختار</div>
                    <div className="space-y-3">
                      {selectedQuestions.map((question) => (
                        <div key={question.id} className="rounded-2xl border border-border bg-card p-4">
                          <div className="text-xs font-semibold text-primary">{question.id}</div>
                          <div className="mt-1 text-sm font-medium leading-7">{question.label}</div>
                          <div className="mt-3 whitespace-pre-wrap rounded-2xl bg-surface p-4 text-sm leading-7 text-foreground">
                            {valueOrDash(answers?.[question.id])}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {cvFile && (
                  <div className="rounded-2xl border border-border bg-card p-4 text-sm">
                    <div className="font-semibold">السيرة الذاتية المرفوعة</div>
                    <a href={cvFile.url} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-2 text-primary underline-offset-4 hover:underline">
                      <FileText className="h-4 w-4" aria-hidden="true" />
                      {cvFile.originalName}
                    </a>
                  </div>
                )}

                <div className="rounded-3xl border border-dashed border-border bg-background p-5">
                  <label className="flex cursor-pointer items-start gap-3">
                    <Checkbox
                      checked={watch("agreement") ?? false}
                      onCheckedChange={(checked) => setValue("agreement", checked === true, { shouldDirty: true, shouldTouch: true, shouldValidate: true })}
                    />
                    <div className="space-y-1 leading-7">
                      <div className="font-medium">أقر بأن المعلومات التي قدمتها في هذا الطلب صحيحة حسب علمي، وأتفهم أن تقديم الطلب لا يعني القبول التلقائي في حركة 967، وأن قرار قبول الطلب يخضع للمراجعة من الفريق المختص.</div>
                      <p className="text-xs text-muted-foreground">موافقتك مطلوبة قبل إرسال الطلب.</p>
                    </div>
                  </label>
                  {errors.agreement && <p className="mt-2 text-xs text-destructive">{errors.agreement.message}</p>}
                </div>
              </div>
            )}

            <div className="mt-8 flex items-center justify-between gap-3 border-t border-border pt-5">
              <Button
                type="button"
                variant="outline"
                onClick={() => setStep((current) => Math.max(current - 1, 0))}
                disabled={step === 0 || submitMutation.isPending}
              >
                <ChevronRight className="ml-2 h-4 w-4" aria-hidden="true" />
                السابق
              </Button>

              {step < totalSteps - 1 ? (
                <Button type="button" className="gradient-gold border-0 font-semibold text-black" onClick={() => void handleNext()} disabled={uploadingCv || submitMutation.isPending}>
                  التالي
                  <ChevronLeft className="mr-2 h-4 w-4" aria-hidden="true" />
                </Button>
              ) : (
                <Button type="submit" className="gradient-gold border-0 font-semibold text-black" disabled={uploadingCv || submitMutation.isPending}>
                  {submitMutation.isPending ? (
                    <span className="inline-flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                      جارٍ الإرسال...
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-2">
                      <BadgeCheck className="h-4 w-4" aria-hidden="true" />
                      إرسال الطلب
                    </span>
                  )}
                </Button>
              )}
            </div>
          </form>
        </div>
      </section>
    </PublicLayout>
  );
}

function SummaryRow({ label, value }: { label: string; value?: string | number | null }) {
  return (
    <div className="rounded-2xl bg-card p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-1 text-sm font-medium">{valueOrDash(value)}</div>
    </div>
  );
}

import { useState } from "react";
import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";
import { ContentCard } from "@/components/ContentCard";
import { CardGridSkeleton } from "@/components/LoadingState";
import { EmptyState } from "@/components/EmptyState";
import { Pagination } from "@/components/Pagination";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { Search, FolderOpen } from "lucide-react";

export default function ProjectsPage() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  const { data, isLoading } = trpc.projects.list.useQuery({ page, limit: 9, status: "published", search: debouncedSearch || undefined });

  const handleSearch = (v: string) => {
    setSearch(v);
    clearTimeout((window as any).__projSearchTimer);
    (window as any).__projSearchTimer = setTimeout(() => { setDebouncedSearch(v); setPage(1); }, 400);
  };

  return (
    <PublicLayout>
      <PageSEO title="المشاريع" description="مشاريع حركة 967 التنموية والمجتمعية في اليمن" />

      <section className="bg-surface text-surface-foreground py-16">
        <div className="container">
          <div className="text-primary text-sm font-medium mb-2">المشاريع</div>
          <h1 className="text-3xl font-black text-surface-foreground mb-2">مشاريعنا</h1>
          <p className="text-surface-foreground/60 text-sm">مبادرات تنموية تغير الواقع اليمني</p>
        </div>
      </section>

      <section className="py-10">
        <div className="container">
          <div className="relative max-w-sm mb-8">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="ابحث في المشاريع..." value={search} onChange={(e) => handleSearch(e.target.value)} className="pr-9" />
          </div>

          {isLoading ? (
            <CardGridSkeleton count={9} />
          ) : !data?.items.length ? (
            <EmptyState icon={FolderOpen} title="لا توجد مشاريع" description={search ? "لا توجد نتائج لبحثك" : "لم يتم نشر أي مشاريع بعد"} />
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {data.items.map((item) => (
                  <ContentCard key={item.id} title={item.title} excerpt={item.excerpt} coverImage={item.imageUrl ?? item.coverImage} category={item.category} date={item.createdAt} viewCount={item.viewCount} featured={item.featured} href={`/projects/${item.slug}`} />
                ))}
              </div>
              <Pagination page={page} total={data.total} limit={9} onPageChange={setPage} />
            </>
          )}
        </div>
      </section>
    </PublicLayout>
  );
}

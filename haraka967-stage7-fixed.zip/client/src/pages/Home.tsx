import { Link } from "wouter";
import {
  ArrowLeft,
  BookOpen,
  ChevronLeft,
  Crown,
  MapPin,
  Newspaper,
  ShieldCheck,
  Sparkles,
  Users,
  Workflow,
  Image as ImageIcon,
  Layers3,
  MessageSquare,
  Globe2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { PublicLayout } from "@/components/PublicLayout";
import { PageSEO } from "@/components/PageSEO";
import { ContentCard } from "@/components/ContentCard";
import { CardGridSkeleton } from "@/components/LoadingState";
import { EmptyState } from "@/components/EmptyState";
import { trpc } from "@/lib/trpc";
import { SiteLogo } from "@/components/SiteLogo";

const overviewTiles = [
  {
    title: "الصفحة الرئيسية",
    desc: "واجهة افتتاحية داكنة مع شعار واضح، عنوان قوي، ومساحة بصرية واسعة.",
    icon: Sparkles,
  },
  {
    title: "الأخبار",
    desc: "عرض أخباري شبكي يركّز على الصور والتغطية الحديثة للمحتوى.",
    icon: Newspaper,
  },
  {
    title: "المشاريع",
    desc: "بطاقات مشاريع حديثة مع ملخصات سريعة وأزرار متابعة واضحة.",
    icon: Workflow,
  },
  {
    title: "الخريطة",
    desc: "مخطط جغرافي يوصل المحافظات بالنشاط والمساهمات والانتشار.",
    icon: MapPin,
  },
];

const featureList = [
  "وضع ليلي افتراضي",
  "وضع نهاري متاح بالتبديل",
  "أسود / ذهبي / رمادي",
  "RTL كامل",
  "شعار واضح في كل الواجهات",
  "تباين بصري قوي مثل التصميم المرجعي",
];

function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-surface text-surface-foreground">
      <div className="absolute inset-0 opacity-[0.06]">
        <div className="absolute inset-0" style={{ backgroundImage: "radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)", backgroundSize: "38px 38px" }} />
      </div>
      <div className="absolute inset-x-0 top-0 h-px gradient-gold opacity-80" />
      <div className="absolute inset-x-0 bottom-0 h-px gradient-gold opacity-40" />

      <div className="container relative z-10 py-16 sm:py-20 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-[1.05fr_0.95fr] gap-10 items-center">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/25 bg-black/20 px-3 py-1.5 text-xs sm:text-sm text-primary mb-6">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              المنصة المجتمعية اليمنية
            </div>

            <div className="flex items-center gap-4 mb-6">
              <SiteLogo
                size="xl"
                showText={false}
                imageClassName="shadow-2xl ring-1 ring-white/10"
              />
              <div>
                <div className="text-sm text-surface-foreground/55">الهوية الرسمية</div>
                <div className="text-xl sm:text-2xl font-black text-surface-foreground">حركة 967</div>
              </div>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-[1.05] mb-6 text-surface-foreground">
              معًا نصنع التغيير
              <span className="block text-primary mt-2">من أجل يمن أفضل</span>
            </h1>

            <p className="text-base sm:text-lg text-surface-foreground/72 leading-8 max-w-xl">
              منصة مجتمعية يمنية غير ربحية تجمع الشباب، المشاريع، المعرفة، والأخبار في مكان واحد. تصميمها هنا أقرب إلى لوحات العرض الحديثة: واضح، داكن، ومليء بالهوية.
            </p>

            <p className="mt-4 text-sm italic text-primary/90">من اليمن نبدأ، ولأجل اليمن نمضي.</p>

            <div className="flex flex-wrap gap-3 mt-8">
              <Link href="/join">
                <Button size="lg" className="gradient-gold text-black font-bold border-0 hover:opacity-90 px-8 gold-glow">
                  انضم إلينا
                  <ArrowLeft className="w-4 h-4 mr-2" />
                </Button>
              </Link>
              <Link href="/about">
                <Button size="lg" variant="outline" className="border-surface-foreground/20 bg-black/10 text-surface-foreground hover:bg-black/20 px-8">
                  اعرف أكثر
                </Button>
              </Link>
            </div>
          </div>

          <div className="relative">
            <Card className="relative overflow-hidden border-border/70 bg-black/50 shadow-2xl backdrop-blur-xl">
              <div className="absolute inset-0 opacity-[0.08]" style={{ backgroundImage: "radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)", backgroundSize: "26px 26px" }} />
              <div className="relative p-4 sm:p-5 lg:p-6">
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-3">
                    <SiteLogo size="sm" showText={false} />
                    <div>
                      <div className="font-black text-surface-foreground leading-none">967</div>
                      <div className="text-[11px] text-surface-foreground/55 mt-1">شكل الموقع وأقسامه</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                    <span className="text-xs text-surface-foreground/50">Live preview</span>
                  </div>
                </div>

                <div className="rounded-3xl border border-white/10 bg-[#111111] p-4 sm:p-5">
                  <div className="flex items-center justify-between gap-3 mb-4">
                    <div className="space-y-2">
                      <div className="h-3 w-28 rounded-full bg-white/15" />
                      <div className="h-2.5 w-44 rounded-full bg-white/10" />
                    </div>
                    <div className="hidden sm:flex items-center gap-2">
                      <div className="h-8 w-16 rounded-full bg-white/10" />
                      <div className="h-8 w-20 rounded-full gradient-gold" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                    {[
                      ["12,500", "أعضاء فاعلون"],
                      ["320", "المشاريع المنجزة"],
                      ["BS", "الخبرات"],
                      ["150", "المحتوى المنشور"],
                    ].map(([value, label]) => (
                      <div key={label} className="rounded-2xl border border-white/8 bg-white/4 p-3">
                        <div className="text-lg font-black text-surface-foreground">{value}</div>
                        <div className="text-[11px] text-surface-foreground/55 mt-1">{label}</div>
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-[1.1fr_0.9fr] gap-3">
                    <div className="rounded-2xl border border-white/8 bg-white/5 p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <div className="text-sm font-bold">أبرز المشاريع</div>
                          <div className="text-[11px] text-surface-foreground/55">واجهة تعرض أهم المبادرات</div>
                        </div>
                        <Layers3 className="w-4 h-4 text-primary" />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {["مبادرة تعليمية", "مشروع خيري", "محتوى معرفي", "أخبار ميدانية"].map((x) => (
                          <div key={x} className="rounded-xl overflow-hidden bg-black/30 border border-white/8">
                            <div className="h-14 bg-gradient-to-br from-white/10 to-white/5" />
                            <div className="px-2.5 py-2 text-[11px] text-surface-foreground/75">{x}</div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="rounded-2xl border border-white/8 bg-white/5 p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <MapPin className="w-4 h-4 text-primary" />
                          <div className="text-sm font-bold">خريطة اليمن</div>
                        </div>
                        <div className="h-24 rounded-xl bg-[radial-gradient(circle_at_top_right,_rgba(232,191,95,0.2),_transparent_45%),linear-gradient(180deg,rgba(255,255,255,0.04),rgba(255,255,255,0.02))] border border-white/8" />
                      </div>
                      <div className="rounded-2xl border border-white/8 bg-white/5 p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <MessageSquare className="w-4 h-4 text-primary" />
                          <div className="text-sm font-bold">النموذج التفاعلي</div>
                        </div>
                        <div className="space-y-2">
                          <div className="h-2.5 w-full rounded-full bg-white/10" />
                          <div className="h-2.5 w-4/5 rounded-full bg-white/10" />
                          <div className="h-2.5 w-2/3 rounded-full bg-white/10" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            <div className="absolute -right-4 top-10 hidden xl:block w-28 h-28 rounded-full bg-primary/15 blur-3xl" />
            <div className="absolute -left-6 bottom-10 hidden xl:block w-36 h-36 rounded-full bg-white/6 blur-3xl" />
          </div>
        </div>
      </div>
    </section>
  );
}

function BlueprintSection() {
  return (
    <section className="py-16 sm:py-20">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-xs sm:text-sm text-primary mb-4">
            <Crown className="w-3.5 h-3.5" />
            شكل الموقع وأقسامه الرئيسية
          </div>
          <h2 className="text-3xl sm:text-4xl font-black mb-4">واجهة ليلية فخمة وواضحة</h2>
          <p className="text-muted-foreground leading-8">
            صممت هذه الصفحة لتقترب من المزاج البصري الذي أرسلته: تباين عالٍ، لوحات متعددة، أقسام ظاهرة بوضوح، وشعار حاضر في كل زاوية مهمة.
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-[0.86fr_1.25fr_0.86fr] gap-6 items-start">
          <div className="space-y-4">
            {overviewTiles.slice(0, 2).map((tile, index) => (
              <Card key={tile.title} className="overflow-hidden border-border/70 bg-card/95 shadow-lg">
                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="text-xs text-muted-foreground">0{index + 1}</div>
                    <tile.icon className="w-4 h-4 text-primary" />
                  </div>
                  <h3 className="font-black text-lg mb-2">{tile.title}</h3>
                  <p className="text-sm text-muted-foreground leading-7">{tile.desc}</p>
                </div>
                <div className="h-24 bg-[linear-gradient(135deg,rgba(232,191,95,0.18),rgba(255,255,255,0.04))] border-t border-border/60" />
              </Card>
            ))}

            <Card className="p-5 border-border/70 bg-card/95 shadow-lg">
              <h3 className="font-black text-lg mb-4">الألوان والخطوط</h3>
              <div className="flex items-center gap-3 mb-5">
                {["#000000", "#E8BF5F", "#EDEDED", "#1F1F1F"].map((color) => (
                  <span key={color} className="w-10 h-10 rounded-full border border-white/10" style={{ background: color }} />
                ))}
              </div>
              <div className="space-y-3 text-sm text-muted-foreground">
                {featureList.map((item) => (
                  <div key={item} className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-primary shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          <Card className="relative overflow-hidden border-border/70 bg-black/55 shadow-2xl">
            <div className="absolute inset-0 opacity-[0.07]" style={{ backgroundImage: "radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)", backgroundSize: "30px 30px" }} />
            <div className="relative p-4 sm:p-5 lg:p-6">
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                  <SiteLogo size="sm" showText={false} />
                  <div>
                    <div className="text-sm font-black">967 Platform</div>
                    <div className="text-[11px] text-surface-foreground/55">الصفحة الرئيسية</div>
                  </div>
                </div>
                <div className="hidden md:flex items-center gap-2 text-xs text-surface-foreground/55">
                  <span>الرئيسية</span>
                  <span>•</span>
                  <span>الأخبار</span>
                  <span>•</span>
                  <span>المشاريع</span>
                  <span>•</span>
                  <span>الخريطة</span>
                </div>
              </div>

              <div className="rounded-[2rem] border border-white/10 bg-[#0f0f0f] p-4 sm:p-5 lg:p-6 shadow-inner">
                <div className="grid grid-cols-1 md:grid-cols-[1.1fr_0.9fr] gap-4">
                  <div className="rounded-[1.75rem] border border-white/8 bg-[radial-gradient(circle_at_top_right,_rgba(232,191,95,0.2),_transparent_35%),linear-gradient(180deg,rgba(255,255,255,0.04),rgba(255,255,255,0.02))] p-5 sm:p-6 min-h-[18rem] flex flex-col justify-between">
                    <div>
                      <div className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-black/25 px-3 py-1 text-[11px] text-primary mb-4">
                        <Sparkles className="w-3.5 h-3.5" />
                        لوحة العرض الرئيسية
                      </div>
                      <h3 className="text-3xl sm:text-4xl font-black leading-tight text-surface-foreground">
                        معًا نصنع التغيير
                        <span className="block text-primary mt-2">من أجل يمن أفضل</span>
                      </h3>
                      <p className="mt-4 text-sm sm:text-base text-surface-foreground/65 leading-7 max-w-lg">
                        مساحة بصرية واسعة، عنوان قوي، وزر واضح للانضمام. هذا هو المزاج الذي يقترب من النموذج المرسل.
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-3 mt-6">
                      <div className="rounded-full bg-primary/15 border border-primary/20 px-4 py-2 text-xs text-primary">رؤية واضحة</div>
                      <div className="rounded-full bg-white/5 border border-white/10 px-4 py-2 text-xs text-surface-foreground/70">RTL</div>
                      <div className="rounded-full bg-white/5 border border-white/10 px-4 py-2 text-xs text-surface-foreground/70">Dark Mode</div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        ["12,500", "أعضاء"], ["320", "مشروع"], ["150", "خبر"], ["21", "مقاطعة"]
                      ].map(([value, label]) => (
                        <div key={label} className="rounded-2xl border border-white/8 bg-white/5 p-4">
                          <div className="text-2xl font-black text-surface-foreground">{value}</div>
                          <div className="text-[11px] text-surface-foreground/55 mt-1">{label}</div>
                        </div>
                      ))}
                    </div>

                    <div className="rounded-2xl border border-white/8 bg-white/5 p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-sm font-bold">آخر الأخبار</div>
                        <Newspaper className="w-4 h-4 text-primary" />
                      </div>
                      <div className="space-y-3">
                        {["تحديثات ميدانية", "مبادرات شبابية", "مشاريع تعليمية"].map((item) => (
                          <div key={item} className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-white/8" />
                            <div className="flex-1">
                              <div className="text-sm text-surface-foreground/85">{item}</div>
                              <div className="text-[11px] text-surface-foreground/45">وصف مختصر للبطاقة</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="rounded-2xl border border-white/8 bg-white/5 p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-sm font-bold">الخريطة التفاعلية</div>
                        <Globe2 className="w-4 h-4 text-primary" />
                      </div>
                      <div className="h-28 rounded-xl bg-[radial-gradient(circle_at_20%_25%,rgba(232,191,95,0.3),transparent_20%),radial-gradient(circle_at_75%_45%,rgba(232,191,95,0.15),transparent_24%),linear-gradient(180deg,rgba(255,255,255,0.03),rgba(255,255,255,0.01))] border border-white/8" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          <div className="space-y-4">
            <Card className="p-5 border-border/70 bg-card/95 shadow-lg">
              <h3 className="font-black text-lg mb-4">الأقسام الرئيسية للموقع</h3>
              <div className="space-y-3">
                {[
                  ["01", "الرئيسية", "عرض شامل ومختصر"],
                  ["02", "الأخبار", "متابعة ما يحدث"],
                  ["03", "المشاريع", "مبادرات ومخرجات"],
                  ["04", "الخريطة", "انتشار النشاط"],
                  ["05", "المعرفة", "محتوى موثوق"],
                ].map(([n, title, desc]) => (
                  <div key={title} className="flex items-start gap-3 rounded-2xl border border-border/60 bg-muted/20 p-3">
                    <div className="text-primary font-black text-sm mt-0.5">{n}</div>
                    <div>
                      <div className="font-bold text-sm">{title}</div>
                      <div className="text-xs text-muted-foreground mt-1">{desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-5 border-border/70 bg-card/95 shadow-lg">
              <div className="flex items-center gap-2 mb-4">
                <ImageIcon className="w-4 h-4 text-primary" />
                <h3 className="font-black text-lg">الهوية البصرية</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-7">
                شعار قوي، تباين عالٍ، وخلفية داكنة ليظهر الموقع بمظهر أقرب للنموذج الذي أرسلته، مع الحفاظ على صفاء القراءة في الوضع النهاري.
              </p>
            </Card>

            <Card className="p-5 border-border/70 bg-card/95 shadow-lg">
              <div className="flex items-center gap-2 mb-4">
                <BookOpen className="w-4 h-4 text-primary" />
                <h3 className="font-black text-lg">الرسالة</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-7">
                لا نبني حضورًا عابرًا، بل نصنع أثرًا يبقى.
              </p>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}

function StatsSection() {
  const { data: stats } = trpc.dashboard.stats.useQuery(undefined, { retry: false });
  const items = [
    { label: "عضو فاعل", value: stats?.members ?? "—", icon: Users },
    { label: "مشروع منجز", value: stats?.projects ?? "—", icon: BookOpen },
    { label: "نقطة على الخريطة", value: stats?.mapPoints ?? "—", icon: MapPin },
    { label: "خبر منشور", value: stats?.news ?? "—", icon: Newspaper },
  ];
  return (
    <section className="py-16 bg-muted/25">
      <div className="container">
        <p className="mb-6 text-center text-sm italic text-muted-foreground">كل رقم هنا حكاية، وكل حكاية جزء من وطن.</p>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map(({ label, value, icon: Icon }) => (
            <div key={label} className="text-center p-6 rounded-2xl bg-card border border-border shadow-sm">
              <div className="w-12 h-12 rounded-xl gradient-gold flex items-center justify-center mx-auto mb-3">
                <Icon className="w-6 h-6 text-black" />
              </div>
              <div className="text-3xl font-black text-foreground mb-1">{typeof value === "number" ? value.toLocaleString("ar") : value}</div>
              <div className="text-sm text-muted-foreground">{label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function LatestNewsSection() {
  const { data, isLoading } = trpc.news.list.useQuery({ page: 1, limit: 3, status: "published" });
  return (
    <section className="py-16">
      <div className="container">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-black">آخر الأخبار</h2>
            <p className="text-muted-foreground text-sm mt-1">تابع أحدث أخبار الحركة</p>
          </div>
          <Link href="/news" className="flex items-center gap-1 text-primary text-sm font-medium hover:underline">
            عرض الكل <ChevronLeft className="w-4 h-4" />
          </Link>
        </div>
        {isLoading ? (
          <CardGridSkeleton count={3} />
        ) : !data?.items.length ? (
          <EmptyState title="لا توجد أخبار بعد" description="سيتم نشر الأخبار قريباً" />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {data.items.map((item) => (
              <ContentCard
                key={item.id}
                title={item.title}
                excerpt={item.excerpt}
                coverImage={item.coverImage}
                category={item.category}
                date={item.publishedAt ?? item.createdAt}
                viewCount={item.viewCount}
                featured={item.featured}
                href={`/news/${item.slug}`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function LatestProjectsSection() {
  const { data, isLoading } = trpc.projects.list.useQuery({ page: 1, limit: 3, status: "published" });
  return (
    <section className="py-16 bg-muted/15">
      <div className="container">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-black">أبرز المشاريع</h2>
            <p className="text-muted-foreground text-sm mt-1">مشاريع تغير الواقع اليمني</p>
          </div>
          <Link href="/projects" className="flex items-center gap-1 text-primary text-sm font-medium hover:underline">
            عرض الكل <ChevronLeft className="w-4 h-4" />
          </Link>
        </div>
        {isLoading ? (
          <CardGridSkeleton count={3} />
        ) : !data?.items.length ? (
          <EmptyState title="لا توجد مشاريع بعد" description="سيتم إضافة المشاريع قريباً" />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {data.items.map((item) => (
              <ContentCard
                key={item.id}
                title={item.title}
                excerpt={item.excerpt}
                coverImage={item.coverImage}
                category={item.category}
                date={item.createdAt}
                viewCount={item.viewCount}
                featured={item.featured}
                href={`/projects/${item.slug}`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function JoinCTASection() {
  return (
    <section className="py-20 bg-surface text-surface-foreground relative overflow-hidden">
      <div className="absolute inset-0 opacity-[0.07]" style={{ backgroundImage: "radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)", backgroundSize: "32px 32px" }} />
      <div className="container relative z-10 text-center">
        <h2 className="text-3xl sm:text-4xl font-black mb-4">كن جزءاً من التغيير</h2>
        <p className="text-surface-foreground/70 text-lg mb-3 max-w-xl mx-auto">
          انضم إلى آلاف الشباب اليمني الذين يعملون معاً لبناء مستقبل أفضل
        </p>
        <p className="text-surface-foreground/50 text-sm italic mb-8 max-w-xl mx-auto">نبني اليوم ما يستحقه الغد.</p>
        <Link href="/join">
          <Button size="lg" className="gradient-gold text-black font-bold border-0 hover:opacity-90 px-10">
            سجّل الآن مجاناً
          </Button>
        </Link>
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <PublicLayout>
      <PageSEO title="حركة 967" description="المنصة المجتمعية اليمنية - معًا نبني يمن أفضل" />
      <HeroSection />
      <BlueprintSection />
      <StatsSection />
      <LatestNewsSection />
      <LatestProjectsSection />
      <JoinCTASection />
    </PublicLayout>
  );
}

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { apiUrl } from "@/lib/api";
import { type FormEvent, useState } from "react";
import { useLocation } from "wouter";

export default function Login() {
  const [location] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);
    try {
      const response = await fetch(apiUrl("/api/auth/login"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ email, password }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || "تعذر تسجيل الدخول");
      // Session cookie is set by the server; no client-side token mirror.
      const requestedNext = new URLSearchParams(location.split("?")[1] ?? "").get("next");
      let next = "/admin";
      if (requestedNext) {
        try {
          const target = new URL(requestedNext, window.location.origin);
          if (target.origin === window.location.origin && target.pathname.startsWith("/") && !target.pathname.startsWith("//")) {
            next = `${target.pathname}${target.search}${target.hash}`;
          }
        } catch {
          // Ignore malformed/untrusted redirect targets and use /admin.
        }
      }
      window.location.href = next;
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تسجيل الدخول");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>تسجيل الدخول</CardTitle>
          <CardDescription>استخدم حساب الإدارة المحلي للدخول إلى لوحة التحكم.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            <Button type="submit" className="w-full">دخول</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

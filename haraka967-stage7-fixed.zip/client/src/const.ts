import { LOGIN_PATH } from "@shared/const";

export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

export const startLogin = () => {
  const next = `${window.location.pathname}${window.location.search}${window.location.hash}`;
  window.location.href = `${LOGIN_PATH}?next=${encodeURIComponent(next)}`;
};

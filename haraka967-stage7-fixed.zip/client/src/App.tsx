import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// ─── Public Pages ─────────────────────────────────────────────────────────────
import Home from "./pages/Home";
import About from "./pages/About";
import Vision from "./pages/Vision";
import NewsPage from "./pages/News";
import NewsDetail from "./pages/NewsDetail";
import ProjectsPage from "./pages/Projects";
import ProjectDetail from "./pages/ProjectDetail";
import MapPage from "./pages/Map";
import KnowledgePage from "./pages/Knowledge";
import KnowledgeDetail from "./pages/KnowledgeDetail";
import Join from "./pages/Join";
import SearchPage from "./pages/Search";
import Contact from "./pages/Contact";
import Privacy from "./pages/Privacy";
import Terms from "./pages/Terms";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";

// ─── Admin Pages ──────────────────────────────────────────────────────────────
import AdminDashboard from "./pages/admin/Dashboard";
import AdminMembers from "./pages/admin/AdminMembers";
import AdminApplications from "./pages/admin/AdminApplications";
import AdminProjects from "./pages/admin/AdminProjects";
import AdminProjectParticipations from "./pages/admin/AdminProjectParticipations";
import AdminNews from "./pages/admin/AdminNews";
import AdminPages from "./pages/admin/AdminPages";
import AdminKnowledge from "./pages/admin/AdminKnowledge";
import AdminMap from "./pages/admin/AdminMap";
import AdminRoles from "./pages/admin/AdminRoles";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminEmail from "./pages/admin/AdminEmail";
import AdminNotifications from "./pages/admin/AdminNotifications";
import AdminFiles from "./pages/admin/AdminFiles";
import AdminAudit from "./pages/admin/AdminAudit";
import AdminActivity from "./pages/admin/AdminActivity";
import AdminSearch from "./pages/admin/AdminSearch";

function Router() {
  return (
    <Switch>
      {/* ─── Public Routes ─────────────────────────────────── */}
      <Route path="/" component={Home} />
      <Route path="/about" component={About} />
      <Route path="/vision" component={Vision} />
      <Route path="/news" component={NewsPage} />
      <Route path="/news/:slug" component={NewsDetail} />
      <Route path="/projects" component={ProjectsPage} />
      <Route path="/projects/:slug" component={ProjectDetail} />
      <Route path="/map" component={MapPage} />
      <Route path="/knowledge" component={KnowledgePage} />
      <Route path="/knowledge/:slug" component={KnowledgeDetail} />
      <Route path="/join" component={Join} />
      <Route path="/search" component={SearchPage} />
      <Route path="/contact" component={Contact} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/terms" component={Terms} />
      <Route path="/login" component={Login} />

      {/* ─── Admin Routes ──────────────────────────────────── */}
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/members" component={AdminMembers} />
      <Route path="/admin/applications" component={AdminApplications} />
      <Route path="/admin/projects" component={AdminProjects} />
      <Route path="/admin/project-participations" component={AdminProjectParticipations} />
      <Route path="/admin/news" component={AdminNews} />
      <Route path="/admin/pages" component={AdminPages} />
      <Route path="/admin/knowledge" component={AdminKnowledge} />
      <Route path="/admin/map" component={AdminMap} />
      <Route path="/admin/roles" component={AdminRoles} />
      <Route path="/admin/settings" component={AdminSettings} />
      <Route path="/admin/email" component={AdminEmail} />
      <Route path="/admin/notifications" component={AdminNotifications} />
      <Route path="/admin/files" component={AdminFiles} />
      <Route path="/admin/audit" component={AdminAudit} />
      <Route path="/admin/activity" component={AdminActivity} />
      <Route path="/admin/search" component={AdminSearch} />

      {/* ─── 404 ───────────────────────────────────────────── */}
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable>
        <TooltipProvider>
          <Toaster position="top-center" richColors />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

import { describe, expect, it } from "vitest";
import {
  projectParticipationSubmissionSchema,
  projectParticipationStatusLabels,
  projectParticipationTypeLabels,
} from "./projectParticipation";

describe("project participation", () => {
  it("exposes readable labels", () => {
    expect(projectParticipationStatusLabels.pending).toBe("معلق");
    expect(projectParticipationTypeLabels.volunteer).toBe("متطوع");
  });

  it("validates a submission payload", () => {
    const result = projectParticipationSubmissionSchema.safeParse({
      projectId: 1,
      fullName: "أحمد محمد علي",
      email: "ahmed@example.com",
      participationType: "volunteer",
      skills: ["تنسيق"],
      motivation: "أرغب في المشاركة في هذا المشروع وخدمته بشكل فعّال.",
    });

    expect(result.success).toBe(true);
  });
});

import { z } from "zod";

export const projectParticipationTypeOptions = [
  { value: "volunteer", label: "متطوع" },
  { value: "team_member", label: "عضو فريق" },
  { value: "technical", label: "دعم تقني" },
  { value: "media", label: "دعم إعلامي" },
  { value: "logistics", label: "دعم لوجستي" },
  { value: "field_support", label: "دعم ميداني" },
  { value: "other", label: "أخرى" },
] as const;

export type ProjectParticipationType = (typeof projectParticipationTypeOptions)[number]["value"];

export const projectParticipationStatusValues = [
  "pending",
  "under_review",
  "more_information_required",
  "approved",
  "rejected",
] as const;

export type ProjectParticipationStatus = (typeof projectParticipationStatusValues)[number];

export const projectParticipationStatusLabels: Record<ProjectParticipationStatus, string> = {
  pending: "معلق",
  under_review: "قيد المراجعة",
  more_information_required: "مطلوب معلومات إضافية",
  approved: "مقبول",
  rejected: "مرفوض",
};

export const projectParticipationTypeLabels: Record<ProjectParticipationType, string> = {
  volunteer: "متطوع",
  team_member: "عضو فريق",
  technical: "دعم تقني",
  media: "دعم إعلامي",
  logistics: "دعم لوجستي",
  field_support: "دعم ميداني",
  other: "أخرى",
};

const trimOrUndefined = z
  .union([z.string(), z.undefined(), z.null()])
  .transform((value) => {
    if (typeof value !== "string") return undefined;
    const next = value.trim();
    return next ? next : undefined;
  })
  .optional();

export const projectParticipationSubmissionSchema = z.object({
  projectId: z.number().int().positive(),
  fullName: z.string().trim().min(3, "الاسم مطلوب"),
  email: z.string().trim().email("البريد الإلكتروني غير صحيح"),
  phone: trimOrUndefined.refine((value) => value === undefined || value.length <= 32, {
    message: "رقم الهاتف غير صحيح",
  }),
  governorate: trimOrUndefined,
  city: trimOrUndefined,
  participationType: z.enum([
    "volunteer",
    "team_member",
    "technical",
    "media",
    "logistics",
    "field_support",
    "other",
  ]),
  skills: z.array(z.string().trim().min(1)).default([]),
  motivation: z.string().trim().min(20, "يرجى كتابة سبب المشاركة بشكل واضح"),
});

export type ProjectParticipationInput = z.infer<typeof projectParticipationSubmissionSchema>;

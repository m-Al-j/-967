import { describe, expect, it } from "vitest";
import {
  getQuestionsForTeam,
  hasMeaningfulAnswer,
  hasMeaningfulName,
  isValidAge,
  isValidPhone,
  joinTeamOptions,
  joinApplicationSchema,
} from "./join";

describe("join helpers", () => {
  it("exposes the five allowed teams", () => {
    expect(joinTeamOptions.map((option) => option.value)).toEqual([
      "governance",
      "membership",
      "projects",
      "tech",
      "media",
    ]);
  });

  it("returns exactly two questions per team", () => {
    for (const team of joinTeamOptions.map((option) => option.value)) {
      const questions = getQuestionsForTeam(team as never);
      expect(questions).toHaveLength(2);
      expect(questions.every((q) => q.team === team)).toBe(true);
    }
  });

  it("rejects superficial answers and accepts meaningful ones", () => {
    expect(hasMeaningfulAnswer("نعم")).toBe(false);
    expect(hasMeaningfulAnswer("تمام")).toBe(false);
    expect(hasMeaningfulAnswer("أقدر")).toBe(false);
    expect(hasMeaningfulAnswer("سأبدأ بتحديد المشكلة ثم جمع البيانات من المتطوعين وبناء خطة تنفيذ واضحة")).toBe(true);
  });

  it("validates names, phones, and age correctly", () => {
    expect(hasMeaningfulName("محمد أحمد علي")).toBe(true);
    expect(hasMeaningfulName("12--" )).toBe(false);
    expect(isValidPhone("")).toBe(true);
    expect(isValidPhone("+966501234567")).toBe(true);
    expect(isValidPhone("501234567")).toBe(false);
    expect(isValidAge(13)).toBe(false);
    expect(isValidAge(30)).toBe(true);
  });

  it("rejects answers from a different team", () => {
    const result = joinApplicationSchema.safeParse({
      fullName: "محمد أحمد علي",
      email: "test@example.com",
      phone: "",
      gender: "male",
      birthPlace: "عدن، اليمن",
      age: undefined,
      currentAddress: "الدمام، السعودية",
      selectedTeam: "tech",
      answers: {
        T1: "أستخدم TypeScript وPostgreSQL مع التحقق من الصلاحيات وتشفير البيانات.",
        T2: "أتحقق من المصدر ثم أراجع القيم وأقارنها قبل إدخالها في التقارير.",
        G1: "إجراء غير مسموح لهذا الفريق.",
      },
      agreement: true,
    });
    expect(result.success).toBe(false);
  });

});

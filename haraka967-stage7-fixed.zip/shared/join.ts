import { z } from "zod";

export const joinTeamOptions = [
  {
    value: "governance",
    label: "فريق الإدارة والحوكمة",
    shortLabel: "الإدارة والحوكمة",
  },
  {
    value: "membership",
    label: "فريق العضوية والتنظيم الداخلي والفروع",
    shortLabel: "العضوية والتنظيم الداخلي",
  },
  {
    value: "projects",
    label: "فريق المشاريع والخدمات المجتمعية",
    shortLabel: "المشاريع والخدمات المجتمعية",
  },
  {
    value: "tech",
    label: "فريق التقنية والبحث والبيانات",
    shortLabel: "التقنية والبحث والبيانات",
  },
  {
    value: "media",
    label: "فريق الإعلام والعلاقات والشراكات",
    shortLabel: "الإعلام والعلاقات والشراكات",
  },
] as const;

export type JoinTeam = (typeof joinTeamOptions)[number]["value"];

export type TeamQuestion = {
  id: string;
  team: JoinTeam;
  label: string;
  hint?: string;
};

export const joinQuestionsByTeam: Record<JoinTeam, TeamQuestion[]> = {
  governance: [
    {
      id: "G1",
      team: "governance",
      label:
        "كيف تتصرف كعضو في فريق الحوكمة إذا وردت شكوى سرية عن مخالفة مالية أو تضارب مصالح لأحد قادة المشاريع الميدانية؟",
      hint: "اشرح خطواتك العملية وكيف تحافظ على السرية والشفافية.",
    },
    {
      id: "G2",
      team: "governance",
      label:
        "ما هي الخطوات التي تتبعها لإعداد ميزانية لمشروع تطوعي، وكيف تضمن تسجيل الإيرادات والمصروفات بشفافية؟",
      hint: "اذكر أدوات المتابعة أو الإجراءات التي ستعتمد عليها.",
    },
  ],
  membership: [
    {
      id: "M1",
      team: "membership",
      label:
        "إذا لاحظت تغيب عدد من الأعضاء عن مهامهم وتراجع أدائهم، ما هي الآلية التي ستتبعها للتواصل معهم وإعادة تقييم استمراريتهم؟",
      hint: "وضح أسلوب المتابعة والتدرج في التعامل.",
    },
    {
      id: "M2",
      team: "membership",
      label:
        "كيف تقترح تنظيم قنوات ديسكورد وتوزيع الرتب والصلاحيات لتسهيل تواصل الأعضاء في المدن المختلفة دون حدوث فوضى؟",
      hint: "اذكر تقسيم القنوات والأدوار المقترح.",
    },
  ],
  projects: [
    {
      id: "P1",
      team: "projects",
      label:
        "اذكر مشكلة مجتمعية أو خدمية في مدينتك، واقترح فكرة مشروع ميداني لحلها مع تحديد المهارات المطلوبة للمتطوعين للتنفيذ!",
      hint: "اشرح الفئة المستفيدة وخطوات التنفيذ.",
    },
    {
      id: "P2",
      team: "projects",
      label:
        "أثناء تنفيذ مشروع ميداني، حدث نقص مفاجئ في الأدوات المطلوبة. كيف تدير الموقف لضمان عدم توقف العمل وتطبيق قواعد السلامة؟",
      hint: "ركز على الأولويات وإدارة المخاطر.",
    },
  ],
  tech: [
    {
      id: "T1",
      team: "tech",
      label:
        "ما هي لغات البرمجة أو أنظمة إدارة قواعد البيانات التي تتقنها؟ وكيف يمكن توظيفها لتطوير نظام بلاغات آمن لحماية بيانات المستخدمين؟",
      hint: "اذكر خبرتك التقنية بشكل عملي.",
    },
    {
      id: "T2",
      team: "tech",
      label:
        "كيف تضمن دقة وصحة البيانات التي يتم جمعها عن مشكلات المدن قبل تحويلها إلى تقارير يعتمد عليها فريق المشاريع؟",
      hint: "اذكر خطوات التحقق والمراجعة.",
    },
  ],
  media: [
    {
      id: "R1",
      team: "media",
      label:
        "ما هي مجالات الإعلام التي تتقنها (مونتاج، كتابة سيناريو، تصوير، الخ..)؟ وكيف تصيغ رسالة إعلامية لمشروع تطوعي دون استخدام أساليب التضليل أو المبالغة؟",
      hint: "اذكر أدواتك أو نمطك في صناعة المحتوى.",
    },
    {
      id: "R2",
      team: "media",
      label:
        "اذكر خطة مبسطة لكيفية التواصل مع المغتربين اليمنيين وربط خبراتهم لدعم مشاريع الحركة في الداخل.",
      hint: "اشرح قنوات التواصل والفائدة المتوقعة.",
    },
  ],
};

export function getTeamLabel(team: JoinTeam): string {
  return joinTeamOptions.find((option) => option.value === team)?.label ?? team;
}

export function getQuestionsForTeam(team: JoinTeam): TeamQuestion[] {
  return joinQuestionsByTeam[team] ?? [];
}

const bannedShortAnswers = new Set([
  "نعم",
  "لا",
  "تمام",
  "أقدر",
  "اقدر",
  "موافق",
  "لا أعرف",
  "لا اعرف",
  "معك",
  "ok",
  "okay",
  "yes",
  "no",
]);

export function normalizeText(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

export function hasRealLetters(value: string): boolean {
  return /[\p{L}]/u.test(value);
}

export function hasMeaningfulName(value: string): boolean {
  const normalized = normalizeText(value);
  if (normalized.length < 3) return false;
  if (!hasRealLetters(normalized)) return false;
  if (/^[\d\s\W_]+$/u.test(normalized)) return false;
  return true;
}

export function hasMeaningfulAnswer(value: string): boolean {
  const normalized = normalizeText(value);
  const lower = normalized.toLowerCase();
  if (!normalized) return false;
  if (bannedShortAnswers.has(normalized) || bannedShortAnswers.has(lower)) return false;
  if (normalized.length < 18) return false;
  if (normalized.split(/\s+/).filter(Boolean).length < 3) return false;
  if (!hasRealLetters(normalized)) return false;
  const repeated = normalized.replace(/\s+/g, "");
  if (new Set(repeated).size <= 2) return false;
  return true;
}

export function normalizePhone(value: string): string {
  return normalizeText(value).replace(/[\-()\s]/g, "");
}

export function isValidPhone(value: string): boolean {
  const normalized = normalizePhone(value);
  if (!normalized) return true;
  return /^\+[1-9]\d{6,14}$/.test(normalized);
}

export function isValidLocation(value: string): boolean {
  const normalized = normalizeText(value);
  return normalized.length >= 3 && hasRealLetters(normalized);
}

export function isValidAge(value: number): boolean {
  return Number.isInteger(value) && value >= 14 && value <= 99;
}

export type CvUploadFile = {
  url: string;
  key: string;
  originalName: string;
  mimeType: string;
  size: number;
};

export const cvUploadSchema = z.object({
  url: z.string().url(),
  key: z.string().min(1),
  originalName: z.string().min(1),
  mimeType: z.string().min(1),
  size: z.number().int().positive(),
});

const applicationBaseSchema = z.object({
  fullName: z.string().trim().refine(hasMeaningfulName, {
    message: "يرجى كتابة اسم ثلاثي صحيح",
  }),
  email: z.string().trim().email("البريد الإلكتروني غير صحيح"),
  phone: z
    .union([z.string(), z.undefined(), z.null()])
    .transform((value) => {
      if (typeof value !== "string") return undefined;
      const normalized = normalizePhone(value);
      return normalized ? normalized : undefined;
    })
    .optional()
    .refine((value) => value === undefined || isValidPhone(value), {
      message: "رقم الهاتف غير صحيح",
    }),
  gender: z.string().refine((value) => value === "male" || value === "female", {
    message: "يرجى اختيار الجنس",
  }),
  birthPlace: z.string().trim().refine(isValidLocation, {
    message: "يرجى كتابة محل الميلاد بشكل صحيح",
  }),
  age: z
    .preprocess((value) => {
      if (value === "" || value === null || value === undefined) return undefined;
      const next = typeof value === "number" ? value : Number(value);
      return Number.isNaN(next) ? undefined : next;
    }, z.number().int().optional())
    .refine((value) => value === undefined || isValidAge(value), {
      message: "العمر غير منطقي",
    })
    .optional(),
  currentAddress: z.string().trim().refine(isValidLocation, {
    message: "يرجى كتابة العنوان الحالي بشكل صحيح",
  }),
  cvFile: cvUploadSchema.optional(),
  selectedTeam: z.string().refine(
    (value): value is JoinTeam => ["governance", "membership", "projects", "tech", "media"].includes(value as JoinTeam),
    {
      message: "يرجى اختيار الفريق",
    },
  ),
  answers: z.record(z.string(), z.string()).default({}),
  agreement: z.boolean().refine((value) => value === true, {
    message: "يجب الموافقة على الإقرار",
  }),
});

export const joinApplicationSchema = applicationBaseSchema.superRefine((data, ctx) => {
  const requiredQuestions = getQuestionsForTeam(data.selectedTeam as JoinTeam);
  const allowedIds = new Set(requiredQuestions.map((question) => question.id));

  for (const question of requiredQuestions) {
    const answer = normalizeText(data.answers[question.id] ?? "");
    if (!answer) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["answers", question.id],
        message: "هذه الإجابة مطلوبة",
      });
      continue;
    }
    if (!hasMeaningfulAnswer(answer)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["answers", question.id],
        message: "يرجى كتابة إجابة أكثر تفصيلًا توضح طريقة تفكيرك أو تجربتك.",
      });
    }
  }

  for (const key of Object.keys(data.answers ?? {})) {
    if (!allowedIds.has(key)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["answers", key],
        message: "هذا السؤال لا ينتمي للفريق المختار",
      });
    }
  }
});

export type JoinApplicationInput = z.infer<typeof joinApplicationSchema>;

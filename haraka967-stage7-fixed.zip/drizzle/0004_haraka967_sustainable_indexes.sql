-- Sustainability / performance indexes for growth over time
CREATE INDEX `users_email_idx` ON `users` (`email`);
CREATE INDEX `users_role_idx` ON `users` (`role`);
CREATE INDEX `users_last_signed_in_idx` ON `users` (`lastSignedIn`);

CREATE INDEX `members_user_id_idx` ON `members` (`userId`);
CREATE INDEX `members_email_idx` ON `members` (`email`);
CREATE INDEX `members_status_idx` ON `members` (`status`);
CREATE INDEX `members_governorate_idx` ON `members` (`governorate`);

CREATE INDEX `applications_email_idx` ON `applications` (`email`);
CREATE INDEX `applications_status_idx` ON `applications` (`status`);
CREATE INDEX `applications_selected_team_idx` ON `applications` (`selectedTeam`);
CREATE INDEX `applications_reviewed_by_idx` ON `applications` (`reviewedBy`);
CREATE INDEX `applications_submitted_at_idx` ON `applications` (`submittedAt`);

CREATE INDEX `news_status_idx` ON `news` (`status`);
CREATE INDEX `news_featured_idx` ON `news` (`featured`);
CREATE INDEX `news_author_id_idx` ON `news` (`authorId`);
CREATE INDEX `news_published_at_idx` ON `news` (`publishedAt`);

CREATE INDEX `projects_status_idx` ON `projects` (`status`);
CREATE INDEX `projects_featured_idx` ON `projects` (`featured`);
CREATE INDEX `projects_author_id_idx` ON `projects` (`authorId`);
CREATE INDEX `projects_category_idx` ON `projects` (`category`);
CREATE INDEX `projects_created_at_idx` ON `projects` (`createdAt`);

CREATE INDEX `knowledge_status_idx` ON `knowledge` (`status`);
CREATE INDEX `knowledge_featured_idx` ON `knowledge` (`featured`);
CREATE INDEX `knowledge_author_id_idx` ON `knowledge` (`authorId`);
CREATE INDEX `knowledge_category_idx` ON `knowledge` (`category`);
CREATE INDEX `knowledge_published_at_idx` ON `knowledge` (`publishedAt`);

CREATE INDEX `map_points_status_idx` ON `map_points` (`status`);
CREATE INDEX `map_points_governorate_idx` ON `map_points` (`governorate`);
CREATE INDEX `map_points_category_idx` ON `map_points` (`category`);
CREATE INDEX `map_points_related_idx` ON `map_points` (`relatedType`, `relatedId`);
CREATE INDEX `map_points_created_at_idx` ON `map_points` (`createdAt`);

CREATE INDEX `files_uploaded_by_idx` ON `files` (`uploadedBy`);
CREATE INDEX `files_folder_idx` ON `files` (`folder`);
CREATE INDEX `files_created_at_idx` ON `files` (`createdAt`);

CREATE INDEX `notifications_user_id_idx` ON `notifications` (`userId`);
CREATE INDEX `notifications_read_idx` ON `notifications` (`read`);
CREATE INDEX `notifications_created_at_idx` ON `notifications` (`createdAt`);

CREATE INDEX `audit_logs_user_id_idx` ON `audit_logs` (`userId`);
CREATE INDEX `audit_logs_entity_idx` ON `audit_logs` (`entity`);
CREATE INDEX `audit_logs_created_at_idx` ON `audit_logs` (`createdAt`);

CREATE INDEX `pages_status_idx` ON `pages` (`status`);
CREATE INDEX `pages_updated_by_idx` ON `pages` (`updatedBy`);
CREATE INDEX `pages_created_at_idx` ON `pages` (`createdAt`);

CREATE INDEX `site_settings_updated_by_idx` ON `site_settings` (`updatedBy`);
CREATE INDEX `site_settings_type_idx` ON `site_settings` (`type`);

-- حركة 967 — تحديث: معرّف المتقدم + صورة وإحداثيات المشروع
ALTER TABLE `applications` ADD COLUMN `applicantId` varchar(32);
--> statement-breakpoint
ALTER TABLE `applications` ADD CONSTRAINT `applications_applicantId_unique` UNIQUE(`applicantId`);
--> statement-breakpoint
ALTER TABLE `projects` ADD COLUMN `imageUrl` text;
--> statement-breakpoint
ALTER TABLE `projects` ADD COLUMN `latitude` float;
--> statement-breakpoint
ALTER TABLE `projects` ADD COLUMN `longitude` float;

import { sql } from "drizzle-orm";
import {
  boolean,
  doublePrecision,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

const roleValues = [
  "super_admin",
  "admin",
  "content_manager",
  "project_manager",
  "membership_manager",
  "map_manager",
  "knowledge_manager",
  "analyst",
  "member",
] as const;

export const userRoleEnum = pgEnum("user_role", roleValues);
export const memberStatusEnum = pgEnum("member_status", ["active", "inactive", "suspended"]);
export const genderEnum = pgEnum("application_gender", ["male", "female"]);
export const selectedTeamEnum = pgEnum("application_team", ["governance", "membership", "projects", "tech", "media"]);
export const applicationStatusEnum = pgEnum("application_status", ["pending", "under_review", "more_information_required", "approved", "rejected"]);
export const contentStatusEnum = pgEnum("content_status", ["draft", "published", "archived"]);
export const projectStatusEnum = pgEnum("project_status", ["draft", "published", "archived", "completed", "ongoing"]);
export const projectParticipationStatusEnum = pgEnum("project_participation_status", ["pending", "under_review", "more_information_required", "approved", "rejected"]);
export const mapStatusEnum = pgEnum("map_status", ["active", "inactive"]);
export const notificationTypeEnum = pgEnum("notification_type", ["info", "success", "warning", "error"]);
export const pageStatusEnum = pgEnum("page_status", ["draft", "published"]);
export const contactMessageStatusEnum = pgEnum("contact_message_status", ["new", "read", "replied", "archived"]);

// ─── Users ───────────────────────────────────────────────────────────────────
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  openId: varchar("open_id", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("login_method", { length: 64 }),
  role: userRoleEnum("role").default("member").notNull(),
  passwordHash: varchar("password_hash", { length: 255 }),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
  lastSignedIn: timestamp("last_signed_in", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  emailIdx: index("users_email_idx").on(table.email),
  roleIdx: index("users_role_idx").on(table.role),
  lastSignedInIdx: index("users_last_signed_in_idx").on(table.lastSignedIn),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── RBAC: editable role permissions ─────────────────────────────────────────
export const rolePermissions = pgTable("role_permissions", {
  id: serial("id").primaryKey(),
  role: userRoleEnum("role").notNull(),
  permission: varchar("permission", { length: 100 }).notNull(),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  roleIdx: index("role_permissions_role_idx").on(table.role),
  uniqueRolePermission: uniqueIndex("role_permissions_role_permission_key").on(table.role, table.permission),
}));

export type RolePermission = typeof rolePermissions.$inferSelect;
export type InsertRolePermission = typeof rolePermissions.$inferInsert;

// ─── RBAC: per-user permission overrides ─────────────────────────────────────
export const permissionEffectEnum = pgEnum("permission_effect", ["grant", "deny"]);

export const userPermissions = pgTable("user_permissions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  permission: varchar("permission", { length: 100 }).notNull(),
  effect: permissionEffectEnum("effect").default("grant").notNull(),
  grantedBy: integer("granted_by").references(() => users.id),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  userIdx: index("user_permissions_user_id_idx").on(table.userId),
  uniqueUserPermission: uniqueIndex("user_permissions_user_permission_key").on(table.userId, table.permission),
}));

export type UserPermission = typeof userPermissions.$inferSelect;
export type InsertUserPermission = typeof userPermissions.$inferInsert;

// ─── Members ─────────────────────────────────────────────────────────────────
export const members = pgTable("members", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  fullName: varchar("full_name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 32 }),
  city: varchar("city", { length: 100 }),
  governorate: varchar("governorate", { length: 100 }),
  bio: text("bio"),
  skills: jsonb("skills").$type<string[]>(),
  status: memberStatusEnum("status").default("active").notNull(),
  joinedAt: timestamp("joined_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("members_user_id_idx").on(table.userId),
  emailIdx: index("members_email_idx").on(table.email),
  statusIdx: index("members_status_idx").on(table.status),
  governorateIdx: index("members_governorate_idx").on(table.governorate),
}));

export type Member = typeof members.$inferSelect;
export type InsertMember = typeof members.$inferInsert;

// ─── Applications ─────────────────────────────────────────────────────────────
export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  applicantId: varchar("applicant_id", { length: 32 }).unique(),
  fullName: varchar("full_name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 32 }),
  gender: genderEnum("gender").notNull(),
  birthPlace: varchar("birth_place", { length: 160 }).notNull(),
  age: integer("age"),
  currentAddress: varchar("current_address", { length: 255 }).notNull(),
  cvUrl: text("cv_url"),
  cvFileKey: varchar("cv_file_key", { length: 500 }),
  cvOriginalName: varchar("cv_original_name", { length: 500 }),
  cvMimeType: varchar("cv_mime_type", { length: 100 }),
  cvSize: integer("cv_size"),
  selectedTeam: selectedTeamEnum("selected_team").notNull(),
  answers: jsonb("answers").$type<Record<string, string>>().notNull(),
  agreementAccepted: boolean("agreement_accepted").default(false).notNull(),
  city: varchar("city", { length: 100 }),
  governorate: varchar("governorate", { length: 100 }),
  motivation: text("motivation"),
  skills: jsonb("skills").$type<string[]>(),
  experience: text("experience"),
  status: applicationStatusEnum("status").default("pending").notNull(),
  reviewedBy: integer("reviewed_by").references(() => users.id),
  reviewNote: text("review_note"),
  submittedAt: timestamp("submitted_at", { mode: "date" }).defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at", { mode: "date" }),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  emailIdx: index("applications_email_idx").on(table.email),
  statusIdx: index("applications_status_idx").on(table.status),
  selectedTeamIdx: index("applications_selected_team_idx").on(table.selectedTeam),
  reviewedByIdx: index("applications_reviewed_by_idx").on(table.reviewedBy),
  submittedAtIdx: index("applications_submitted_at_idx").on(table.submittedAt),
  // Database-level guard against duplicate active applications for the same
  // email (defense in depth alongside the getActiveApplicationByEmail check
  // in server/db.ts, which is not race-safe on its own). A rejected
  // application does not count as active, so the same email can re-apply
  // once its prior application(s) are all rejected. Keep this list of
  // statuses in sync with getActiveApplicationByEmail.
  // See drizzle/0010_haraka967_active_application_email_unique.sql
  activeEmailUniqueIdx: uniqueIndex("applications_active_email_unique_idx")
    .on(sql`lower(${table.email})`)
    .where(sql`${table.status} in ('pending', 'under_review', 'more_information_required', 'approved')`),
}));

export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;

// ─── News ─────────────────────────────────────────────────────────────────────
export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 500 }).notNull(),
  excerpt: text("excerpt"),
  content: text("content").notNull(),
  coverImage: text("cover_image"),
  category: varchar("category", { length: 100 }),
  tags: jsonb("tags").$type<string[]>(),
  status: contentStatusEnum("status").default("draft").notNull(),
  featured: boolean("featured").default(false).notNull(),
  authorId: integer("author_id").references(() => users.id),
  viewCount: integer("view_count").default(0).notNull(),
  publishedAt: timestamp("published_at", { mode: "date" }),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  statusIdx: index("news_status_idx").on(table.status),
  featuredIdx: index("news_featured_idx").on(table.featured),
  authorIdIdx: index("news_author_id_idx").on(table.authorId),
  publishedAtIdx: index("news_published_at_idx").on(table.publishedAt),
}));

export type News = typeof news.$inferSelect;
export type InsertNews = typeof news.$inferInsert;

// ─── Projects ─────────────────────────────────────────────────────────────────
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 500 }).notNull(),
  excerpt: text("excerpt"),
  content: text("content").notNull(),
  coverImage: text("cover_image"),
  category: varchar("category", { length: 100 }),
  tags: jsonb("tags").$type<string[]>(),
  status: projectStatusEnum("status").default("draft").notNull(),
  featured: boolean("featured").default(false).notNull(),
  location: varchar("location", { length: 255 }),
  imageUrl: text("image_url"),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  startDate: timestamp("start_date", { mode: "date" }),
  endDate: timestamp("end_date", { mode: "date" }),
  authorId: integer("author_id").references(() => users.id),
  viewCount: integer("view_count").default(0).notNull(),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  statusIdx: index("projects_status_idx").on(table.status),
  featuredIdx: index("projects_featured_idx").on(table.featured),
  authorIdIdx: index("projects_author_id_idx").on(table.authorId),
  categoryIdx: index("projects_category_idx").on(table.category),
  createdAtIdx: index("projects_created_at_idx").on(table.createdAt),
}));

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;


// ─── Project Participation Requests ──────────────────────────────────────────
export const projectParticipationRequests = pgTable("project_participation_requests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  projectId: integer("project_id").references(() => projects.id, { onDelete: "cascade" }).notNull(),
  fullName: varchar("full_name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 32 }),
  governorate: varchar("governorate", { length: 100 }),
  city: varchar("city", { length: 100 }),
  participationType: varchar("participation_type", { length: 100 }).notNull(),
  skills: jsonb("skills").$type<string[]>(),
  motivation: text("motivation").notNull(),
  status: projectParticipationStatusEnum("status").default("pending").notNull(),
  reviewedBy: integer("reviewed_by").references(() => users.id),
  reviewNote: text("review_note"),
  submittedAt: timestamp("submitted_at", { mode: "date" }).defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at", { mode: "date" }),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("project_participation_requests_user_id_idx").on(table.userId),
  projectIdIdx: index("project_participation_requests_project_id_idx").on(table.projectId),
  statusIdx: index("project_participation_requests_status_idx").on(table.status),
  submittedAtIdx: index("project_participation_requests_submitted_at_idx").on(table.submittedAt),
}));

export type ProjectParticipationRequest = typeof projectParticipationRequests.$inferSelect;
export type InsertProjectParticipationRequest = typeof projectParticipationRequests.$inferInsert;

// ─── Knowledge ────────────────────────────────────────────────────────────────
export const knowledge = pgTable("knowledge", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 500 }).notNull(),
  excerpt: text("excerpt"),
  content: text("content").notNull(),
  coverImage: text("cover_image"),
  category: varchar("category", { length: 100 }),
  tags: jsonb("tags").$type<string[]>(),
  status: contentStatusEnum("status").default("draft").notNull(),
  featured: boolean("featured").default(false).notNull(),
  authorId: integer("author_id").references(() => users.id),
  viewCount: integer("view_count").default(0).notNull(),
  publishedAt: timestamp("published_at", { mode: "date" }),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  statusIdx: index("knowledge_status_idx").on(table.status),
  featuredIdx: index("knowledge_featured_idx").on(table.featured),
  authorIdIdx: index("knowledge_author_id_idx").on(table.authorId),
  categoryIdx: index("knowledge_category_idx").on(table.category),
  publishedAtIdx: index("knowledge_published_at_idx").on(table.publishedAt),
}));

export type Knowledge = typeof knowledge.$inferSelect;
export type InsertKnowledge = typeof knowledge.$inferInsert;

// ─── Map Points ───────────────────────────────────────────────────────────────
export const mapPoints = pgTable("map_points", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  lat: doublePrecision("lat").notNull(),
  lng: doublePrecision("lng").notNull(),
  category: varchar("category", { length: 100 }),
  governorate: varchar("governorate", { length: 100 }),
  icon: varchar("icon", { length: 100 }),
  color: varchar("color", { length: 20 }),
  status: mapStatusEnum("status").default("active").notNull(),
  relatedId: integer("related_id"),
  relatedType: varchar("related_type", { length: 50 }),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  statusIdx: index("map_points_status_idx").on(table.status),
  governorateIdx: index("map_points_governorate_idx").on(table.governorate),
  categoryIdx: index("map_points_category_idx").on(table.category),
  relatedIdx: index("map_points_related_idx").on(table.relatedType, table.relatedId),
  createdAtIdx: index("map_points_created_at_idx").on(table.createdAt),
}));

export type MapPoint = typeof mapPoints.$inferSelect;
export type InsertMapPoint = typeof mapPoints.$inferInsert;

// ─── Files ────────────────────────────────────────────────────────────────────
export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  filename: varchar("filename", { length: 500 }).notNull(),
  originalName: varchar("original_name", { length: 500 }).notNull(),
  mimeType: varchar("mime_type", { length: 100 }),
  size: integer("size"),
  url: text("url").notNull(),
  fileKey: varchar("file_key", { length: 500 }).notNull(),
  folder: varchar("folder", { length: 255 }),
  uploadedBy: integer("uploaded_by").references(() => users.id),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  uploadedByIdx: index("files_uploaded_by_idx").on(table.uploadedBy),
  folderIdx: index("files_folder_idx").on(table.folder),
  createdAtIdx: index("files_created_at_idx").on(table.createdAt),
}));

export type File = typeof files.$inferSelect;
export type InsertFile = typeof files.$inferInsert;

// ─── Notifications ────────────────────────────────────────────────────────────
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  type: notificationTypeEnum("type").default("info").notNull(),
  read: boolean("read").default(false).notNull(),
  link: varchar("link", { length: 500 }),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("notifications_user_id_idx").on(table.userId),
  readIdx: index("notifications_read_idx").on(table.read),
  createdAtIdx: index("notifications_created_at_idx").on(table.createdAt),
}));

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// ─── Audit Logs ───────────────────────────────────────────────────────────────
export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  action: varchar("action", { length: 100 }).notNull(),
  entity: varchar("entity", { length: 100 }),
  entityId: integer("entity_id"),
  details: jsonb("details"),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("audit_logs_user_id_idx").on(table.userId),
  entityIdx: index("audit_logs_entity_idx").on(table.entity),
  createdAtIdx: index("audit_logs_created_at_idx").on(table.createdAt),
}));

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

// ─── Site Settings ────────────────────────────────────────────────────────────
export const siteSettings = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  type: varchar("type", { length: 50 }).default("text").notNull(),
  updatedBy: integer("updated_by").references(() => users.id),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  updatedByIdx: index("site_settings_updated_by_idx").on(table.updatedBy),
  typeIdx: index("site_settings_type_idx").on(table.type),
}));

export type SiteSetting = typeof siteSettings.$inferSelect;
export type InsertSiteSetting = typeof siteSettings.$inferInsert;

// ─── Pages ────────────────────────────────────────────────────────────────────
export const pages = pgTable("pages", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 500 }).notNull(),
  content: text("content"),
  metaTitle: varchar("meta_title", { length: 500 }),
  metaDescription: text("meta_description"),
  status: pageStatusEnum("status").default("draft").notNull(),
  updatedBy: integer("updated_by").references(() => users.id),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  statusIdx: index("pages_status_idx").on(table.status),
  updatedByIdx: index("pages_updated_by_idx").on(table.updatedBy),
  createdAtIdx: index("pages_created_at_idx").on(table.createdAt),
}));

export type Page = typeof pages.$inferSelect;
export type InsertPage = typeof pages.$inferInsert;

// ─── Contact Messages ───────────────────────────────────────────────────────
export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  subject: varchar("subject", { length: 500 }).notNull(),
  message: text("message").notNull(),
  status: contactMessageStatusEnum("status").default("new").notNull(),
  readAt: timestamp("read_at", { mode: "date" }),
  repliedAt: timestamp("replied_at", { mode: "date" }),
  sourceIp: varchar("source_ip", { length: 45 }),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { mode: "date" }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { mode: "date" }).defaultNow().notNull(),
}, (table) => ({
  statusIdx: index("contact_messages_status_idx").on(table.status),
  emailIdx: index("contact_messages_email_idx").on(table.email),
  createdAtIdx: index("contact_messages_created_at_idx").on(table.createdAt),
}));

export type ContactMessage = typeof contactMessages.$inferSelect;
export type InsertContactMessage = typeof contactMessages.$inferInsert;

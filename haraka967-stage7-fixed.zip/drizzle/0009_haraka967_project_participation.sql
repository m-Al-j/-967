-- حركة 967 — طلبات المشاركة في المشاريع
CREATE TYPE "project_participation_status" AS ENUM ('pending', 'under_review', 'more_information_required', 'approved', 'rejected');

CREATE TABLE "project_participation_requests" (
  "id" serial PRIMARY KEY NOT NULL,
  "user_id" integer NOT NULL REFERENCES "users"("id") ON DELETE cascade,
  "project_id" integer NOT NULL REFERENCES "projects"("id") ON DELETE cascade,
  "full_name" varchar(255) NOT NULL,
  "email" varchar(320) NOT NULL,
  "phone" varchar(32),
  "governorate" varchar(100),
  "city" varchar(100),
  "participation_type" varchar(100) NOT NULL,
  "skills" jsonb,
  "motivation" text NOT NULL,
  "status" "project_participation_status" NOT NULL DEFAULT 'pending',
  "reviewed_by" integer REFERENCES "users"("id"),
  "review_note" text,
  "submitted_at" timestamp NOT NULL DEFAULT now(),
  "reviewed_at" timestamp,
  "updated_at" timestamp NOT NULL DEFAULT now()
);

CREATE INDEX "project_participation_requests_user_id_idx" ON "project_participation_requests" ("user_id");
CREATE INDEX "project_participation_requests_project_id_idx" ON "project_participation_requests" ("project_id");
CREATE INDEX "project_participation_requests_status_idx" ON "project_participation_requests" ("status");
CREATE INDEX "project_participation_requests_submitted_at_idx" ON "project_participation_requests" ("submitted_at");
CREATE UNIQUE INDEX "project_participation_requests_user_project_key" ON "project_participation_requests" ("user_id","project_id");

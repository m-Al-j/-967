CREATE TYPE "public"."contact_message_status" AS ENUM('new','read','replied','archived');

CREATE TABLE IF NOT EXISTS "contact_messages" (
  "id" serial PRIMARY KEY NOT NULL,
  "name" varchar(255) NOT NULL,
  "email" varchar(320) NOT NULL,
  "subject" varchar(500) NOT NULL,
  "message" text NOT NULL,
  "status" "contact_message_status" DEFAULT 'new' NOT NULL,
  "read_at" timestamp,
  "replied_at" timestamp,
  "source_ip" varchar(45),
  "user_agent" text,
  "created_at" timestamp DEFAULT now() NOT NULL,
  "updated_at" timestamp DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "contact_messages_status_idx" ON "contact_messages" USING btree ("status");
CREATE INDEX IF NOT EXISTS "contact_messages_email_idx" ON "contact_messages" USING btree ("email");
CREATE INDEX IF NOT EXISTS "contact_messages_created_at_idx" ON "contact_messages" USING btree ("created_at");

-- حركة 967 — منع تكرار طلبات العضوية النشطة لنفس البريد على مستوى قاعدة البيانات
--
-- الحماية الحالية على مستوى التطبيق (getActiveApplicationByEmail قبل الإدراج) عرضة
-- لتسابق (race condition): طلبان متزامنان لنفس البريد قد يجتازا الفحص معًا قبل أن
-- يكتمل أي إدراج. هذا الفهرس الفريد الجزئي (partial unique index) يفرض القيد فعليًا
-- داخل قاعدة البيانات نفسها، بينما يظل البريد قابلاً لتقديم طلب جديد بمجرد أن يصبح
-- كل طلب سابق له في حالة نهائية غير نشطة ("rejected").
--
-- الحالات المعتبرة "نشطة" هنا يجب أن تطابق getActiveApplicationByEmail في server/db.ts:
-- pending, under_review, more_information_required, approved.
CREATE UNIQUE INDEX "applications_active_email_unique_idx"
  ON "applications" (lower("email"))
  WHERE "status" IN ('pending', 'under_review', 'more_information_required', 'approved');

-- Haraka 967 — dynamic RBAC (editable roles & per-user permissions)

ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "is_active" boolean NOT NULL DEFAULT true;

DO $$ BEGIN
  CREATE TYPE "permission_effect" AS ENUM ('grant', 'deny');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS "role_permissions" (
  "id" serial PRIMARY KEY NOT NULL,
  "role" "user_role" NOT NULL,
  "permission" varchar(100) NOT NULL,
  "created_at" timestamp DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "role_permissions_role_idx" ON "role_permissions" ("role");
CREATE UNIQUE INDEX IF NOT EXISTS "role_permissions_role_permission_key" ON "role_permissions" ("role", "permission");

CREATE TABLE IF NOT EXISTS "user_permissions" (
  "id" serial PRIMARY KEY NOT NULL,
  "user_id" integer NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
  "permission" varchar(100) NOT NULL,
  "effect" "permission_effect" DEFAULT 'grant' NOT NULL,
  "granted_by" integer REFERENCES "users"("id"),
  "created_at" timestamp DEFAULT now() NOT NULL
);

CREATE INDEX IF NOT EXISTS "user_permissions_user_id_idx" ON "user_permissions" ("user_id");
CREATE UNIQUE INDEX IF NOT EXISTS "user_permissions_user_permission_key" ON "user_permissions" ("user_id", "permission");

CREATE INDEX IF NOT EXISTS "users_is_active_idx" ON "users" ("is_active");

ALTER TABLE `users`
  ADD COLUMN `passwordHash` varchar(255) NULL AFTER `loginMethod`;

ALTER TABLE `users`
  MODIFY COLUMN `role` enum(
    'super_admin',
    'admin',
    'content_manager',
    'project_manager',
    'membership_manager',
    'map_manager',
    'knowledge_manager',
    'analyst',
    'member'
  ) NOT NULL DEFAULT 'member';

# PROGRESS

## Current status
This codebase already has a strong foundation. The safest next step is to reduce load by following a small, explicit order instead of trying to finish everything at once.

## Current priorities
1. Keep a backup before any large change.
2. Verify the first owner/admin bootstrap path.
3. Confirm `/admin` access and role checks.
4. Fix any build/test failures.
5. Only after that, continue with feature polish and hardening.

## Useful file map
- `README.md` — project overview and recovery path
- `ADMIN_SETUP.md` — how the first admin is bootstrapped in this codebase
- `BACKUP_RECOVERY.md` — backup and rollback notes
- `docs/architecture.md` — safe places to extend the app
- `server/routers.ts` — auth/admin guards and tRPC routes
- `server/db.ts` — user bootstrap and role assignment behavior
- `client/src/components/AdminLayout.tsx` — admin navigation
- `client/src/pages/admin/` — admin screens

## Notes from the current code
- `auth.me` returns the current user session data.
- Admin access is currently influenced by role and by configured email lists/settings.
- The database layer auto-assigns the owner admin role when the configured owner identity matches.

## Next safe actions
- Make sure environment values are set.
- Log in with the owner account.
- Open `/admin` and verify access.
- Then use the admin UI to adjust roles, settings, and content.

## Recovery rule
If the app becomes unstable, stop adding new features and return to the last stable backup before continuing.

# Admin Setup

This project already has an admin path and role checks. The simplest safe bootstrap path is to use the existing owner identity settings that the code reads during user creation.

## How admin access works here
The current codebase gives admin access through a combination of:
- user role (`admin`, and in some places `editor` / `moderator`)
- configured email allow-lists in settings/env
- owner bootstrap values in env

The important bootstrap values are:
- `OWNER_OPEN_ID`
- `OWNER_EMAIL`
- `ADMIN_EMAILS`
- `JOIN_REQUESTS_EMAIL`

## Fast path for the first admin
1. Create or sign in with your real account.
2. Put that account's `openId` in `OWNER_OPEN_ID`, or put its email in `OWNER_EMAIL`.
3. Restart the app or re-run the auth flow so the user record is refreshed.
4. Sign in again.
5. Open `/admin`.

If the bootstrap values match, the app should treat that user as the owner/admin.

## Adding extra admins
After the first admin is working, you can manage additional users from the admin UI:
- open `/admin/roles`
- assign the role you want
- keep access limited to only the people you trust

If you need a temporary emergency access path, you can also add your email to `ADMIN_EMAILS` Use the `ADMIN_EMAILS` setting or manage administrators from the RBAC panel. `JOIN_REQUESTS_EMAIL` is only a notification destination and never grants admin access.

## Safe operating rule
Do not hard-code an email or password in the source code.
Use the existing env/settings path so the project stays portable.

## If access is lost
- Check the current `.env` values.
- Verify the owner email/openId matches the signed-in account.
- Confirm the user was refreshed after the env change.
- If needed, add your email temporarily to the admin access list, sign in, then clean it up.

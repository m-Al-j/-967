# Haraka 967

Project `Haraka 967` is a long-lived community platform built with:

- React + TypeScript
- Vite
- Express
- tRPC
- Drizzle ORM
- PostgreSQL / Supabase-ready schema
- wouter


## Start here

1. Read `ADMIN_SETUP.md` first.
2. Read `PROGRESS.md` for the current work order.
3. Create a backup before any large change.
4. Focus first on authentication, admin access, and role checks.

## Architecture goals

This codebase is organized to stay maintainable over time:

- UI code stays in `client/`
- server-side business logic stays in `server/`
- shared validation / types stay in `shared/`
- schema and migrations stay in `drizzle/`

## Maintenance notes

- Keep new business rules in shared validation and server routers.
- Keep database lookups paginated and indexed.
- Avoid hard-coding admin emails, notification emails, or owner data.
- Use settings in the database for operational configuration when possible.
- Prefer small, focused migrations.
- Keep upload validation strict for file type, size, and ownership.
- Use audit logs for sensitive operations.
- Regenerate the legacy migration files in `drizzle/` before first Postgres deploy; the current code now targets PostgreSQL/Supabase-ready schema.

## Local environment

Copy `.env.example` to `.env` and fill the values before running the app.

## Commands

- `pnpm install`
- `pnpm check`
- `pnpm test`
- `pnpm build`
- `pnpm build:dev`

## Quick recovery path

If the app feels unstable, stop feature work and do this in order:
1. restore the latest backup
2. verify `.env.example` / environment values
3. sign in with the owner account
4. confirm `/admin` access
5. run the build and tests
